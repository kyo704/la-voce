# -*- coding: utf-8 -*-
"""帽子 ── ★頭の実測に合わせる。耳は上に描き戻す
   頭の幅（実測）  y150:±204  y230:±244  y290:±274  y330:±264
   → かぶり口 y300 / 半幅 272、クラウンの頂点 y128 を基準にする"""
from PIL import Image, ImageDraw, ImageFilter
import numpy as np, math
W=H=1024; CX=511
BAND_Y=300          # かぶり口（帽子の下端）
BAND_HW=272         # かぶり口の半幅＝そこの頭の幅
TOP_Y=128           # クラウンの頂点
def dome(y0,hw,y1=BAND_Y): return [CX-hw,y0,CX+hw,2*y1-y0]   # 上半分だけ描く箱
head=Image.open('sheepparts2/sheep_head.png').convert('RGBA')
_h=np.array(head); _rgb=_h[:,:,:3].astype(int); _al=_h[:,:,3]
_earmask=((_rgb[:,:,0]>150)&(_rgb[:,:,0]<235)&(_rgb[:,:,2]<175)&(_al>100))
_earmask[250:,:]=False
EARS=np.zeros_like(_h); EARS[_earmask]=_h[_earmask]; EARS=Image.fromarray(EARS)
def sh(c,d): return tuple(max(0,int(v*(1-d))) for v in c)
def li(c,d): return tuple(min(255,int(v+(255-v)*d)) for v in c)
def new(): return Image.new('RGBA',(W,H),(0,0,0,0))
def outline(img,col,w=7):
    a=np.array(img); m=(a[:,:,3]>10).astype('uint8')*255
    mi=Image.fromarray(m).filter(ImageFilter.MinFilter(w))
    a[(m>0)&(np.array(mi)==0)]=(*col,255); return Image.fromarray(a)

def hat(kind, col, accent=None, band=None, ol=None, bake=True):
    acc=accent or li(col,0.45); bd=band or sh(col,0.28)
    im=new(); d=ImageDraw.Draw(im)
    if kind=='cap':
        d.pieslice(dome(BAND_Y-46,352,BAND_Y+52),180,360,fill=(*bd,255))      # つば
        d.arc(dome(BAND_Y-46,352,BAND_Y+52),182,358,fill=(*sh(col,0.44),255),width=6)
        d.pieslice(dome(TOP_Y,BAND_HW),180,360,fill=(*col,255))               # クラウン
        d.ellipse([CX-BAND_HW,BAND_Y-56,CX+BAND_HW,BAND_Y+30],fill=(*col,255))
        d.ellipse([CX-17,TOP_Y-6,CX+17,TOP_Y+26],fill=(*acc,255))
        for k in(-1,1): d.line([(CX+k*88,TOP_Y+40),(CX+k*88,BAND_Y-30)],fill=(*sh(col,0.13),255),width=5)
    elif kind=='knit':
        box=dome(TOP_Y+16,BAND_HW+6)
        d.pieslice(box,180,360,fill=(*col,255))
        m=new(); ImageDraw.Draw(m).pieslice(box,180,360,fill=(255,255,255,255))
        rib=new(); rd=ImageDraw.Draw(rib)
        for x in range(CX-BAND_HW-6,CX+BAND_HW+6,20): rd.line([(x,TOP_Y),(x,BAND_Y+40)],fill=(*sh(col,0.15),255),width=6)
        rib.putalpha(Image.composite(rib.getchannel('A'),Image.new('L',(W,H),0),m.getchannel('A')))
        im.alpha_composite(rib); d=ImageDraw.Draw(im)
        d.rounded_rectangle([CX-BAND_HW-12,BAND_Y-64,CX+BAND_HW+12,BAND_Y+16],24,fill=(*bd,255))
        for x in range(CX-BAND_HW-6,CX+BAND_HW+6,17): d.line([(x,BAND_Y-58),(x,BAND_Y+10)],fill=(*sh(bd,0.16),255),width=5)
        d.ellipse([CX-52,TOP_Y-70,CX+52,TOP_Y+34],fill=(*acc,255))
    elif kind=='beret':
        d.ellipse([CX-290,TOP_Y+38,CX+290,BAND_Y+34],fill=(*col,255))
        d.ellipse([CX-244,TOP_Y+52,CX+150,BAND_Y-24],fill=(*li(col,0.09),255))
        d.ellipse([CX-18,TOP_Y+16,CX+22,TOP_Y+56],fill=(*bd,255))
    elif kind=='hat':                       # 中折れ
        d.ellipse([CX-372,BAND_Y-32,CX+372,BAND_Y+82],fill=(*bd,255))
        d.pieslice(dome(TOP_Y+4,BAND_HW-16,BAND_Y+16),180,360,fill=(*col,255))
        d.ellipse([CX-(BAND_HW-16),BAND_Y-42,CX+(BAND_HW-16),BAND_Y+50],fill=(*sh(col,0.08),255))
        d.rectangle([CX-(BAND_HW-16),BAND_Y-58,CX+(BAND_HW-16),BAND_Y-6],fill=(*acc,255))
        d.line([(CX,TOP_Y+10),(CX,BAND_Y-70)],fill=(*sh(col,0.22),255),width=9)
    elif kind=='bucket':
        d.pieslice(dome(TOP_Y+30,BAND_HW-6,BAND_Y-24),180,360,fill=(*col,255))
        d.polygon([(CX-(BAND_HW-6),BAND_Y-30),(CX+(BAND_HW-6),BAND_Y-30),
                   (CX+352,BAND_Y+76),(CX-352,BAND_Y+76)],fill=(*sh(col,0.09),255))
        d.line([(CX-336,BAND_Y+46),(CX+336,BAND_Y+46)],fill=(*bd,255),width=7)
    elif kind=='straw':
        d.ellipse([CX-410,BAND_Y-14,CX+410,BAND_Y+118],fill=(*col,255))
        for r in range(30,392,30):
            d.arc([CX-r,BAND_Y+52-int(r*0.16),CX+r,BAND_Y+52+int(r*0.16)],0,360,fill=(*sh(col,0.11),255),width=3)
        d.pieslice(dome(TOP_Y+26,BAND_HW-22,BAND_Y+22),180,360,fill=(*li(col,0.07),255))
        d.rectangle([CX-(BAND_HW-22),BAND_Y-32,CX+(BAND_HW-22),BAND_Y+16],fill=(*bd,255))
    elif kind=='earmuff':
        d.arc([CX-BAND_HW-14,TOP_Y+6,CX+BAND_HW+14,BAND_Y-20],202,338,fill=(*bd,255),width=20)
        for s in(-1,1):
            d.ellipse([CX+s*272-72,BAND_Y-96,CX+s*272+72,BAND_Y+52],fill=(*col,255))
            d.ellipse([CX+s*272-46,BAND_Y-70,CX+s*272+46,BAND_Y+26],fill=(*li(col,0.20),255))
    elif kind=='ribbon':                    # カチューシャ
        d.arc([CX-BAND_HW-2,TOP_Y+34,CX+BAND_HW+2,BAND_Y+16],202,338,fill=(*col,255),width=22)
        bx=CX+168
        d.polygon([(bx,BAND_Y-88),(bx+112,BAND_Y-152),(bx+112,BAND_Y-30)],fill=(*acc,255))
        d.polygon([(bx,BAND_Y-88),(bx-112,BAND_Y-152),(bx-112,BAND_Y-30)],fill=(*acc,255))
        d.polygon([(bx-32,BAND_Y-66),(bx-70,BAND_Y+40),(bx+10,BAND_Y+18)],fill=(*sh(acc,0.10),255))
        d.polygon([(bx+32,BAND_Y-66),(bx+70,BAND_Y+40),(bx-10,BAND_Y+18)],fill=(*sh(acc,0.10),255))
        d.ellipse([bx-30,BAND_Y-114,bx+30,BAND_Y-58],fill=(*sh(acc,0.22),255))
    elif kind=='hood':
        d.pieslice([CX-330,TOP_Y-70,CX+330,BAND_Y+240],180,360,fill=(*col,255))
        d.pieslice([CX-252,TOP_Y-6,CX+252,BAND_Y+218],186,354,fill=(*sh(col,0.30),255))
    elif kind=='crown':
        b=BAND_Y+26; t=TOP_Y+52
        d.polygon([(CX-216,b),(CX-216,t+54),(CX-124,t+128),(CX-38,t),(CX+48,t+128),
                   (CX+140,t+54),(CX+140,b)],fill=(*col,255))
        d.rectangle([CX-216,b-40,CX+140,b+18],fill=(*sh(col,0.16),255))
        for x in (CX-124,CX-38,CX+48): d.ellipse([x-15,t+92,x+15,t+122],fill=(*acc,255))
    elif kind=='headband':
        d.arc([CX-BAND_HW-4,TOP_Y+40,CX+BAND_HW+4,BAND_Y+22],200,340,fill=(*col,255),width=42)
    elif kind=='santa':
        d.polygon([(CX-244,BAND_Y+10),(CX-180,TOP_Y+24),(CX+296,TOP_Y-16),(CX+230,BAND_Y+10)],fill=(*col,255))
        d.rounded_rectangle([CX-260,BAND_Y-38,CX+260,BAND_Y+34],28,fill=(*acc,255))
        d.ellipse([CX+252,TOP_Y-58,CX+352,TOP_Y+42],fill=(*acc,255))
    elif kind=='chef':
        for s in range(3):
            d.ellipse([CX-282+s*186,TOP_Y-92,CX-70+s*186,BAND_Y-46],fill=(*li(col,0.04),255))
        d.rounded_rectangle([CX-236,BAND_Y-72,CX+236,BAND_Y+42],20,fill=(*col,255))
        for x in range(CX-226,CX+226,32): d.line([(x,BAND_Y-62),(x,BAND_Y+32)],fill=(*sh(col,0.07),255),width=5)
    if ol: im=outline(im,ol)
    if bake: im.alpha_composite(EARS)
    return im
