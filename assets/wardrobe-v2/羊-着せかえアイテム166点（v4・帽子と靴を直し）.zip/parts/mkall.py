# -*- coding: utf-8 -*-
import os, json, random, shutil
from garment import *
import catalog as C, feet as F
from PIL import ImageFont
FB='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FR='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
fb=lambda s: ImageFont.truetype(FB,s); fr=lambda s: ImageFont.truetype(FR,s)
BG=(250,249,246); OUT='/home/claude/out/parts'
shutil.rmtree(OUT,ignore_errors=True)
FL=F.foot('L'); FR_=F.foot('R')
SPEC={'top':(C.TOPS,5),'bottom':(C.BOTTOMS,3),'outer':(C.OUTER,6),
      'neck':(C.NECK,7),'eyes':(C.EYES,9),'shoes':(C.SHOES,None),'hats':(C.HATS,10),
      'feet':None}
os.makedirs(f'{OUT}/feet',exist_ok=True)
FL.save(f'{OUT}/feet/foot_L@2x.png'); FR_.save(f'{OUT}/feet/foot_R@2x.png')
F.foot_shadow('L').save(f'{OUT}/feet/foot_shadow_L@2x.png')
F.foot_shadow('R').save(f'{OUT}/feet/foot_shadow_R@2x.png')
man=[]
for cat,v in SPEC.items():
    if v is None: continue
    items,layer=v; os.makedirs(f'{OUT}/{cat}',exist_ok=True)
    for i,it in enumerate(items):
        if cat=='shoes': name,g,z,img=it; ly=z
        else:            name,g,img=it;   ly=layer
        key=f'{cat}_{i+1:02d}'; img.save(f'{OUT}/{cat}/{key}@2x.png')
        man.append({'key':key,'category':cat,'name':name,'gender':g,'layer':ly,
                    'src':f'/assets/home/{cat}/{key}@2x.png','width':1024,'height':1024})
json.dump(man,open(f'{OUT}/manifest.json','w'),ensure_ascii=False,indent=1)

def compose(top=None,bottom=None,outer=None,neck=None,eyes=None,hat=None,shoe=None,z=4,feet=True):
    p=new()
    if feet: p.alpha_composite(FL); p.alpha_composite(FR_)
    p.alpha_composite(body)
    if shoe is not None and z==4: p.alpha_composite(shoe)
    if bottom is not None: p.alpha_composite(bottom)
    if shoe is not None and z==6: p.alpha_composite(shoe)
    for L in (top,outer,neck):
        if L is not None: p.alpha_composite(L)
    p.alpha_composite(head)
    for L in (eyes,hat):
        if L is not None: p.alpha_composite(L)
    return p
def flat(img,cell):
    b=Image.new('RGB',(W,H),BG); b.paste(img,(0,0),img); return b.resize((cell,cell))
def grid(items,getter,title,path,cols=6,cell=290):
    rows=(len(items)+cols-1)//cols
    im=Image.new('RGB',(cols*cell+40,rows*(cell+34)+130),BG); d=ImageDraw.Draw(im)
    d.text((28,30),title,font=fb(40),fill=(38,38,38))
    for i,it in enumerate(items):
        r,c=divmod(i,cols); x=20+c*cell; y=112+r*(cell+34)
        im.paste(flat(getter(it),cell-18),(x,y))
        nm=it[0]; nm=nm if len(nm)<=13 else nm[:12]+'…'
        d.text((x+6,y+cell-12),f"{ {'m':'男','f':'女','u':'共'}[it[1]] }　{nm}",font=fr(19),fill=(94,92,88))
    im.save(path,quality=95); print(path)
BT=C.TOPS[6][2]; BB=C.BOTTOMS[0][2]
grid(C.TOPS,   lambda it: compose(top=it[2],bottom=BB),  f'上（トップス）{len(C.TOPS)}点　男{len(C.TOPS_M)}・女{len(C.TOPS_F)}','/home/claude/out/羊-上.png')
grid(C.BOTTOMS,lambda it: compose(top=BT,bottom=it[2]),  f'下（ボトムス）{len(C.BOTTOMS)}点　男{len(C.BOTTOMS_M)}・女{len(C.BOTTOMS_F)}','/home/claude/out/羊-下.png')
grid(C.OUTER,  lambda it: compose(top=BT,bottom=BB,outer=it[2]), f'羽織り {len(C.OUTER)}点　男{len(C.OUTER_M)}・女{len(C.OUTER_F)}','/home/claude/out/羊-羽織り.png')
grid(C.NECK,   lambda it: compose(top=BT,bottom=BB,neck=it[2]),  f'首元 {len(C.NECK)}点','/home/claude/out/羊-首元.png')
grid(C.EYES,   lambda it: compose(top=BT,bottom=BB,eyes=it[2]),  f'目元 {len(C.EYES)}点','/home/claude/out/羊-目元.png')
grid(C.HATS,   lambda it: compose(top=BT,bottom=BB,hat=it[2]),   f'帽子 {len(C.HATS)}点　※耳を上に描き戻し','/home/claude/out/羊-帽子.png',cols=5)
grid([(n,g,img,z) for n,g,z,img in C.SHOES],
     lambda it: compose(top=BT,bottom=BB,shoe=it[2],z=it[3]),     f'靴 {len(C.SHOES)}点　※足パーツの上',
     '/home/claude/out/羊-靴.png',cols=6)
random.seed(5)
def pick(cat,g): return random.choice([x for x in cat if x[1] in (g,'u')])
combos=[]
for g in ('m','f'):
    for i in range(12):
        t=pick(C.TOPS,g); b=pick(C.BOTTOMS,g)
        sname,sg,sz,simg=pick(C.SHOES,g)
        o=pick(C.OUTER,g)[2] if random.random()<0.45 else None
        n=pick(C.NECK,g)[2]  if random.random()<0.40 else None
        e=pick(C.EYES,g)[2]  if random.random()<0.22 else None
        h=pick(C.HATS,g)[2]  if random.random()<0.40 else None
        combos.append((t[0]+'／'+b[0], g, compose(t[2],b[2],o,n,e,h,simg,sz)))
grid(combos, lambda it: it[2], '組み合わせの例（男12・女12）','/home/claude/out/羊-組み合わせ例.png')
n=len(C.TOPS)*len(C.BOTTOMS)*(len(C.OUTER)+1)*(len(C.NECK)+1)*(len(C.EYES)+1)*(len(C.HATS)+1)*(len(C.SHOES)+1)
print('総組み合わせ',f'{n:,}')
