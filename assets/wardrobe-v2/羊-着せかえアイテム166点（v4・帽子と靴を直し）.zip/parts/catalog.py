# -*- coding: utf-8 -*-
"""服のカタログ v2 ── 縫製と生地で描き分ける"""
from garment import *

WHITE=(246,245,242); OFFW=(236,232,222); IVORY=(240,232,216)
NAVY=(46,58,92); DENIM=(78,108,152); LTDEN=(136,162,192); INDIGO=(52,68,104)
GRAY=(126,128,132); LGRAY=(186,186,190); CHAR=(66,68,74); BLACK=(48,46,50)
CREAM=(228,214,186); CAMEL=(184,142,92); TAN=(198,170,132); BROWN=(120,86,62)
OLIVE=(104,110,78); KHAKI=(150,142,110); FOREST=(62,84,68)
RED=(178,62,62); WINE=(122,52,66); TERRA=(196,110,80); MUST=(206,164,68)
SAGE=(140,162,132); MINT=(168,200,182); SKY=(140,178,206); TEAL=(72,124,132)
PINK=(226,168,178); ROSE=(212,132,146); LAV=(168,152,196); PURPLE=(112,86,142)
LEMON=(232,214,140); PEACH=(238,190,164); GOLD=(198,166,96); SILVER=(196,198,202)
ORST=(214,150,70)   # デニムのステッチ

# ══════ 上 ══════
TOPS_M=[
('シャツ','m', mk_top(WHITE,neck='shirt',placket='shirt',yoke=True,buttons=3,cuff='band',
                      accent=(212,208,198),seam=(196,192,182),ol=(188,184,174))),
('ボタンダウン','m', mk_top(SKY,neck='shirt',placket='shirt',yoke=True,buttons=3,cuff='band',
                      accent=li(SKY,0.5),seam=sh(SKY,0.30))),
('チェックシャツ','m', mk_top(RED,tex=T_tartan(sh(RED,0.34),CHAR,62),neck='shirt',placket='shirt',
                      yoke=True,buttons=3,cuff='band',accent=OFFW,seam=sh(RED,0.42))),
('ワークシャツ','m', mk_top(OLIVE,neck='shirt',placket='shirt',yoke=True,buttons=3,cuff='band',
                      pocket='chest',accent=CREAM,seam=sh(OLIVE,0.4))),
('デニムシャツ','m', mk_top(DENIM,tex=T_twill,neck='shirt',placket='shirt',yoke=True,buttons=3,
                      cuff='band',pocket='chest',seam=ORST,accent=ORST)),
('ボーダー','m', mk_top(WHITE,tex=T_border(NAVY,30),neck='boat',cuff='band',ol=(196,192,182))),
('Ｔシャツ','m', mk_top(SKY,tex=T_jersey,neck='crew',sleeve='short',cuff='band')),
('ポロ','m', mk_top(SAGE,tex=T_pique,neck='polo',sleeve='short',cuff='band',accent=WHITE)),
('スウェット','m', mk_top(GRAY,tex=T_jersey,neck='crew',cuff='rib',hem_rib=True)),
('フーディ','m', mk_top(CHAR,tex=T_jersey,neck='hood',placket='zip',cuff='rib',hem_rib=True,pocket='kangaroo')),
('セーター（丸首）','m', mk_top(MUST,tex=T_garter(13),neck='crew',cuff='rib',hem_rib=True)),
('タートルネック','m', mk_top(CHAR,tex=T_rib(11),neck='turtle',cuff='rib',hem_rib=True)),
('ケーブルニット','m', mk_top(CREAM,tex=T_cable(44),neck='crew',cuff='rib',hem_rib=True,ol=(198,186,158))),
('ベスト','m', mk_top(NAVY,tex=T_garter(13),neck='v',sleeve='none')),
('つなぎの上','m', mk_top(KHAKI,neck='shirt',placket='shirt',buttons=2,cuff='band',pocket='chest',seam=sh(KHAKI,0.4))),
('ジャージ','m', mk_top(NAVY,tex=T_jersey,neck='turtle',placket='zip',cuff='rib',accent=WHITE)),
('タンクトップ','m', mk_top(LGRAY,tex=T_jersey,neck='boat',sleeve='none',ol=(150,150,154))),
('ラガーシャツ','m', mk_top(FOREST,tex=T_border(CREAM,44),neck='polo',cuff='band',accent=WHITE)),
]
TOPS_F=[
('ブラウス','f', mk_top(IVORY,neck='crew',frill=WHITE,cuff='band',ol=(206,196,176))),
('ボウタイブラウス','f', mk_top(CREAM,neck='crew',bow=(196,124,132),cuff='band',ol=(198,186,158))),
('パフスリーブ','f', mk_top(PINK,tex=T_jersey,neck='crew',puff=True,cuff='band',ol=(212,158,168))),
('フリルブラウス','f', mk_top(WHITE,neck='crew',frill=(238,230,234),lace_hem=(238,230,234),ol=(206,200,196))),
('リボンニット','f', mk_top(LAV,tex=T_rib(11),neck='crew',cuff='rib',hem_rib=True,ribbon=(230,214,240))),
('レーストップス','f', mk_top(OFFW,tex=T_lace,neck='crew',cuff='band',ol=(204,198,188))),
('カーディガン','f', mk_top(PINK,tex=T_rib(13),neck='crew',placket='button',buttons=4,cuff='rib',hem_rib=True,accent=WHITE)),
('ロングカーディガン','f', mk_top(CREAM,tex=T_rib(13),hem=830,neck='crew',placket='button',buttons=5,cuff='rib',accent=WHITE,ol=(200,188,164))),
('モヘアニット','f', mk_top(PEACH,tex=T_fleece,neck='crew',cuff='rib',hem_rib=True,ol=(214,166,142))),
('タートル（リブ）','f', mk_top(WINE,tex=T_rib(9),neck='turtle',cuff='rib',hem_rib=True)),
('ペプラムトップス','f', mk_top(TEAL,hem=816,drop=42,neck='boat',cuff='band')),
('キャミソール','f', mk_top(LEMON,tex=T_jersey,neck='v',sleeve='none',ol=(210,192,120))),
('チュニック','f', mk_top(SAGE,hem=842,drop=34,neck='crew',puff=True,cuff='band')),
('ギンガムブラウス','f', mk_top(WHITE,tex=T_gingham(SKY,24),neck='shirt',placket='shirt',buttons=3,cuff='band',seam=sh(SKY,0.3))),
('花柄ブラウス','f', mk_top(OFFW,tex=T_floral(ROSE,MUST,86),neck='crew',frill=WHITE,cuff='band',ol=(206,200,190))),
('ドットブラウス','f', mk_top(NAVY,tex=T_dots(WHITE,62,11),neck='crew',bow=WHITE,cuff='band')),
('レオパードニット','f', mk_top(TAN,tex=T_leopard(sh(TAN,0.30),BROWN,72),neck='crew',cuff='rib',hem_rib=True)),
('ツイードのトップス','f', mk_top(OFFW,tex=T_tweed(ROSE,SAGE),neck='boat',cuff='band',ol=(204,198,188))),
]
TOPS=TOPS_M+TOPS_F

# ══════ 下 ══════
BOTTOMS_M=[
('デニム','m', mk_bottom(DENIM,tex=T_twill,stitch_col=ORST,accent=(196,150,80),rivets=True)),
('ダメージデニム','m', mk_bottom(LTDEN,tex=T_twill,stitch_col=ORST,accent=(196,150,80),rivets=True)),
('ブラックデニム','m', mk_bottom(CHAR,tex=T_twill,stitch_col=sh(CHAR,0.5),rivets=True)),
('ワイドスラックス','m', mk_bottom(CHAR,gap=22,pocket=False,crease=True)),
('スラックス（紺）','m', mk_bottom(NAVY,gap=28,pocket=False,crease=True)),
('テーパードパンツ','m', mk_bottom(KHAKI,gap=44)),
('カーゴ','m', mk_bottom(OLIVE,cargo=True,gap=30)),
('チノ','m', mk_bottom(TAN,gap=38)),
('コーデュロイ','m', mk_bottom(BROWN,tex=T_cord(22),gap=34)),
('ジャージパンツ','m', mk_bottom(NAVY,gap=30,side_stripe=WHITE,pocket=False)),
('ショーツ','m', mk_bottom(NAVY,hem=884,gap=30)),
('ハーフパンツ','m', mk_bottom(KHAKI,hem=906,gap=34,cargo=False)),
('チェックのパンツ','m', mk_bottom(GRAY,tex=T_tartan(sh(GRAY,0.3),BLACK,54),gap=30,pocket=False)),
]
BOTTOMS_F=[
('ミディ丈スカート','f', mk_bottom(WINE,kind='skirt',hem=934,flare=0.28)),
('プリーツスカート','f', mk_bottom(SAGE,kind='skirt',hem=944,flare=0.34,pleat=30)),
('ロングスカート','f', mk_bottom(BROWN,kind='skirt',hem=988,flare=0.40)),
('ミニスカート','f', mk_bottom(LAV,kind='skirt',hem=892,flare=0.22)),
('チェックスカート','f', mk_bottom(GRAY,kind='skirt',hem=930,flare=0.30,tex=T_tartan(sh(GRAY,0.28),RED,56))),
('デニムスカート','f', mk_bottom(DENIM,kind='skirt',hem=906,flare=0.24,tex=T_twill,stitch_col=ORST)),
('フレアスカート','f', mk_bottom(PINK,kind='skirt',hem=952,flare=0.44,ol=(212,150,162))),
('チュールスカート','f', mk_bottom(OFFW,kind='skirt',hem=948,flare=0.42,tex=T_dots(WHITE,28,6),ol=(206,198,190))),
('花柄スカート','f', mk_bottom(TEAL,kind='skirt',hem=936,flare=0.32,tex=T_floral(MINT,LEMON,80))),
('コーデュロイスカート','f', mk_bottom(TERRA,kind='skirt',hem=926,flare=0.26,tex=T_cord(20))),
('ワイドパンツ','f', mk_bottom(CREAM,gap=20,pocket=False,crease=True,ol=(200,188,164))),
('レギンス','f', mk_bottom(CHAR,tex=T_rib(9),gap=50,waistband=False,loops=False,pocket=False)),
]
BOTTOMS=BOTTOMS_M+BOTTOMS_F

# ══════ 羽織り ══════
OUTER_M=[
('テーラードジャケット','m', mk_outer(CHAR,hem=846,lapel='notch',pockets='flap',chest=True,buttons=2)),
('スーツの上着','m', mk_outer(NAVY,hem=852,lapel='notch',pockets='flap',chest=True,buttons=2)),
('ツイードジャケット','m', mk_outer(CREAM,tex=T_tweed(BROWN,OLIVE),hem=838,lapel='notch',pockets='flap',
                                   chest=True,buttons=2,ol=(200,188,164))),
('デニムジャケット','m', mk_outer(DENIM,tex=T_twill,hem=816,lapel='notch',pockets='patch',
                                 stitch_col=ORST,accent=(196,150,80),buttons=0)),
('レザージャケット','m', mk_outer(BLACK,hem=818,lapel='peak',pockets=None,zipper=True,accent=(158,158,166),buttons=0)),
('ブルゾン','m', mk_outer(OLIVE,hem=816,lapel='stand',pockets='patch',open_w=92,buttons=0,zipper=True)),
('トラックジャケット','m', mk_outer(TEAL,tex=T_jersey,hem=820,lapel='stand',pockets=None,open_w=90,zipper=True,buttons=0)),
('マウンテンパーカ','m', mk_outer(SKY,hem=852,lapel='stand',pockets='flap',open_w=92,zipper=True,buttons=0,ol=(118,148,174))),
('フリース','m', mk_outer(CREAM,tex=T_fleece,hem=836,lapel='stand',pockets='patch',fur=True,buttons=0,ol=(198,186,158))),
('ダウン（パファー）','m', mk_outer(MUST,hem=862,lapel='stand',pockets=None,quilt=6,puff=True,buttons=0,zipper=True)),
('Ｍ-65（ミリタリー）','m', mk_outer(FOREST,hem=868,lapel='notch',pockets='flap',epaulet=True,belt=sh(FOREST,0.28),buttons=0)),
('トレンチコート','m', mk_outer(CAMEL,hem=922,lapel='notch',pockets='flap',double=True,belt=(150,112,68),epaulet=True,buttons=0)),
('ロングコート','m', mk_outer(NAVY,hem=948,lapel='notch',pockets='flap',buttons=3)),
('ステンカラーコート','m', mk_outer(GRAY,hem=930,lapel='stand',pockets='flap',buttons=3)),
]
OUTER_F=[
('ノーカラーコート','f', mk_outer(IVORY,hem=926,lapel='stand',pockets='patch',open_w=98,buttons=2,ol=(204,194,176))),
('チェスターコート','f', mk_outer(GRAY,hem=944,lapel='notch',pockets='flap',buttons=2)),
('ダッフルコート','f', mk_outer(CAMEL,hem=892,lapel='stand',pockets='patch',fur=False,double=True,buttons=0)),
('ファーコート','f', mk_outer(PEACH,tex=T_fleece,hem=886,lapel='stand',pockets=None,fur=True,puff=True,buttons=0,ol=(214,164,140))),
('ケープ','f', mk_outer(WINE,hem=846,lapel='stand',pockets=None,open_w=88,puff=True,buttons=0)),
('ショートジャケット','f', mk_outer(ROSE,hem=800,lapel='notch',pockets=None,buttons=1,accent=li(ROSE,0.35))),
('ツイードジャケット（女）','f', mk_outer(OFFW,tex=T_tweed(ROSE,SAGE),hem=828,lapel='stand',pockets='patch',
                                        buttons=2,ol=(204,196,184))),
('ガウン','f', mk_outer(PURPLE,hem=964,lapel='stand',pockets='patch',open_w=110,belt=sh(PURPLE,0.28),buttons=0)),
('カーディガン（羽織）','f', mk_outer(MINT,tex=T_rib(13),hem=906,lapel='stand',pockets='patch',open_w=98,buttons=0,ol=(138,176,156))),
('レースの羽織り','f', mk_outer(WHITE,tex=T_lace,hem=914,lapel='stand',pockets=None,open_w=104,buttons=0,ol=(206,200,192))),
('キルティング','f', mk_outer(SAGE,hem=856,lapel='stand',pockets='flap',quilt=7,buttons=0,zipper=True)),
]
OUTER=OUTER_M+OUTER_F

NECK=[
('マフラー','u', neckwear('muffler',WINE)),
('チェックのマフラー','u', neckwear('muffler',CREAM,sh(CREAM,0.2),ol=(196,182,156))),
('ストール','f', neckwear('stole',SAGE)),
('ネクタイ','m', neckwear('tie',NAVY)),
('蝶ネクタイ','m', neckwear('bowtie',BLACK)),
('リボン','f', neckwear('ribbon',ROSE)),
('ネックレス','f', neckwear('necklace',GOLD)),
('パールのくび飾り','f', neckwear('pearl',(242,238,230),ol=(196,190,178))),
('スカーフ','f', neckwear('scarf',TERRA)),
('チョーカー','f', neckwear('choker',BLACK)),
('フード（下ろした）','u', neckwear('hood_down',CHAR)),
]
EYES=[
('メガネ（丸）','u', eyewear('round',CHAR)),
('メガネ（四角）','u', eyewear('square',BROWN)),
('金ぶちメガネ','u', eyewear('round',GOLD)),
('サングラス','u', eyewear('sun',BLACK,lens=(40,40,48))),
('伊達メガネ','f', eyewear('square',ROSE)),
('ゴーグル','u', eyewear('goggle',BROWN,lens=(180,205,215))),
]

# ══════ 追加（系統をひろげる）══════
TOPS_M += [
('ヘンリーネック','m', mk_top(CREAM,tex=T_jersey,neck='crew',placket='button',buttons=2,cuff='band',ol=(200,188,164))),
('モックネック','m', mk_top(GRAY,tex=T_rib(11),neck='turtle',cuff='rib',hem_rib=True)),
('ラグランＴ','m', mk_top(WHITE,tex=T_jersey,neck='crew',sleeve='short',cuff='band',ol=(194,190,180))),
('アロハシャツ','m', mk_top(TEAL,tex=T_floral(CREAM,MUST,84),neck='shirt',placket='shirt',buttons=3,sleeve='short',cuff='band')),
('甚平の上','m', mk_top(INDIGO,neck='v',sleeve='short',cuff=None,placket='button')),
('パジャマ','m', mk_top(SKY,tex=T_stripe_v(WHITE,30),neck='shirt',placket='shirt',buttons=3,cuff='band',seam=sh(SKY,0.3))),
('ミリタリーシャツ','m', mk_top(KHAKI,neck='shirt',placket='shirt',yoke=True,buttons=3,cuff='band',pocket='chest',seam=sh(KHAKI,0.42))),
('ビッグシルエットＴ','m', mk_top(BLACK,tex=T_jersey,hem=822,drop=26,neck='crew',sleeve='short',cuff='band')),
('スポーツＴ','m', mk_top(TEAL,tex=T_pique,neck='crew',sleeve='short',cuff='band',accent=WHITE)),
]
TOPS_F += [
('オフショル','f', mk_top(ROSE,tex=T_jersey,neck='boat',puff=True,cuff='band')),
('ニットベスト','f', mk_top(MUST,tex=T_cable(40),neck='v',sleeve='none')),
('セーラー風','f', mk_top(WHITE,neck='boat',cuff='band',bow=(60,80,140),ol=(194,190,180))),
('黒レースブラウス','f', mk_top(BLACK,tex=T_lace,neck='crew',frill=(90,88,96),cuff='band')),
('Ｙ２Ｋトップス','f', mk_top(LAV,tex=T_dots(WHITE,40,7),neck='boat',sleeve='short',cuff='band')),
('韓国系ゆるニット','f', mk_top(CREAM,tex=T_garter(15),hem=826,drop=30,neck='crew',cuff='rib',ol=(200,188,164))),
('もこもこパジャマ','f', mk_top(PINK,tex=T_fleece,neck='crew',placket='button',buttons=3,cuff='rib',hem_rib=True,accent=WHITE)),
('ボヘミアンブラウス','f', mk_top(IVORY,tex=T_tweed(TERRA,SAGE),neck='v',puff=True,cuff='band',ol=(204,194,176))),
('レザートップス','f', mk_top(BLACK,neck='turtle',cuff='band',accent=(150,150,158))),
]
BOTTOMS_M += [
('スウェットパンツ','m', mk_bottom(GRAY,tex=T_jersey,gap=30,waistband=False,loops=False,pocket=False,hem_band=sh(GRAY,0.16))),
('パジャマパンツ','m', mk_bottom(SKY,tex=T_stripe_v(WHITE,30),gap=32,loops=False,pocket=False)),
('ミリタリーパンツ','m', mk_bottom(KHAKI,cargo=True,gap=28,tex=T_check(sh(KHAKI,0.10),46))),
('甚平の下','m', mk_bottom(INDIGO,hem=896,gap=36,loops=False,pocket=False)),
('スキニー','m', mk_bottom(BLACK,tex=T_twill,gap=52,stitch_col=sh(BLACK,0.0))),
]
BOTTOMS_F += [
('サロペット','f', mk_bottom(DENIM,tex=T_twill,gap=26,stitch_col=ORST,accent=(196,150,80))),
('ガウチョ','f', mk_bottom(SAGE,hem=914,gap=18,pocket=False,crease=True)),
('ペチコート','f', mk_bottom(WHITE,kind='skirt',hem=956,flare=0.36,tex=T_lace,ol=(206,200,192))),
('レザースカート','f', mk_bottom(BLACK,kind='skirt',hem=898,flare=0.20)),
('もこもこパンツ','f', mk_bottom(PINK,tex=T_fleece,gap=30,waistband=False,loops=False,pocket=False)),
]
OUTER_M += [
('ＭＡ-1','m', mk_outer(OLIVE,hem=814,lapel='stand',pockets='flap',open_w=90,zipper=True,buttons=0,accent=(198,80,72))),
('スタジャン','m', mk_outer(NAVY,hem=818,lapel='stand',pockets='patch',open_w=92,double=True,buttons=0,accent=CREAM)),
('半纏','m', mk_outer(INDIGO,tex=T_check(sh(INDIGO,0.12),44),hem=856,lapel='stand',pockets=None,open_w=96,buttons=0)),
('ベンチコート','m', mk_outer(BLACK,hem=966,lapel='stand',pockets='flap',quilt=8,puff=True,buttons=0,zipper=True)),
('ジレ','m', mk_outer(GRAY,hem=830,lapel='notch',pockets=None,buttons=2)),
]
OUTER_F += [
('ポンチョ','f', mk_outer(TERRA,tex=T_tweed(CREAM,BROWN),hem=902,lapel='stand',pockets=None,open_w=92,puff=True,buttons=0)),
('ムートン','f', mk_outer(CREAM,tex=T_fleece,hem=874,lapel='stand',pockets='patch',fur=True,buttons=0,ol=(198,186,158))),
('ライダース（女）','f', mk_outer(WINE,hem=804,lapel='peak',pockets=None,zipper=True,buttons=0,accent=(180,180,188))),
('ロングガウン','f', mk_outer(LAV,tex=T_rib(15),hem=976,lapel='stand',pockets='patch',open_w=104,belt=sh(LAV,0.28),buttons=0)),
('ゴシックコート','f', mk_outer(BLACK,hem=952,lapel='peak',pockets='flap',double=True,buttons=0,accent=(160,140,180))),
]
TOPS=TOPS_M+TOPS_F
BOTTOMS=BOTTOMS_M+BOTTOMS_F
OUTER=OUTER_M+OUTER_F

# ══════ 靴（新スロット）══════
import shoes2 as _S
SHOES=[
('スニーカー','u',4,_S.shoes('sneaker',WHITE,sole=(214,210,200),accent=(150,150,156),ol=(186,182,172))),
('ハイカット','u',6,_S.shoes('high',RED,sole=(238,234,224),accent=WHITE)),
('ローファー','u',4,_S.shoes('loafer',BROWN,accent=GOLD)),
('革靴','m',4,_S.shoes('dress',BLACK,accent=(150,150,158))),
('ブーツ','u',6,_S.shoes('boot',TAN,accent=(150,112,68))),
('ロングブーツ','f',6,_S.shoes('longboot',BLACK,accent=(150,150,158))),
('サンダル','u',4,_S.shoes('sandal',TAN,sole=(150,112,68))),
('上履き','u',4,_S.shoes('uwabaki',WHITE,sole=(214,210,200),accent=(160,190,210),ol=(186,182,172))),
('スリッパ','u',4,_S.shoes('slipper',PINK,sole=(200,140,150),accent=WHITE)),
('長ぐつ','u',6,_S.shoes('rain',MUST,sole=(160,124,50),accent=(238,220,150))),
('パンプス','f',4,_S.shoes('pumps',NAVY,accent=GOLD)),
('ミュール','f',4,_S.shoes('mule',CREAM,sole=(180,166,140),ol=(198,186,158))),
]

# ══════ 帽子（新スロット）══════
import hats3 as _Hh
HATS=[
('キャップ','u',_Hh.hat('cap',NAVY,accent=WHITE)),
('ニット帽','u',_Hh.hat('knit',RED,accent=WHITE)),
('ベレー','u',_Hh.hat('beret',BLACK)),
('中折れハット','m',_Hh.hat('hat',BROWN,accent=(90,64,46))),
('バケット','u',_Hh.hat('bucket',OLIVE)),
('麦わら帽子','u',_Hh.hat('straw',(226,196,132),band=RED,ol=(190,160,100))),
('イヤーマフ','u',_Hh.hat('earmuff',PINK,band=(180,120,130))),
('カチューシャ','f',_Hh.hat('ribbon',LAV,accent=(212,190,232))),
('フード','u',_Hh.hat('hood',GRAY)),
('王冠','u',_Hh.hat('crown',GOLD,accent=(190,70,70))),
('ヘアバンド','f',_Hh.hat('headband',SAGE)),
('サンタ帽','u',_Hh.hat('santa',RED,accent=WHITE)),
('コック帽','u',_Hh.hat('chef',WHITE,ol=(202,198,188))),
]
