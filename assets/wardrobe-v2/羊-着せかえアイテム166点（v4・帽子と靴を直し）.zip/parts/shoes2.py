# -*- coding: utf-8 -*-
"""靴 ── 足パーツ（feet.py）の座標に合わせる。足の子として動く"""
from PIL import Image, ImageDraw, ImageFilter
import numpy as np, math
W=H=1024
CXs={'L':421,'R':601}
FB=1002          # 足の下端
FW=114           # 足の幅
def sh(c,d): return tuple(max(0,int(v*(1-d))) for v in c)
def li(c,d): return tuple(min(255,int(v+(255-v)*d)) for v in c)
def new(): return Image.new('RGBA',(W,H),(0,0,0,0))
def outline(img,col,w=7):
    a=np.array(img); m=(a[:,:,3]>10).astype('uint8')*255
    mi=Image.fromarray(m).filter(ImageFilter.MinFilter(w))
    a[(m>0)&(np.array(mi)==0)]=(*col,255); return Image.fromarray(a)

def shoes(kind, col, sole=None, accent=None, top=None, ol=None):
    """kind: sneaker/high/loafer/dress/boot/longboot/sandal/uwabaki/
             slipper/rain/pumps/mule"""
    sole = sole or sh(col,0.42)
    acc  = accent or li(col,0.55)
    im=new(); d=ImageDraw.Draw(im)
    for s in ('L','R'):
        cx=CXs[s]; m=1 if s=='R' else -1
        HW=FW//2+8                                   # 足より8px 大きい
        if kind=='sneaker':
            d.rounded_rectangle([cx-HW,FB-64,cx+HW,FB+4],26,fill=(*col,255))
            d.rounded_rectangle([cx-HW,FB-22,cx+HW,FB+6],13,fill=(*sole,255))
            d.line([(cx-HW+8,FB-34),(cx+HW-8,FB-34)],fill=(*acc,255),width=5)
            for k in range(3):
                d.line([(cx-26,FB-58+k*11),(cx+26,FB-58+k*11)],fill=(*acc,255),width=4)
        elif kind=='high':
            d.rounded_rectangle([cx-HW,FB-124,cx+HW,FB+4],24,fill=(*col,255))
            d.rounded_rectangle([cx-HW,FB-22,cx+HW,FB+6],13,fill=(*sole,255))
            for k in range(5):
                yy=FB-116+k*20
                d.line([(cx-30,yy),(cx+30,yy)],fill=(*acc,255),width=4)
                d.ellipse([cx-34,yy-4,cx-26,yy+4],fill=(*acc,255))
                d.ellipse([cx+26,yy-4,cx+34,yy+4],fill=(*acc,255))
        elif kind=='loafer':
            d.rounded_rectangle([cx-HW,FB-58,cx+HW,FB+2],22,fill=(*col,255))
            d.rounded_rectangle([cx-HW,FB-16,cx+HW,FB+4],9,fill=(*sole,255))
            d.arc([cx-40,FB-64,cx+40,FB-18],200,340,fill=(*sh(col,0.28),255),width=6)
            d.rounded_rectangle([cx-26,FB-46,cx+26,FB-34],5,fill=(*acc,255))
        elif kind=='dress':
            d.rounded_rectangle([cx-HW,FB-56,cx+HW,FB+2],16,fill=(*col,255))
            d.rounded_rectangle([cx-HW,FB-14,cx+HW,FB+4],7,fill=(*sole,255))
            d.line([(cx-HW+10,FB-42),(cx+HW-10,FB-42)],fill=(*sh(col,0.34),255),width=4)
            d.ellipse([cx-9,FB-38,cx+9,FB-20],fill=(*acc,255))
        elif kind in ('boot','longboot','rain'):
            hgt = 126 if kind=='boot' else (206 if kind=='longboot' else 162)
            SW  = HW-16                                   # 筒は足より細い
            # 筒
            d.rounded_rectangle([cx-SW,FB-hgt,cx+SW,FB-46],14,fill=(*sh(col,0.06),255))
            # 履き口の折り返し
            d.rounded_rectangle([cx-SW-11,FB-hgt-10,cx+SW+11,FB-hgt+30],13,fill=(*acc,255))
            d.arc([cx-SW-11,FB-hgt-10,cx+SW+11,FB-hgt+30],180,360,fill=(*sh(acc,0.22),255),width=4)
            # 甲（足の部分。筒より太い）
            d.rounded_rectangle([cx-HW,FB-74,cx+HW,FB+2],26,fill=(*col,255))
            d.arc([cx-HW,FB-74,cx+HW,FB+2],180,300,fill=(*li(col,0.16),255),width=6)
            # 足首の切り替え
            d.line([(cx-SW,FB-52),(cx+SW,FB-52)],fill=(*sh(col,0.24),255),width=4)
            # ソール（かかとを少し厚く）
            d.rounded_rectangle([cx-HW-2,FB-20,cx+HW+2,FB+6],11,fill=(*sole,255))
            d.rounded_rectangle([cx+m*(HW-30)-22,FB-30,cx+m*(HW-30)+22,FB+6],8,fill=(*sole,255))
            if kind=='longboot':
                d.line([(cx-SW,FB-hgt+64),(cx+SW,FB-hgt+64)],fill=(*sh(col,0.16),255),width=3)
            if kind=='rain':
                d.line([(cx-SW,FB-92),(cx+SW,FB-92)],fill=(*acc,255),width=8)
        elif kind=='sandal':
            d.rounded_rectangle([cx-HW,FB-18,cx+HW,FB+4],11,fill=(*sole,255))
            d.line([(cx-HW+10,FB-46),(cx+HW-10,FB-24)],fill=(*col,255),width=15)
            d.line([(cx+HW-10,FB-46),(cx-HW+10,FB-24)],fill=(*col,255),width=15)
        elif kind=='uwabaki':
            d.rounded_rectangle([cx-HW,FB-56,cx+HW,FB+2],22,fill=(*col,255))
            d.rounded_rectangle([cx-HW,FB-16,cx+HW,FB+4],9,fill=(*sole,255))
            d.arc([cx-46,FB-70,cx+46,FB-14],200,340,fill=(*acc,255),width=11)
        elif kind=='slipper':
            d.rounded_rectangle([cx-HW,FB-26,cx+HW,FB+4],13,fill=(*sole,255))
            d.pieslice([cx-HW,FB-70,cx+HW,FB-2],180,360,fill=(*col,255))
            d.ellipse([cx-16,FB-52,cx+16,FB-26],fill=(*acc,255))
        elif kind=='pumps':
            # 甲（つま先の丸み）
            d.pieslice([cx-HW+4,FB-82,cx+HW-4,FB-2],180,360,fill=(*col,255))
            # 履き口（甲の開き）
            d.ellipse([cx-40,FB-84,cx+40,FB-48],fill=(*sh(col,0.26),255))
            d.ellipse([cx-32,FB-80,cx+32,FB-54],fill=(*li(col,0.06),255))
            # ソール（★下に飛び出さない。後ろを少し厚くするだけ）
            d.rounded_rectangle([cx-HW+2,FB-16,cx+HW-2,FB+4],9,fill=(*sole,255))
            d.rounded_rectangle([cx+m*(HW-34)-24,FB-30,cx+m*(HW-34)+24,FB+4],8,fill=(*sole,255))
            # 飾り
            d.ellipse([cx-11,FB-70,cx+11,FB-52],fill=(*acc,255))
        elif kind=='mule':
            d.rounded_rectangle([cx-HW,FB-20,cx+HW,FB+4],11,fill=(*sole,255))
            d.pieslice([cx-HW,FB-64,cx+HW,FB-4],180,300,fill=(*col,255))
        if top:  # 靴下
            d.rounded_rectangle([cx-FW//2+4,FB-104,cx+FW//2-4,FB-52],16,fill=(*top,255))
    return outline(im,ol) if ol else im
