# -*- coding: utf-8 -*-
"""歩ける足パーツ ── 羊と同じ1024座標系。体の下に生やす"""
from PIL import Image, ImageDraw, ImageFilter
import numpy as np
W=H=1024
WOOL=(237,228,206); WOOL_L=(246,239,223); WOOL_D=(229,219,193); LINE=(206,192,164)
FOOT_CX={'L':421,'R':601}
FOOT_TOP=926          # 上端（体の下端952より26px 上＝のりしろ）
FOOT_BOT=1002         # 下端
FOOT_W=114            # 足の横幅
ANKLE_W=62            # 脚（足首）の幅
GROUND=1006           # 接地線

def foot(side, col=WOOL, shadow=WOOL_D, hi=WOOL_L, line=LINE):
    cx=FOOT_CX[side]
    im=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(im)
    # 脚（上ののりしろ。体に隠れる）
    d.rounded_rectangle([cx-ANKLE_W//2, FOOT_TOP, cx+ANKLE_W//2, FOOT_BOT-34], 26, fill=(*col,255))
    # 足（楕円）
    d.ellipse([cx-FOOT_W//2, FOOT_BOT-72, cx+FOOT_W//2, FOOT_BOT], fill=(*col,255))
    # 下の影と上の光
    d.chord([cx-FOOT_W//2, FOOT_BOT-72, cx+FOOT_W//2, FOOT_BOT], 20,160, fill=(*shadow,255))
    d.ellipse([cx-FOOT_W//2+14, FOOT_BOT-66, cx+FOOT_W//2-30, FOOT_BOT-38], fill=(*hi,255))
    # ふちどり
    a=np.array(im); m=(a[:,:,3]>10).astype('uint8')*255
    mi=Image.fromarray(m).filter(ImageFilter.MinFilter(7))
    a[(m>0)&(np.array(mi)==0)]=(*line,255)
    im=Image.fromarray(a)
    # のりしろ（y<952）は体に隠れるので、そのまま残す
    return im

def foot_shadow(side, w=96, h=20, alpha=90):
    cx=FOOT_CX[side]
    im=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.ellipse([cx-w//2, GROUND-h//2, cx+w//2, GROUND+h//2], fill=(90,84,74,alpha))
    return im.filter(ImageFilter.GaussianBlur(6))

if __name__=='__main__':
    import os
    os.makedirs('/home/claude/out/feet',exist_ok=True)
    for s in ('L','R'):
        foot(s).save(f'/home/claude/out/feet/foot_{s}@2x.png')
        foot_shadow(s).save(f'/home/claude/out/feet/foot_shadow_{s}@2x.png')
    print('ok')
