# -*- coding: utf-8 -*-
"""服の作画エンジン v2 ── 縫製のディテールと生地の質感を持つ
   参考：シャツ（ヨーク・前立て・台襟・カフス・剣ボロ）／編み地（天竺・リブ・ガーター・
   ケーブル・鹿の子）／ジャケット（ゴージライン・ノッチドラペル・フラップポケット）／
   デニム（オレンジのステッチ・リベット・コインポケット・ベルトループ）"""
from PIL import Image, ImageDraw, ImageFilter
import numpy as np, math, random

A,B,C,FLAT=-0.00237595,2.49995,-58.78,490.0
CX=511; EY,ERX,ERY=660,268,300
WAIST_TOP=752; WAIST_BOT=792
def jaw(x): return max(A*x*x+B*x+C,FLAT)
orig=Image.open('orig_sheep.png').convert('RGBA')
head=Image.open('sheepparts2/sheep_head.png').convert('RGBA')
body=Image.open('sheepparts2/sheep_body.png').convert('RGBA')
W,H=orig.size; SIL=np.array(orig)[:,:,3]
_BIG=np.array(Image.fromarray(SIL).filter(ImageFilter.MaxFilter(21)))
EYE_L=(442,395); EYE_R=(581,395)

def sh(c,d): return tuple(max(0,int(v*(1-d))) for v in c)
def li(c,d): return tuple(min(255,int(v+(255-v)*d)) for v in c)
def new(): return Image.new('RGBA',(W,H),(0,0,0,0))
def clip(l,big=False):
    a=np.array(l); s=_BIG if big else SIL
    a[:,:,3]=(a[:,:,3].astype(int)*s.astype(int)//255).astype('uint8')
    return Image.fromarray(a)
def torso_hw(y):
    t=1-((y-EY)/ERY)**2
    return ERX*math.sqrt(t) if t>0 else 0.0
def shoulder(x,drop=150): return 592-drop*((x-CX)/300.0)**2
def top_y(x,drop=150):    return max(jaw(x)-14, shoulder(x,drop))
def arm_seam(y):
    """アームホール（身頃と袖の境目）。肩で広く、脇で狭い"""
    t=min(1.0,max(0.0,(y-516)/210.0))
    return 250-60*t
def outline(img,col,w=9):
    a=np.array(img); m=(a[:,:,3]>10).astype('uint8')*255
    mi=Image.fromarray(m).filter(ImageFilter.MinFilter(w))
    a[(m>0)&(np.array(mi)==0)]=(*col,255); return Image.fromarray(a)

# ══════════ 生地の質感 ══════════
def T_plain(x,y,c): return c
def T_jersey(x,y,c):                      # 天竺：V字の細かい目
    return li(c,0.05) if ((y//7)%2==0 and (x+ (y//7)*4)%14<2) else c
def T_rib(w=11):                          # リブ：縦の筋
    return lambda x,y,c: (sh(c,0.13) if (x//w)%2 else li(c,0.05))
def T_garter(w=13):                       # ガーター：横の畝
    return lambda x,y,c: (sh(c,0.11) if (y//w)%2 else li(c,0.06))
def T_cable(w=44):                        # ケーブル：縄編み（2本が交差する）
    def f(x,y,c):
        u=(x%w)/w
        if u<0.09 or u>0.91: return sh(c,0.28)      # 縄の間の溝
        p=(y%58)/58.0
        s1=0.5+0.30*math.sin(2*math.pi*p)
        s2=0.5-0.30*math.sin(2*math.pi*p)
        d1=abs(u-s1); d2=abs(u-s2)
        if min(d1,d2)<0.085: return li(c,0.16)      # 縄の峰
        if min(d1,d2)>0.30:  return sh(c,0.14)      # 谷
        return c
    return f
def T_pique(x,y,c):                       # 鹿の子：細かい粒
    return li(c,0.10) if ((x//6+y//6)%2==0 and (x*y)%3==0) else c
def T_cord(w=22):                         # コーデュロイ：太い縦の畝
    def f(x,y,c):
        u=(x%w)/w
        return li(c,0.13) if 0.30<u<0.55 else (sh(c,0.18) if u<0.10 else c)
    return f
def T_twill(x,y,c):                       # デニム：右上がりの綾
    return li(c,0.10) if ((x+y*2)%9)<2 else (sh(c,0.05) if ((x+y*2)%9)>7 else c)
def T_tweed(c2,c3):
    def f(x,y,c):
        h=(x*7919+y*104729)%1000
        if h<28: return c2
        if h<52: return c3
        return c
    return f
def T_fleece(x,y,c):
    h=(x*2654435761+y*40503)%997
    return li(c,0.11) if h<180 else (sh(c,0.07) if h>860 else c)
def T_lace(x,y,c):
    return None if (((x%26)-13)**2+((y%26)-13)**2)<20 else c
def T_check(c2,w=52): return lambda x,y,c:(c2 if ((x//w)%2==0)^((y//w)%2==0) else c)
def T_tartan(c2,c3,w=64):
    def f(x,y,c):
        a_=(x%w)<17; b_=(y%w)<17
        if a_ and b_: return c3
        return c2 if (a_ or b_) else c
    return f
def T_gingham(c2,w=26): return lambda x,y,c:(c2 if ((x//w)%2==0)^((y//w)%2==0) else (li(c2,0.5) if (x//w)%2==0 else c))
def T_border(c2,w=30): return lambda x,y,c:(c2 if (y//w)%2==0 else c)
def T_stripe_v(c2,w=26): return lambda x,y,c:(c2 if (x//w)%2==0 else c)
def T_dots(c2,step=76,r=13):
    return lambda x,y,c:(c2 if ((x%step-step//2)**2+(y%step-step//2)**2)<r*r else c)
def T_floral(c2,c3,step=88):
    def f(x,y,c):
        u=x%step-step//2; v=y%step-step//2; d=u*u+v*v
        if d<70: return c3
        for k in range(5):
            th=k*2*math.pi/5
            if (u-26*math.cos(th))**2+(v-26*math.sin(th))**2<190: return c2
        return c
    return f
def T_leopard(c2,c3,step=74):
    def f(x,y,c):
        u=x%step-step//2; v=(y%step)-step//2
        d=u*u*1.4+v*v
        if d<210: return c3
        if d<420: return c2
        return c
    return f

# ══════════ 縫い目・ステッチ ══════════
def stitch(d,pts,col,dash=13,gap=9,w=4):
    for i in range(len(pts)-1):
        (x0,y0),(x1,y1)=pts[i],pts[i+1]
        L=math.hypot(x1-x0,y1-y0); n=max(1,int(L//(dash+gap)))
        for k in range(n):
            t0=k*(dash+gap)/L; t1=min(1,(k*(dash+gap)+dash)/L)
            d.line([(x0+(x1-x0)*t0,y0+(y1-y0)*t0),(x0+(x1-x0)*t1,y0+(y1-y0)*t1)],fill=(*col,255),width=w)
def stitch_arc(d,box,a0,a1,col,w=4,seg=26):
    x0,y0,x1,y1=box; cx=(x0+x1)/2; cy=(y0+y1)/2; rx=(x1-x0)/2; ry=(y1-y0)/2
    pts=[]
    for k in range(seg+1):
        th=math.radians(a0+(a1-a0)*k/seg)
        pts.append((cx+rx*math.cos(th),cy+ry*math.sin(th)))
    stitch(d,pts,col,w=w)

# ══════════ 上（トップス）══════════
def mk_top(col, tex=T_plain, hem=WAIST_BOT, drop=22, sleeve='long', cuff='rib',
           neck='crew', placket=None, yoke=False, hem_rib=False, pocket=None,
           buttons=0, accent=None, sdrop=150, ol=None, seam=None, puff=False,
           frill=None, lace_hem=None, bow=None, ribbon=None, shading=0.30):
    acc = accent or sh(col,0.22)
    seam_col = seam or sh(col,0.30)
    def hemc(x):
        u=(x-CX)/262.0
        return hem+drop*max(0.0,1-u*u)
    a=np.zeros((H,W,4),dtype=np.uint8)
    y0=int(FLAT)-30; y1=int(hem+drop)+2
    for y in range(max(0,y0),min(H,y1)):
        hw=torso_hw(y)
        if hw<=0: continue
        asx=arm_seam(y)
        for x in range(int(CX-hw),int(CX+hw)+1):
            t=top_y(x,sdrop); b=hemc(x)
            if y<t or y>b: continue
            dx=abs(x-CX); is_sleeve = (sleeve!='none') and dx>asx
            if sleeve=='none' and dx>asx+6: 
                pass  # ノースリーブでも身頃は肩まで
            if sleeve=='short' and is_sleeve and y>708: continue
            c=tex(x,y,col)
            if c is None: continue
            # 丸みの陰影（端ほど暗く）
            u=dx/max(1.0,hw)
            c=sh(c, shading*(u**2.2))
            if is_sleeve: c=sh(c,0.07)
            if y<t+52: c=li(c,0.13*(1-(y-t)/52.0))     # 肩の光
            if y>b-24: c=sh(c,0.16)                     # 裾の影
            a[y,x]=(*c,255)
    l=Image.fromarray(a); d=ImageDraw.Draw(l)
    j=int(jaw(CX))

    # ── アームホールの縫い目
    if sleeve!='none':
        for s in(-1,1):
            pts=[(CX+s*arm_seam(y), y) for y in range(int(top_y(CX+s*250,sdrop)), 
                 min(int(hemc(CX+s*230)), 720 if sleeve=='short' else int(hemc(CX+s*230))),6)]
            if len(pts)>1: stitch(d,pts,seam_col,w=3)
    # ── 袖口
    if sleeve!='none' and cuff:
        cy = 700 if sleeve=='short' else int(hem-6)
        ch = 34 if sleeve=='short' else 62
        for s in(-1,1):
            x0=CX+s*int(arm_seam(cy)); x1=CX+s*int(torso_hw(cy)+4)
            box=[min(x0,x1),cy-ch,max(x0,x1),cy]
            if cuff=='rib':
                d.rectangle(box,fill=(*sh(col,0.12),255))
                for xx in range(int(box[0]),int(box[2]),9):
                    d.line([(xx,box[1]),(xx,box[3])],fill=(*sh(col,0.26),255),width=3)
            else:
                d.rectangle(box,fill=(*sh(col,0.16),255))
                stitch(d,[(box[0],box[1]+7),(box[2],box[1]+7)],seam_col,w=3)
                d.ellipse([ (box[0]+box[2])/2-9,(box[1]+box[3])/2-9,
                            (box[0]+box[2])/2+9,(box[1]+box[3])/2+9],fill=(*acc,255))
    # ── 裾のリブ
    if hem_rib:
        for x in range(int(CX-torso_hw(hem)),int(CX+torso_hw(hem))):
            pass
        box=[CX-300,hem-44,CX+300,int(hemc(CX))]
        d.rectangle(box,fill=(*sh(col,0.12),255))
        for xx in range(box[0],box[2],9):
            d.line([(xx,box[1]),(xx,box[3])],fill=(*sh(col,0.26),255),width=3)
    # ── ヨーク（シャツ）
    if yoke:
        stitch(d,[(CX-240,j+96),(CX+240,j+96)],seam_col,w=3)
    # ── 前立て
    if placket=='shirt':
        d.rectangle([CX-21,j-6,CX+21,int(hemc(CX))],fill=(*li(col,0.06),255))
        stitch(d,[(CX-21,j-6),(CX-21,hemc(CX))],seam_col,w=3)
        stitch(d,[(CX+21,j-6),(CX+21,hemc(CX))],seam_col,w=3)
    elif placket=='button':
        stitch(d,[(CX,j+20),(CX,hemc(CX)-16)],seam_col,w=3)
    elif placket=='zip':
        d.line([(CX,j+8),(CX,hemc(CX)-12)],fill=(*sh(col,0.34),255),width=13)
        for yy in range(j+10,int(hemc(CX))-12,11):
            d.line([(CX-7,yy),(CX+7,yy)],fill=(*li(col,0.45),255),width=3)
        d.rounded_rectangle([CX-13,hem-104,CX+13,hem-58],7,fill=(*li(col,0.62),255))
    for i in range(buttons):
        yy=j+112+i*76
        if yy>hemc(CX)-24: break
        d.ellipse([CX-15,yy-15,CX+15,yy+15],fill=(*li(acc,0.5),255))
        d.ellipse([CX-15,yy-15,CX+15,yy+15],outline=(*sh(acc,0.2),255),width=3)
        for k in(-5,5): d.ellipse([CX+k-3,yy-3,CX+k+3,yy+3],fill=(*sh(acc,0.4),255))
    # ── ポケット
    if pocket=='kangaroo':
        d.arc([CX-190,j+180,CX+190,j+420],14,166,fill=(*sh(col,0.22),255),width=7)
        stitch(d,[(CX-186,j+266),(CX-150,j+218)],seam_col,w=3)
        stitch(d,[(CX+186,j+266),(CX+150,j+218)],seam_col,w=3)
    elif pocket=='chest':
        d.rectangle([CX-186,j+124,CX-96,j+220],outline=(*seam_col,255),width=4)
        stitch(d,[(CX-186,j+134),(CX-96,j+134)],seam_col,w=3)
    # ── 襟
    if neck=='crew':
        d.arc([CX-124,j-40,CX+124,j+104],196,344,fill=(*sh(col,0.18),255),width=17)
        d.arc([CX-124,j-34,CX+124,j+110],196,344,fill=(*li(col,0.10),255),width=5)
    elif neck=='shirt':
        st=li(col,0.04)
        d.rounded_rectangle([CX-104,j-46,CX+104,j+22],16,fill=(*st,255))   # 台襟
        d.polygon([(CX-8,j-30),(CX-126,j-14),(CX-150,j+66),(CX-14,j+22)],fill=(*li(col,0.10),255))
        d.polygon([(CX+8,j-30),(CX+126,j-14),(CX+150,j+66),(CX+14,j+22)],fill=(*li(col,0.10),255))
        stitch(d,[(CX-8,j-30),(CX-126,j-14),(CX-150,j+66)],seam_col,w=3)
        stitch(d,[(CX+8,j-30),(CX+126,j-14),(CX+150,j+66)],seam_col,w=3)
    elif neck=='polo':
        st=li(col,0.05)
        d.polygon([(CX-14,j-24),(CX-116,j-10),(CX-130,j+56),(CX-16,j+18)],fill=(*st,255))
        d.polygon([(CX+14,j-24),(CX+116,j-10),(CX+130,j+56),(CX+16,j+18)],fill=(*st,255))
        d.rectangle([CX-24,j-18,CX+24,j+112],fill=(*li(col,0.03),255))
        stitch(d,[(CX-24,j-18),(CX-24,j+112)],seam_col,w=3)
        stitch(d,[(CX+24,j-18),(CX+24,j+112)],seam_col,w=3)
        for i in range(2):
            yy=j+34+i*52
            d.ellipse([CX-11,yy-11,CX+11,yy+11],fill=(*li(acc,0.55),255))
    elif neck=='turtle':
        d.rounded_rectangle([CX-118,j-70,CX+118,j+46],38,fill=(*li(col,0.08),255))
        for xx in range(CX-118,CX+118,10):
            d.line([(xx,j-66),(xx,j+44)],fill=(*sh(col,0.16),255),width=3)
        d.arc([CX-118,j-4,CX+118,j+86],200,340,fill=(*sh(col,0.24),255),width=6)
    elif neck=='v':
        d.polygon([(CX-104,j-22),(CX+104,j-22),(CX,j+128)],fill=(*sh(col,0.34),255))
        d.line([(CX-104,j-22),(CX,j+128),(CX+104,j-22)],fill=(*li(col,0.14),255),width=13)
    elif neck=='boat':
        d.arc([CX-168,j-58,CX+168,j+64],186,354,fill=(*li(col,0.12),255),width=13)
    elif neck=='hood':
        d.pieslice([CX-186,j-146,CX+186,j+136],188,352,fill=(*sh(col,0.16),255))
        d.arc([CX-186,j-146,CX+186,j+136],188,352,fill=(*sh(col,0.34),255),width=7)
        d.pieslice([CX-140,j-104,CX+140,j+112],192,348,fill=(*sh(col,0.34),255))
        for s in(-1,1):
            d.line([(CX+s*46,j+72),(CX+s*32,j+196)],fill=(*li(col,0.66),255),width=11)
            d.ellipse([CX+s*32-9,j+190,CX+s*32+9,j+208],fill=(*sh(col,0.4),255))
    # ── 女性寄りの装飾
    if puff:
        for s in(-1,1):
            xx=CX+s*248; ty=int(top_y(xx,sdrop))
            d.pieslice([xx-104,ty-24,xx+104,ty+196],180,360,fill=(*li(col,0.07),255))
            stitch_arc(d,[xx-104,ty-24,xx+104,ty+196],182,358,seam_col,w=3)
    if frill:
        for k in range(11):
            xx=CX-190+k*38
            d.pieslice([xx-30,j-14,xx+30,j+62],0,180,fill=(*frill,255))
            d.arc([xx-30,j-14,xx+30,j+62],10,170,fill=(*sh(frill,0.18),255),width=4)
    if lace_hem:
        for k in range(16):
            xx=CX-296+k*40
            d.pieslice([xx-24,hem+drop-46,xx+24,hem+drop+14],0,180,fill=(*lace_hem,255))
    if bow:
        for s in(-1,1):
            d.polygon([(CX,j+54),(CX+s*94,j+12),(CX+s*94,j+94)],fill=(*bow,255))
            d.polygon([(CX,j+54),(CX+s*94,j+12),(CX+s*60,j+54)],fill=(*li(bow,0.18),255))
        d.ellipse([CX-20,j+36,CX+20,j+74],fill=(*sh(bow,0.20),255))
    if ribbon:
        d.rectangle([CX-300,722,CX+300,758],fill=(*ribbon,255))
        for s in(-1,1):
            d.polygon([(CX,740),(CX+s*84,704),(CX+s*84,776)],fill=(*sh(ribbon,0.10),255))
        d.ellipse([CX-17,722,CX+17,758],fill=(*sh(ribbon,0.24),255))
    # ── 切り抜き
    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x,sdrop))),x]=0
    for y in range(H):
        hw=torso_hw(y)
        a[y,:max(0,int(CX-hw))]=0; a[y,min(W,int(CX+hw))+1:]=0
    for x in range(W): a[int(hemc(x))+1:,x]=0
    if sleeve=='short':
        for y in range(709,H):
            asx=arm_seam(y)
            a[y,:int(CX-asx)]=0; a[y,int(CX+asx):]=0
    if sleeve=='none':
        for y in range(int(FLAT),H):
            asx=arm_seam(y)+6
            a[y,:int(CX-asx)]=0; a[y,int(CX+asx):]=0
    out=clip(Image.fromarray(a))
    return outline(out,ol) if ol else out

# ══════════ 下（ボトムス）══════════
def mk_bottom(col, kind='pants', tex=T_plain, hem=956, waist=WAIST_TOP, flare=0.30,
              stitch_col=None, accent=None, pleat=0, gap=34, pocket=True,
              crease=False, cargo=False, waistband=True, loops=True, rivets=False,
              ol=None, shading=0.30, hem_band=None, side_stripe=None):
    st = stitch_col or sh(col,0.34)
    acc= accent or sh(col,0.22)
    a=np.zeros((H,W,4),dtype=np.uint8)
    is_skirt = kind=='skirt'
    if not is_skirt:
        for y in range(waist,min(H,hem+1)):
            hw=torso_hw(y)
            if hw<=0: continue
            for x in range(int(CX-hw),int(CX+hw)+1):
                if y>872:
                    t_=min(1.0,(y-872)/max(1,(hem-872)))
                    if abs(x-CX)<gap*(t_**0.55): continue
                c=tex(x,y,col)
                if c is None: continue
                u=abs(x-CX)/max(1.0,hw)
                c=sh(c,shading*(u**2.2))
                if y<waist+26: c=li(c,0.09)
                if y>hem-26: c=sh(c,0.14)
                a[y,x]=(*c,255)
        l=Image.fromarray(a); d=ImageDraw.Draw(l)
        hwW=torso_hw(waist+16)
        if waistband:
            d.rectangle([CX-hwW,waist,CX+hwW,waist+44],fill=(*sh(col,0.10),255))
            stitch(d,[(CX-hwW,waist+38),(CX+hwW,waist+38)],st,w=3)
            d.ellipse([CX-13,waist+9,CX+13,waist+35],fill=(*li(acc,0.5),255))
        if loops:
            for s in(-3,-1,1,3):
                xx=CX+s*62
                d.rectangle([xx-7,waist-2,xx+7,waist+50],fill=(*sh(col,0.20),255))
        stitch(d,[(CX+16,waist+46),(CX+16,waist+170)],st,w=3)          # 前立て
        stitch(d,[(CX+24,waist+52),(CX+24,waist+162)],st,w=3)
        if pocket:
            for s in(-1,1):
                stitch_arc(d,[CX+s*46-8,waist+22,CX+s*212,waist+186],
                           200 if s<0 else 340, 340 if s<0 else 380, st,w=3)
            stitch(d,[(CX+58,waist+30),(CX+58,waist+96)],st,w=3)        # コインポケット
            stitch(d,[(CX+58,waist+96),(CX+120,waist+96)],st,w=3)
        if rivets:
            for (rx,ry) in ((CX-206,waist+42),(CX+206,waist+42),(CX-64,waist+150),(CX+64,waist+150)):
                d.ellipse([rx-8,ry-8,rx+8,ry+8],fill=(*li(acc,0.35),255))
        if side_stripe:
            for s in(-1,1):
                pts=[(CX+s*(torso_hw(y)-26), y) for y in range(796,min(H,hem-4),6)]
                for i in range(len(pts)-1):
                    d.line([pts[i],pts[i+1]],fill=(*side_stripe,255),width=13)
        if crease:
            for s in(-1,1):
                d.line([(CX+s*118,waist+60),(CX+s*130,hem-10)],fill=(*li(col,0.16),255),width=6)
        if cargo:
            for s in(-1,1):
                bx=CX+s*128
                d.rounded_rectangle([bx-62,832,bx+62,930],10,fill=(*sh(col,0.12),255))
                d.rectangle([bx-66,824,bx+66,858],fill=(*sh(col,0.20),255))
                stitch(d,[(bx-62,848),(bx+62,848)],st,w=3)
        if hem_band:
            d.rectangle([CX-300,hem-40,CX+300,hem],fill=(*hem_band,255))
        for s in(-1,1):   # 脇の縫い目（脚に沿って）
            pts=[(CX+s*(torso_hw(y)-9), y) for y in range(796,min(H,hem-4),7)]
            if len(pts)>1: stitch(d,pts,st,w=3)
        for s in(-1,1):   # 内また
            pts=[(CX+s*(gap*(min(1.0,(y-872)/max(1,(hem-872)))**0.55)+9), y)
                 for y in range(880,min(H,hem-4),7)]
            if len(pts)>1: stitch(d,pts,st,w=3)
        if hem_band is None and hem<952:   # 裾の折り返し
            pass
        a=np.array(l)
        for y in range(H):
            hw=torso_hw(y)
            a[y,:max(0,int(CX-hw))]=0; a[y,min(W,int(CX+hw))+1:]=0
        a[:waist]=0; a[hem+1:]=0
        for y in range(873,min(H,hem+1)):
            t_=min(1.0,(y-872)/max(1,(hem-872)))
            g_=int(gap*(t_**0.55))
            a[y,CX-g_:CX+g_]=0
        out=clip(Image.fromarray(a))
    else:
        hw0=torso_hw(waist+8); hwmax=hw0*(1+flare)
        for y in range(waist,min(H,hem+1)):
            t=(y-waist)/max(1,(hem-waist))
            hw=hw0*(1+flare*(t**1.5))
            for x in range(int(CX-hw),int(CX+hw)+1):
                yb = hem-30*((x-CX)/hwmax)**2
                if y > yb: continue
                c=tex(x,y,col)
                if c is None: continue
                if y > yb-18: c=sh(c,0.26)          # 裾の始末
                sd=abs(x-CX)/hwmax
                if pleat:
                    ph=((x-CX)//pleat)%2
                    c=sh(c,0.17) if ph else li(c,0.06)
                c=sh(c,shading*(sd**2.0))
                if y<waist+26: c=li(c,0.08)
                if 0<=x<W: a[y,x]=(*c,255)
        l=Image.fromarray(a); d=ImageDraw.Draw(l)
        if waistband:
            d.rectangle([CX-hw0-4,waist,CX+hw0+4,waist+40],fill=(*sh(col,0.14),255))
            stitch(d,[(CX-hw0,waist+34),(CX+hw0,waist+34)],st,w=3)
        out=Image.fromarray(np.array(l))
    return outline(out,ol) if ol else out

# ══════════ 羽織り ══════════
def mk_outer(col, tex=T_plain, hem=880, drop=26, open_w=104, tex_lapel=None,
             lapel='notch', pockets='flap', chest=False, buttons=2, belt=None,
             quilt=0, fur=False, epaulet=False, double=False, stitch_col=None,
             accent=None, ol=None, sdrop=150, puff=False, shading=0.30, zipper=False):
    st=stitch_col or sh(col,0.34); acc=accent or sh(col,0.20)
    def hemc(x):
        u=(x-CX)/300.0
        return hem+drop*max(0.0,1-u*u)
    a=np.zeros((H,W,4),dtype=np.uint8)
    for y in range(int(FLAT)-30,min(H,int(hem+drop)+2)):
        hw=torso_hw(y)+(18 if puff else 0)
        if hw<=0: continue
        asx=arm_seam(y)
        for x in range(int(CX-hw),int(CX+hw)+1):
            t=top_y(x,sdrop); b=hemc(x)
            if y<t or y>b: continue
            if abs(x-CX)<open_w and y>t+34: continue
            c=tex(x,y,col)
            if c is None: continue
            u=abs(x-CX)/max(1.0,hw)
            c=sh(c,shading*(u**2.2))
            if abs(x-CX)>asx: c=sh(c,0.06)
            if y<t+54: c=li(c,0.12*(1-(y-t)/54.0))
            if y>b-26: c=sh(c,0.16)
            if 0<=x<W: a[y,x]=(*c,255)
    l=Image.fromarray(a); d=ImageDraw.Draw(l); j=int(jaw(CX))
    # ── 生地の上に描くもの（前あきの中には出さない）
    if quilt:
        for k in range(quilt):
            yy=int(FLAT)+58+k*int((hem-FLAT)/quilt)
            d.line([(CX-330,yy),(CX+330,yy)],fill=(*sh(col,0.24),255),width=5)
            d.line([(CX-330,yy+7),(CX+330,yy+7)],fill=(*li(col,0.13),255),width=4)
    for s in(-1,1):
        pts=[(CX+s*arm_seam(y),y) for y in range(int(top_y(CX+s*250,sdrop)),int(hemc(CX+s*230)),6)]
        if len(pts)>1: stitch(d,pts,st,w=3)
    if chest:
        d.rectangle([CX-open_w-186,j+150,CX-open_w-72,j+188],fill=(*sh(col,0.18),255))
        stitch(d,[(CX-open_w-186,j+156),(CX-open_w-72,j+156)],st,w=3)
    if pockets=='flap':
        for s in(-1,1):
            px=CX+s*(open_w+124)
            d.rectangle([px-82,hem-164,px+82,hem-110],fill=(*sh(col,0.16),255))
            stitch(d,[(px-82,hem-116),(px+82,hem-116)],st,w=3)
    elif pockets=='patch':
        for s in(-1,1):
            px=CX+s*(open_w+124)
            d.rounded_rectangle([px-78,hem-176,px+78,hem-56],10,outline=(*st,255),width=4)
            stitch(d,[(px-78,hem-166),(px+78,hem-166)],st,w=3)
    if belt:
        d.rectangle([CX-330,742,CX+330,798],fill=(*belt,255))
        d.rectangle([CX-330,742,CX+330,750],fill=(*li(belt,0.3),255))
    if zipper:
        d.line([(CX-open_w+9,j+20),(CX-open_w+9,hemc(CX)-20)],fill=(*sh(col,0.42),255),width=11)
    # ── ここで前あきと輪郭を切る
    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x,sdrop))),x]=0
    for x in range(W): a[int(hemc(x))+1:,x]=0
    for y in range(H):
        t=top_y(CX,sdrop)
        if y>t+34: a[y,CX-open_w:CX+open_w]=0
    l=clip(Image.fromarray(a),big=puff)
    # ── 切ったあとに描くもの（あきの縁に乗る）
    trim=new(); d=ImageDraw.Draw(trim)
    if lapel=='notch':
        lc=tex_lapel or li(col,0.11)
        for s in(-1,1):
            d.polygon([(CX+s*(open_w-2),j+2),(CX+s*(open_w+78),j+40),
                       (CX+s*(open_w+44),j+86),(CX+s*(open_w+86),j+126),
                       (CX+s*(open_w-2),j+218)],fill=(*lc,255))
            d.line([(CX+s*(open_w+78),j+40),(CX+s*(open_w+44),j+86)],fill=(*sh(col,0.34),255),width=4)
            stitch(d,[(CX+s*(open_w-2),j+2),(CX+s*(open_w-2),j+218)],st,w=3)
    elif lapel=='peak':
        lc=tex_lapel or li(col,0.11)
        for s in(-1,1):
            d.polygon([(CX+s*(open_w-2),j+2),(CX+s*(open_w+94),j+16),
                       (CX+s*(open_w+46),j+84),(CX+s*(open_w+90),j+130),
                       (CX+s*(open_w-2),j+218)],fill=(*lc,255))
    elif lapel=='stand':
        d.rounded_rectangle([CX-open_w-88,j-42,CX+open_w+88,j+30],18,fill=(*li(col,0.08),255))
        stitch(d,[(CX-open_w-80,j+22),(CX+open_w+80,j+22)],st,w=3)
    if fur:
        for s in(-1,1):
            for k in range(7):
                xx=CX+s*(open_w+18+k*28)
                d.ellipse([xx-32,j-36,xx+32,j+38],fill=(*li(col,0.26),255))
                d.ellipse([xx-19,j-22,xx+19,j+22],fill=(*li(col,0.48),255))
    if epaulet:
        for s in(-1,1):
            ty=int(top_y(CX+s*242,sdrop))
            d.rounded_rectangle([CX+s*242-58,ty+6,CX+s*242+58,ty+46],10,fill=(*sh(col,0.18),255))
    if belt:
        d.rounded_rectangle([CX-46,736,CX+46,804],9,fill=(*li(belt,0.10),255))
        d.rounded_rectangle([CX-46,736,CX+46,804],9,outline=(*li(belt,0.55),255),width=9)
    if double:
        for i in range(2):
            for s in(-1,1):
                yy=j+152+i*84
                d.ellipse([CX+s*62-15,yy-15,CX+s*62+15,yy+15],fill=(*li(acc,0.45),255))
                d.ellipse([CX+s*62-15,yy-15,CX+s*62+15,yy+15],outline=(*sh(acc,0.25),255),width=3)
    else:
        for i in range(buttons):
            yy=j+206+i*88
            if yy>hem-70: break
            d.ellipse([CX+open_w-32,yy-15,CX+open_w-2,yy+15],fill=(*li(acc,0.45),255))
            d.ellipse([CX+open_w-32,yy-15,CX+open_w-2,yy+15],outline=(*sh(acc,0.25),255),width=3)
    ta=np.array(trim)
    for x in range(W): ta[:max(0,int(top_y(x,sdrop)))-6,x]=0
    trim=clip(Image.fromarray(ta),big=True)
    l.alpha_composite(trim)
    return outline(l,ol) if ol else l

def stack(*layers, over=()):
    p=new(); p.alpha_composite(body)
    for g in layers:
        if g is not None: p.alpha_composite(g)
    p.alpha_composite(head)
    for g in over:
        if g is not None: p.alpha_composite(g)
    return p

# ── 首元 ──────────────────────────────────────────
def scarf_bottom(x): return -0.00160767*x*x + 1.643818*x + 255.353
def neckwear(kind, col, col2=None, ol=None):
    l=new(); d=ImageDraw.Draw(l); j=int(jaw(CX))
    if kind in ('muffler','stole'):
        wide = 300 if kind=='stole' else 250
        a=np.array(l)
        for x in range(CX-wide,CX+wide+1):
            t=int(jaw(x))-18; b=int(scarf_bottom(x))+(30 if kind=='stole' else 0)
            for y in range(max(0,t),min(H,b)):
                base=col if (col2 is None or ((x+y)//34)%2==0) else col2
                a[y,x]=(*base,255)
        l=Image.fromarray(a); d=ImageDraw.Draw(l)
        d.rounded_rectangle([CX+70,int(scarf_bottom(CX))-20,CX+188,int(scarf_bottom(CX))+210],26,fill=(*sh(col,0.14),255))
        for k in range(6):
            yy=int(scarf_bottom(CX))+186+k*6
            d.line([(CX+74,yy),(CX+184,yy)],fill=(*sh(col,0.3),255),width=3)
    elif kind=='tie':
        d.polygon([(CX-52,j+6),(CX+52,j+6),(CX+20,j+62),(CX-20,j+62)],fill=(*sh(col,0.16),255))
        d.polygon([(CX-38,j+62),(CX+38,j+62),(CX+26,j+250),(CX,j+286),(CX-26,j+250)],fill=(*col,255))
    elif kind=='bowtie':
        for s_ in(-1,1):
            d.polygon([(CX,j+52),(CX+s_*98,j+10),(CX+s_*98,j+96)],fill=(*col,255))
        d.ellipse([CX-22,j+32,CX+22,j+74],fill=(*sh(col,0.20),255))
    elif kind=='ribbon':
        for s_ in(-1,1):
            d.polygon([(CX,j+58),(CX+s_*118,j+2),(CX+s_*84,j+110)],fill=(*col,255))
        d.polygon([(CX-14,j+70),(CX-52,j+228),(CX+6,j+214)],fill=(*sh(col,0.10),255))
        d.polygon([(CX+14,j+70),(CX+52,j+228),(CX-6,j+214)],fill=(*sh(col,0.10),255))
        d.ellipse([CX-26,j+38,CX+26,j+90],fill=(*sh(col,0.24),255))
    elif kind=='necklace':
        d.arc([CX-150,j-70,CX+150,j+130],14,166,fill=(*col,255),width=11)
        d.ellipse([CX-24,j+112,CX+24,j+160],fill=(*col,255))
        d.ellipse([CX-11,j+125,CX+11,j+147],fill=(*li(col,0.55),255))
    elif kind=='pearl':
        import math
        for k in range(19):
            th=math.radians(16+148*k/18.0)
            x=CX-150*math.cos(th); y=(j+30)+100*math.sin(th)
            d.ellipse([x-13,y-13,x+13,y+13],fill=(*col,255))
    elif kind=='scarf':
        d.polygon([(CX-150,j-14),(CX+150,j-14),(CX,j+30)],fill=(*sh(col,0.16),255))
        d.polygon([(CX-104,j+10),(CX+104,j+10),(CX,j+126)],fill=(*col,255))
        d.ellipse([CX-34,j+2,CX+34,j+56],fill=(*sh(col,0.26),255))
    elif kind=='hood_down':
        d.pieslice([CX-206,j-40,CX+206,j+250],188,352,fill=(*col,255))
        d.arc([CX-206,j-40,CX+206,j+250],188,352,fill=(*sh(col,0.22),255),width=8)
    elif kind=='choker':
        d.rounded_rectangle([CX-128,j-42,CX+128,j+8],24,fill=(*col,255))
        d.ellipse([CX-19,j-35,CX+19,j+1],fill=(*li(col,0.5),255))
    if ol: l=outline(l,ol,7)
    return l

# ── 目元 ──────────────────────────────────────────
def eyewear(kind, col, lens=None, ol=None):
    l=new(); d=ImageDraw.Draw(l)
    (lx,ly),(rx,ry)=EYE_L,EYE_R; R=52
    def frame(shape):
        for (cx,cy) in ((lx,ly),(rx,ry)):
            box=[cx-R,cy-R+6,cx+R,cy+R-6]
            if lens: d.rounded_rectangle(box,R//2,fill=(*lens,150)) if shape=='sq' else d.ellipse(box,fill=(*lens,150))
            if shape=='sq': d.rounded_rectangle(box,R//2,outline=(*col,255),width=11)
            else: d.ellipse(box,outline=(*col,255),width=11)
        d.line([(lx+R-4,ly),(rx-R+4,ry)],fill=(*col,255),width=10)
        d.line([(lx-R+2,ly-4),(lx-R-58,ly-16)],fill=(*col,255),width=10)
        d.line([(rx+R-2,ry-4),(rx+R+58,ry-16)],fill=(*col,255),width=10)
    if kind=='round': frame('rd')
    elif kind=='square': frame('sq')
    elif kind=='sun': frame('rd')
    elif kind=='goggle':
        d.rounded_rectangle([lx-R-14,ly-R,rx+R+14,ry+R],48,fill=(*col,255))
        d.rounded_rectangle([lx-R+4,ly-R+18,rx+R-4,ry+R-18],36,fill=(*(lens or (150,190,210)),200))
    elif kind=='eyepatch':
        d.ellipse([rx-R,ry-R,rx+R,ry+R],fill=(*col,255))
        d.line([(rx-R,ry-18),(lx-R-60,ry-40)],fill=(*col,255),width=9)
        d.line([(rx+R,ry-18),(rx+R+60,ry-40)],fill=(*col,255),width=9)
    if ol: l=outline(l,ol,7)
    return l
