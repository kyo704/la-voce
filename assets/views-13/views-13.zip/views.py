# -*- coding: utf-8 -*-
"""外のけしき ── 全13点
   規約：窓の外の景色 480 × 320 ／ 地平線 y232

   ★このファイルに 足していきます。★1点ずつ 別ファイルに しません。
   ★使い方：python3 views.py          → 全部 作り直す
            python3 views.py 3 7      → 3番と7番だけ
"""
import sys, os, math, json, random
sys.path.insert(0, '/home/claude/z/acnh/interior')
from PIL import Image, ImageDraw, ImageFilter
from interior2 import canvas

W, H = 480, 320
HOR = 232
OUT = '/home/claude/out/view'


# ══ 共通の 道具 ════════════════════════════════════════
def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def sky(d, stops):
    for y in range(HOR):
        t = y / HOR
        for i in range(len(stops) - 1):
            p0, c0 = stops[i]
            p1, c1 = stops[i + 1]
            if p0 <= t <= p1:
                d.line([(0, y), (W, y)],
                       fill=(*lerp(c0, c1, (t - p0) / (p1 - p0)), 255))
                break


def ridge(d, base_y, amp, col, seed, step=8):
    r = random.Random(seed)
    pts = [(0, H)]
    x = 0
    while x <= W:
        pts.append((x, base_y + math.sin(x / 46 + seed) * amp + r.uniform(-2, 2)))
        x += step
    pts.append((W, H))
    d.polygon(pts, fill=col)


def grass(d, top, base, tip, n=260, seed=77):
    g = random.Random(seed)
    d.rectangle([0, HOR, W, H], fill=(*base, 255))
    d.rectangle([0, HOR, W, HOR + 3], fill=(*top, 255))
    for _ in range(n):
        x = g.uniform(0, W)
        y = g.uniform(HOR + 4, H)
        t = (y - HOR) / (H - HOR)
        d.line([(x, y), (x + g.uniform(-1.4, 1.4), y - g.uniform(2, 5))],
               fill=(*lerp(tip, base, t), 255))


def clouds(img, bands, base, lowlight, highshade, blur=2, seed=41):
    """★塊の つらなり。★楕円を 重ねると 輪に 見えるため この形
       bands = [(cx, cy, cw, ch, alpha), ...]"""
    cl = canvas(W, H)
    cd = ImageDraw.Draw(cl)
    cr = random.Random(seed)
    for cx, cy, cw, ch, al in bands:
        n = max(4, int(cw / 34))
        lumps = []
        for k in range(n):
            t = k / (n - 1)
            px = cx - cw / 2 + cw * t
            f = math.sin(math.pi * t) ** 0.6
            rw = (cw / n) * 0.95 * (0.55 + 0.75 * f)
            rh = ch * (0.55 + 0.75 * f) + cr.uniform(-1, 1)
            lumps.append((px, cy + cr.uniform(-2, 2), rw, rh))
        for px, py, rw, rh in lumps:                      # ① 地
            cd.ellipse([px - rw, py - rh, px + rw, py + rh], fill=(*base, al))
        for px, py, rw, rh in lumps:                      # ② 下面の 光
            cd.ellipse([px - rw * .82, py + rh * .10, px + rw * .82, py + rh * 1.02],
                       fill=(*lowlight, int(al * .85)))
        for px, py, rw, rh in lumps:                      # ③ 上面の 影
            cd.ellipse([px - rw * .70, py - rh * .98, px + rw * .70, py - rh * .18],
                       fill=(*highshade, int(al * .55)))
    img.alpha_composite(cl.filter(ImageFilter.GaussianBlur(blur)))


def orb(d, img, cx, cy, r, core, edge, halo_col, halo_a=12, halo_n=10, halo_step=10):
    """★月・太陽。★欠けや 海を 作らない（★丸が 2つに 見えます）"""
    h = canvas(W, H)
    hd = ImageDraw.Draw(h)
    for k in range(halo_n, 0, -1):
        rr = r + k * halo_step
        hd.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                   fill=(*halo_col, int(halo_a * (halo_n + 1 - k) / halo_n)))
    img.alpha_composite(h.filter(ImageFilter.GaussianBlur(8)))
    dd = ImageDraw.Draw(img)
    for k in range(int(r), 0, -1):
        t = 1 - k / r
        dd.ellipse([cx - k, cy - k, cx + k, cy + k], fill=(*lerp(edge, core, t), 255))
    return ImageDraw.Draw(img)


def light_road(img, cx, col, a=34, top_w=15, bot_w=62, blur=9):
    road = canvas(W, H)
    rd = ImageDraw.Draw(road)
    rd.polygon([(cx - top_w, HOR), (cx + top_w, HOR),
                (cx + bot_w, H), (cx - bot_w, H)], fill=(*col, a))
    img.alpha_composite(road.filter(ImageFilter.GaussianBlur(blur)))


def tree_round(d, cx, base, scale, crown, seed, trunk=(104, 78, 66)):
    """★丸い 木。★冠＋ふちの もこもこ（★散らすと 形が 読めません）"""
    r = random.Random(seed)
    tw = 9 * scale
    d.polygon([(cx - tw, base), (cx + tw, base),
               (cx + tw * .45, base - 52 * scale), (cx - tw * .45, base - 52 * scale)],
              fill=(*trunk, 255))
    for a, ln in [(-0.9, 34), (0.8, 30), (-0.35, 26)]:
        d.line([(cx, base - 50 * scale),
                (cx + math.sin(a) * ln * scale,
                 base - 52 * scale - math.cos(a) * ln * scale)],
               fill=(*trunk, 255), width=max(2, int(5 * scale)))
    cy0 = base - 96 * scale
    rw, rh = 52 * scale, 34 * scale
    for dy, sw, sh_, c in [(6, 1.00, 1.00, crown[0]),
                           (0, 0.96, 0.94, crown[1]),
                           (-7, 0.72, 0.64, crown[2])]:
        d.ellipse([cx - rw * sw, cy0 + dy - rh * sh_,
                   cx + rw * sw, cy0 + dy + rh * sh_], fill=(*c, 255))
    n = int(11 * scale)
    for i in range(n):
        a = math.pi * (0.06 + 0.88 * i / max(1, n - 1))
        px = cx - math.cos(a) * rw * 0.94
        py = cy0 - math.sin(a) * rh * 0.92 + r.uniform(-2, 2)
        rr = r.uniform(9, 14) * scale
        c = crown[1] if r.random() < .6 else crown[2]
        d.ellipse([px - rr, py - rr, px + rr, py + rr], fill=(*c, 255))


def conifer(d, cx, base, scale, cols, seed):
    """★杉・もみ。★三角を 3段"""
    r = random.Random(seed)
    tw = 6 * scale
    d.polygon([(cx - tw, base), (cx + tw, base),
               (cx + tw * .6, base - 30 * scale), (cx - tw * .6, base - 30 * scale)],
              fill=(96, 72, 58, 255))
    for k, (wf, yf, hf) in enumerate([(1.00, 0.00, 1.00),
                                      (0.78, 0.28, 0.86),
                                      (0.54, 0.54, 0.70)]):
        hw = 42 * scale * wf
        top = base - (44 + 52 * yf + 44 * hf) * scale
        bot = base - (18 + 52 * yf) * scale
        d.polygon([(cx, top), (cx - hw, bot), (cx + hw, bot)], fill=(*cols[k], 255))


def specks(d, n, ymin, ymax, col, rmin, rmax, seed, amin=140, amax=255):
    r = random.Random(seed)
    for _ in range(n):
        x, y = r.uniform(0, W), r.uniform(ymin, ymax)
        rr = r.uniform(rmin, rmax)
        d.ellipse([x - rr, y - rr, x + rr, y + rr],
                  fill=(*col, r.randint(amin, amax)))


def stars(d, n=190, seed=20260917, ytop=4, ybot=None, thin=True):
    ybot = ybot if ybot is not None else HOR - 14
    rnd = random.Random(seed)
    for _ in range(n):
        x, y = rnd.uniform(0, W), rnd.uniform(ytop, ybot)
        near = y / HOR
        if thin and rnd.random() < near * 0.72:
            continue
        r = rnd.choice([0.7, 0.7, 0.9, 1.1, 1.5])
        a = int(255 * (1 - near * 0.66) * rnd.uniform(0.55, 1.0))
        col = (255, 252, 240) if rnd.random() < 0.82 else (206, 222, 255)
        d.ellipse([x - r, y - r, x + r, y + r], fill=(*col, a))
        if r >= 1.5:
            d.line([(x - 3.4, y), (x + 3.4, y)], fill=(*col, a // 3))
            d.line([(x, y - 3.4), (x, y + 3.4)], fill=(*col, a // 3))


# ══ 13点 ══════════════════════════════════════════════
def v01_hare():
    """晴れ ── 空と 草原"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (104, 168, 220)), (0.62, (166, 206, 236)), (1, (216, 232, 240))])
    clouds(img, [(140, 74, 230, 20, 225), (350, 118, 190, 15, 195),
                 (96, 150, 160, 11, 150)],
           (255, 255, 255), (255, 255, 255), (206, 218, 232), blur=2, seed=5)
    d = ImageDraw.Draw(img)
    ridge(d, HOR - 32, 10, (150, 178, 160, 255), 2.3)
    ridge(d, HOR - 14, 6, (116, 150, 122, 255), 1.1)
    grass(d, (156, 190, 122), (96, 134, 84), (144, 180, 112))
    return img


def v02_yuuyake():
    """夕焼け"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (72, 78, 128)), (0.34, (196, 122, 116)), (0.62, (240, 164, 106)),
            (0.86, (250, 206, 138)), (1, (252, 232, 176))])
    d = orb(d, img, 330, 196, 26, (255, 246, 214), (252, 198, 122), (255, 216, 150))
    clouds(img, [(160, 100, 250, 17, 205), (350, 138, 200, 13, 170),
                 (96, 166, 170, 10, 130)],
           (226, 158, 138), (255, 220, 174), (198, 128, 124))
    d = ImageDraw.Draw(img)
    ridge(d, HOR - 30, 10, (122, 96, 118, 255), 3.1)
    ridge(d, HOR - 14, 6, (84, 66, 88, 255), 1.7)
    grass(d, (150, 128, 96), (62, 54, 52), (118, 102, 78))
    light_road(img, 330, (255, 208, 150), 40)
    return img


def v03_yoru():
    """夜 ── 満月"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (18, 22, 52)), (0.62, (34, 44, 92)), (1, (78, 92, 140))])
    stars(d)
    d = orb(d, img, 356, 72, 30, (253, 252, 244), (238, 234, 214),
            (226, 232, 255), halo_a=9, halo_n=9, halo_step=8)
    clouds(img, [(300, 116, 210, 17, 52), (120, 150, 240, 14, 40),
                 (368, 178, 170, 12, 30)],
           (198, 210, 245), (216, 226, 250), (150, 166, 210), blur=5, seed=9)
    d = ImageDraw.Draw(img)
    ridge(d, HOR - 34, 11, (42, 50, 86, 255), 3.1)
    ridge(d, HOR - 16, 7, (28, 34, 62, 255), 1.7)
    grass(d, (66, 84, 72), (24, 34, 30), (72, 92, 78))
    light_road(img, 356, (180, 196, 240), 26, 16, 66)
    return img


def v04_ame():
    """雨"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (96, 104, 116)), (0.60, (132, 140, 150)), (1, (170, 176, 182))])
    clouds(img, [(150, 56, 300, 26, 230), (356, 100, 240, 20, 200),
                 (110, 132, 220, 14, 160)],
           (104, 112, 124), (146, 154, 164), (82, 90, 102), blur=3, seed=13)
    d = ImageDraw.Draw(img)
    ridge(d, HOR - 28, 9, (122, 132, 130, 255), 2.7)
    grass(d, (108, 128, 106), (66, 84, 70), (98, 118, 96), n=180)
    # 雨すじ
    r = random.Random(4)
    for _ in range(300):
        x, y = r.uniform(-30, W), r.uniform(0, H)
        ln = r.uniform(10, 22)
        d.line([(x, y), (x + 6, y + ln)],
               fill=(224, 232, 238, r.randint(46, 120)), width=1)
    # 水たまりの 波紋
    for cx, cy, rr in [(120, 292, 16), (330, 276, 12), (228, 306, 20)]:
        for k in range(3):
            d.ellipse([cx - rr + k * 5, cy - rr * .3 + k * 1.6,
                       cx + rr - k * 5, cy + rr * .3 - k * 1.6],
                      outline=(206, 220, 228, 90 - k * 22), width=1)
    return img


def v05_yuki():
    """雪"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (122, 140, 172)), (0.46, (172, 188, 208)),
            (0.78, (214, 222, 232)), (1, (238, 240, 242))])
    clouds(img, [(150, 58, 290, 22, 190), (352, 102, 220, 16, 155)],
           (168, 180, 198), (214, 224, 236), (142, 154, 176), blur=3, seed=21)
    d = ImageDraw.Draw(img)

    # ★山 ── 3重。★雪の 稜線を 白く 残し、★陰は 青みに
    ridge(d, HOR - 34, 11, (206, 214, 224, 255), 2.3)
    ridge(d, HOR - 16, 7, (226, 232, 238, 255), 1.1)

    # ★地面 ── 手前ほど 白く、奥は 青い 影
    for y in range(HOR, H):
        t = (y - HOR) / (H - HOR)
        d.line([(0, y), (W, y)],
               fill=(*lerp((206, 216, 232), (250, 252, 255), t), 255))
    d.rectangle([0, HOR, W, HOR + 2], fill=(255, 255, 255, 255))

    # ★雪原 ── ★平らで よい。★うねりを 並べると 横縞に なります
    #   起伏は ★大きく 2つだけ。★手前の 影で 奥行きを 出す
    b = random.Random(8)
    for cx, cy, rw, rh, c in [(120, HOR + 30, 210, 16, (216, 226, 240)),
                              (372, HOR + 52, 190, 20, (208, 220, 238))]:
        d.ellipse([cx - rw, cy - rh, cx + rw, cy + rh], fill=(*c, 255))
        d.ellipse([cx - rw, cy - rh - 5, cx + rw, cy + rh - 5],
                  fill=(250, 252, 255, 255))

    # ★手前の 影 ── 下ほど 青く 沈める
    sh_ = canvas(W, H)
    sd = ImageDraw.Draw(sh_)
    for y in range(H - 54, H):
        t = (y - (H - 54)) / 54
        sd.line([(0, y), (W, y)], fill=(178, 196, 222, int(70 * t)))
    img.alpha_composite(sh_.filter(ImageFilter.GaussianBlur(6)))
    d = ImageDraw.Draw(img)

    # ★雪の すじ ── 風の 向き。★数本だけ
    for _ in range(14):
        y = b.uniform(HOR + 16, H - 8)
        x = b.uniform(-40, W)
        ln = b.uniform(60, 170)
        d.line([(x, y), (x + ln, y + b.uniform(-2, 2))],
               fill=(255, 255, 255, b.randint(90, 160)), width=b.randint(2, 4))

    # ★降る雪 ── 3段。★手前ほど 大きく、ぼかす。★大粒は 縦に つぶす
    for n, rmin, rmax, a0, a1, bl, sq in [(120, 0.8, 1.5, 110, 180, 0, 1.0),
                                          (64, 1.6, 2.5, 140, 205, 0, 0.9),
                                          (22, 2.8, 4.2, 110, 165, 3, 0.7)]:
        lay = canvas(W, H)
        ld = ImageDraw.Draw(lay)
        r = random.Random(int(rmin * 100))
        for _ in range(n):
            x, y = r.uniform(0, W), r.uniform(0, H)
            rr = r.uniform(rmin, rmax)
            ld.ellipse([x - rr, y - rr * sq, x + rr, y + rr * sq],
                       fill=(255, 255, 255, r.randint(a0, a1)))
        img.alpha_composite(lay.filter(ImageFilter.GaussianBlur(bl)) if bl else lay)
    return img


def v06_asamoya():
    """朝もや"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (156, 172, 196)), (0.46, (214, 206, 198)),
            (0.78, (244, 224, 198)), (1, (250, 238, 216))])
    d = orb(d, img, 150, 176, 20, (255, 250, 236), (250, 226, 186),
            (255, 232, 196), halo_a=14, halo_n=11, halo_step=11)
    ridge(d, HOR - 44, 12, (184, 190, 196, 255), 3.7)
    ridge(d, HOR - 26, 8, (152, 162, 168, 255), 2.1)
    ridge(d, HOR - 10, 5, (120, 134, 132, 255), 1.3)
    grass(d, (150, 160, 130), (104, 118, 96), (140, 152, 122), n=160)
    # もや ── 横に 帯を 数本
    mo = canvas(W, H)
    md = ImageDraw.Draw(mo)
    for y, h_, a in [(HOR - 40, 18, 120), (HOR - 18, 22, 150), (HOR + 6, 26, 110)]:
        md.rectangle([0, y, W, y + h_], fill=(248, 244, 238, a))
    img.alpha_composite(mo.filter(ImageFilter.GaussianBlur(10)))
    return img


def v07_shinryoku():
    """新緑"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (122, 180, 224)), (0.64, (178, 212, 236)), (1, (222, 236, 240))])
    clouds(img, [(340, 66, 200, 16, 210), (110, 116, 170, 12, 170)],
           (255, 255, 255), (255, 255, 255), (206, 220, 234), blur=2, seed=17)
    d = ImageDraw.Draw(img)
    ridge(d, HOR - 34, 10, (140, 176, 138, 255), 2.9)
    G = [(96, 150, 78), (128, 182, 96), (166, 208, 120)]
    tree_round(d, 254, HOR - 6, 0.58, G, 13)
    tree_round(d, 70, HOR + 8, 1.05, G, 5)
    tree_round(d, 406, HOR + 4, 0.86, G, 9)
    grass(d, (160, 198, 118), (98, 140, 82), (150, 190, 110))
    return img


def v08_kouyou():
    """紅葉"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (128, 172, 208)), (0.60, (194, 206, 216)), (1, (236, 226, 208))])
    clouds(img, [(150, 70, 210, 15, 190), (368, 122, 170, 11, 150)],
           (246, 242, 236), (255, 252, 246), (204, 206, 206), blur=2, seed=23)
    d = ImageDraw.Draw(img)
    ridge(d, HOR - 34, 11, (162, 140, 118, 255), 3.3)
    A = [(176, 88, 52), (212, 122, 62), (240, 170, 86)]
    B = [(168, 66, 58), (204, 96, 72), (236, 146, 102)]
    tree_round(d, 250, HOR - 6, 0.56, A, 13)
    tree_round(d, 76, HOR + 8, 1.02, B, 5)
    tree_round(d, 402, HOR + 4, 0.88, A, 9)
    grass(d, (178, 156, 104), (118, 104, 72), (168, 146, 98))
    # 落ち葉
    r = random.Random(19)
    for _ in range(46):
        x, y = r.uniform(0, W), r.uniform(60, H - 6)
        rr = r.uniform(2.0, 3.6)
        c = r.choice([(214, 120, 62), (176, 88, 52), (238, 168, 86)])
        d.ellipse([x - rr, y - rr * .66, x + rr, y + rr * .66],
                  fill=(*c, r.randint(170, 240)))
    return img


def v09_kareki():
    """枯れ木と 雪"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (134, 148, 176)), (0.52, (182, 194, 210)),
            (0.82, (216, 224, 232)), (1, (234, 238, 242))])
    # ★山 ── 3重。★稜線に 雪
    ridge(d, HOR - 34, 11, (208, 214, 224, 255), 2.3)

    # 枯れ木 ── 枝だけ
    def bare(cx, base, scale, seed):
        r = random.Random(seed)
        col = (88, 74, 66)
        tw = 8 * scale
        d.polygon([(cx - tw, base), (cx + tw, base),
                   (cx + tw * .4, base - 76 * scale), (cx - tw * .4, base - 76 * scale)],
                  fill=(*col, 255))
        def branch(x, y, a, ln, wdt, dep):
            if dep == 0 or wdt < 1:
                return
            x2 = x + math.sin(a) * ln
            y2 = y - math.cos(a) * ln
            d.line([(x, y), (x2, y2)], fill=(*col, 255), width=max(2, int(wdt)))
            # 枝の 上に 積もった 雪
            d.line([(x, y - wdt * .4), (x2, y2 - wdt * .4)],
                   fill=(242, 246, 252, 210), width=max(1, int(wdt * .55)))
            for s_ in (-1, 1):
                branch(x2, y2, a + s_ * r.uniform(0.32, 0.58),
                       ln * r.uniform(0.66, 0.78), wdt * 0.66, dep - 1)
        for a0 in (-0.62, -0.2, 0.22, 0.6):
            branch(cx, base - 74 * scale, a0, 44 * scale, 9 * scale, 4)
    bare(240, HOR - 4, 0.62, 17)
    bare(88, HOR + 10, 1.12, 5)
    bare(392, HOR + 5, 0.92, 9)
    d.rectangle([0, HOR, W, H], fill=(238, 241, 245, 255))
    d.rectangle([0, HOR, W, HOR + 3], fill=(252, 253, 255, 255))
    b = random.Random(3)
    for _ in range(36):
        x, y = b.uniform(0, W), b.uniform(HOR + 8, H)
        rw, rh = b.uniform(22, 58), b.uniform(5, 12)
        d.ellipse([x - rw, y - rh, x + rw, y + rh], fill=(228, 233, 240, 150))
    specks(d, 90, 0, H, (255, 255, 255), 1.0, 2.4, 6, 150, 235)
    return img


def v10_sugi():
    """杉林 ── 参道と 鳥居"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (118, 168, 206)), (0.52, (168, 200, 222)), (1, (214, 228, 228))])

    # ★遠景の 山
    ridge(d, HOR - 46, 11, (128, 156, 142, 255), 2.5)

    C_FAR = [(86, 124, 96), (104, 146, 110), (122, 166, 124)]
    C_MID = [(58, 96, 70), (74, 116, 82), (92, 138, 96)]
    C_NEAR = [(38, 68, 52), (50, 84, 62), (64, 102, 74)]

    # ★奥の 林 ── 小さく、薄く
    r = random.Random(29)
    for x in range(-10, W + 40, 38):
        conifer(d, x + r.randint(-6, 6), HOR - 10, 0.44, C_FAR, x)

    # ★参道 ── 奥へ すぼまる。★これが 絵の 芯
    CX = 240
    d.polygon([(CX - 16, HOR - 12), (CX + 16, HOR - 12),
               (CX + 108, H), (CX - 108, H)], fill=(178, 166, 146, 255))
    # 敷石
    st = random.Random(3)
    for k in range(9):
        t = k / 8
        y = HOR - 12 + (H - (HOR - 12)) * (t ** 1.6)
        hw = 16 + 92 * (t ** 1.6)
        d.line([(CX - hw, y), (CX + hw, y)],
               fill=(160, 148, 128, int(120 + 90 * t)), width=max(1, int(1 + t * 3)))

    # ★中景の 林 ── 参道を あけて 両側に
    for x in range(-24, W + 50, 58):
        if abs(x - CX) < 62:
            continue
        conifer(d, x + r.randint(-8, 8), HOR + 2, 0.74, C_MID, x + 7)

    # ★鳥居 ── ★明神鳥居（2026-09-18 調べ／★2度目の 直し）
    #   ★1度目の 誤り
    #     ・額束を 貫まで 伸ばした → ★3本目の 柱に 見えた
    #     ・笠木を 島木より 薄くした → ★上下が 逆
    #     ・反りが 強すぎた → ★中央が 凹んで 見えた
    #   ★直した 比率（柱の 内のり幅 D を 1 とする）
    #     高さ  1.30D ／ 笠木の 長さ 1.62D ／ 島木 1.42D
    #     貫の 高さ  柱の 0.62 の ところ（★上寄り）
    #     額束  島木の 下から 貫の 上まで。★短い
    def torii(cx, base, scale):
        AKA   = (182, 72, 58)
        AKA_D = (138, 46, 40)
        AKA_L = (206, 104, 86)

        D  = 84 * scale               # 柱の 内のり（間隔）
        hd = D / 2
        hh = D * 1.30                 # 高さ
        pw = D * 0.085                # 柱の 太さ（半分）
        korobi = D * 0.055            # ★内転

        y_kasa_t = base - hh          # 笠木 上
        kh       = D * 0.095          # 笠木の 厚み  ★島木より 厚い
        y_kasa_b = y_kasa_t + kh
        sh       = D * 0.075          # 島木の 厚み
        y_shi_t  = y_kasa_b
        y_shi_b  = y_shi_t + sh
        y_nuki_t = base - hh * 0.58   # ★貫 ── ★もっと 上。額束を 短く
        nh       = D * 0.065
        y_nuki_b = y_nuki_t + nh

        # ── 柱（★内転。上ほど 内へ）
        for sgn in (-1, 1):
            xb = cx + sgn * hd
            xt = cx + sgn * (hd - korobi)
            d.polygon([(xb - pw, base), (xb + pw, base),
                       (xt + pw * 0.88, y_shi_b), (xt - pw * 0.88, y_shi_b)],
                      fill=(*AKA, 255))
            d.line([(xb - pw * 0.5, base), (xt - pw * 0.44, y_shi_b)],
                   fill=(*AKA_L, 255), width=max(1, int(D * 0.026)))
            d.line([(xb + pw * 0.58, base), (xt + pw * 0.52, y_shi_b)],
                   fill=(*AKA_D, 255), width=max(1, int(D * 0.030)))

        # ── 貫 ── ★柱の 外へ 少し 突き出る
        nx = hd + pw * 2.2
        d.rectangle([cx - nx, y_nuki_t, cx + nx, y_nuki_b], fill=(*AKA, 255))
        d.line([(cx - nx, y_nuki_t + D * 0.012), (cx + nx, y_nuki_t + D * 0.012)],
               fill=(*AKA_L, 255), width=max(1, int(D * 0.020)))

        # ── 楔
        for sgn in (-1, 1):
            xk = cx + sgn * (hd - korobi * 0.5)
            d.rectangle([xk - D * 0.026, y_nuki_t - D * 0.020,
                         xk + D * 0.026, y_nuki_b + D * 0.020],
                        fill=(*AKA_D, 255))

        # ── ★額束 ── ★島木の 下から 貫の 上まで。★これだけ
        # ★細く。★柱（pw）より 細いこと。★太いと 3本目の 柱に 見えます
        gw = pw * 0.52
        d.rectangle([cx - gw, y_shi_b, cx + gw, y_nuki_t], fill=(*AKA, 255))
        d.line([(cx - gw * 0.35, y_shi_b), (cx - gw * 0.35, y_nuki_t)],
               fill=(*AKA_L, 255), width=1)

        # ── 島木 ── 笠木より 短く、薄い。★わずかに 反る
        sw = D * 0.71
        n = 30
        top, bot = [], []
        for k in range(n + 1):
            t = k / n
            x = cx - sw + 2 * sw * t
            rise = ((t - 0.5) * 2) ** 2 * D * 0.030
            top.append((x, y_shi_t - rise))
            bot.append((x, y_shi_b - rise))
        d.polygon(top + bot[::-1], fill=(*AKA, 255))
        for k in range(n):
            d.line([bot[k], bot[k + 1]], fill=(*AKA_D, 255),
                   width=max(1, int(sh * 0.40)))

        # ── 笠木 ── ★島木より 長く、★厚い。★反りは ひかえめ
        kw = D * 0.81
        top, bot = [], []
        for k in range(n + 1):
            t = k / n
            x = cx - kw + 2 * kw * t
            rise = ((t - 0.5) * 2) ** 2 * D * 0.052
            top.append((x, y_kasa_t - rise))
            bot.append((x, y_kasa_b - rise))
        # ★端は 下へ 斜めに 切る
        top[0]  = (top[0][0] + D * 0.030, top[0][1])
        top[-1] = (top[-1][0] - D * 0.030, top[-1][1])
        # ★★大きく 描いて 縮める ── ★端の ぎざぎざを 消す
        SS = 4
        big = Image.new('RGBA', (W * SS, H * SS), (0, 0, 0, 0))
        bd = ImageDraw.Draw(big)
        bd.polygon([(x * SS, y * SS) for x, y in top]
                   + [(x * SS, y * SS) for x, y in bot[::-1]], fill=(*AKA, 255))
        bd.line([(x * SS, y * SS) for x, y in top], fill=(*AKA_L, 255),
                width=max(1, int(kh * 0.34 * SS)), joint='curve')
        bd.line([(x * SS, y * SS) for x, y in bot], fill=(*AKA_D, 255),
                width=max(1, int(kh * 0.26 * SS)), joint='curve')
        d._image.alpha_composite(
            big.resize((W, H), Image.LANCZOS))

    torii(CX, HOR + 30, 0.78)

    # ★手前の 林 ── 大きく、暗く。★左右の 端だけ
    for x in (-26, 22, 452, 500):
        conifer(d, x + r.randint(-6, 6), H - 4, 1.35, C_NEAR, x + 11)

    # ★下草
    g = random.Random(51)
    for _ in range(150):
        x, y = g.uniform(0, W), g.uniform(HOR + 6, H)
        if abs(x - CX) < 20 + (y - HOR) * 0.45:
            continue
        t = (y - HOR) / (H - HOR)
        d.line([(x, y), (x + g.uniform(-1.6, 1.6), y - g.uniform(3, 7))],
               fill=(*lerp((104, 138, 92), (52, 82, 62), t), 255))

    # ★木もれ日 ── ★薄く。★2本だけ
    ray = canvas(W, H)
    rd = ImageDraw.Draw(ray)
    for cx0, w0, w1 in [(150, 14, 44), (330, 10, 34)]:
        rd.polygon([(cx0 - w0, 0), (cx0 + w0, 0),
                    (cx0 + w1 + 26, H), (cx0 - w1 + 26, H)],
                   fill=(255, 250, 226, 15))
    img.alpha_composite(ray.filter(ImageFilter.GaussianBlur(13)))
    return img


def v11_umi():
    """海"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (106, 168, 216)), (0.60, (166, 206, 234)), (1, (216, 234, 240))])
    clouds(img, [(120, 66, 220, 17, 220), (366, 112, 180, 12, 180)],
           (255, 255, 255), (255, 255, 255), (208, 220, 234), blur=2, seed=33)
    d = ImageDraw.Draw(img)
    # 海 ── 遠いほど 明るい
    for y in range(HOR, H):
        t = (y - HOR) / (H - HOR)
        d.line([(0, y), (W, y)],
               fill=(*lerp((104, 162, 186), (44, 92, 134), t), 255))
    d.rectangle([0, HOR, W, HOR + 2], fill=(206, 228, 236, 255))
    # 波
    r = random.Random(37)
    for _ in range(90):
        y = r.uniform(HOR + 6, H - 4)
        t = (y - HOR) / (H - HOR)
        x = r.uniform(0, W)
        ln = r.uniform(10, 30) * (0.5 + t)
        d.line([(x, y), (x + ln, y)],
               fill=(226, 240, 246, int(60 + 120 * (1 - t))), width=max(1, int(1 + t * 2)))
    return img


def v12_sakura():
    """桜"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (152, 190, 224)), (0.60, (198, 218, 236)), (1, (232, 234, 234))])
    ridge(d, HOR - 36, 9, (168, 186, 190, 255), 2.3)
    P = [(232, 176, 196), (250, 206, 220), (255, 230, 238)]
    tree_round(d, 250, HOR - 6, 0.58, P, 13)
    tree_round(d, 72, HOR + 8, 1.05, P, 5)
    tree_round(d, 404, HOR + 4, 0.86, P, 9)
    grass(d, (148, 178, 120), (84, 116, 78), (132, 168, 108))
    specks(d, 44, 40, H - 10, (255, 222, 232), 1.6, 3.2, 31, 150, 235)
    return img


def v13_machiakari():
    """街あかり"""
    img = canvas(W, H); d = ImageDraw.Draw(img)
    sky(d, [(0, (26, 30, 58)), (0.52, (52, 56, 96)),
            (0.82, (110, 92, 118)), (1, (168, 124, 114))])
    s = random.Random(1017)
    for _ in range(70):
        x, y = s.uniform(0, W), s.uniform(4, HOR * 0.5)
        a = int(190 * (1 - y / (HOR * 0.5)))
        d.ellipse([x - .8, y - .8, x + .8, y + .8], fill=(255, 252, 240, a))

    def blocks(y_base, hmin, hmax, col, win_a, seed, wmin=18, wmax=44):
        r = random.Random(seed)
        x = -10
        while x < W + 10:
            bw, bh = r.randint(wmin, wmax), r.randint(hmin, hmax)
            d.rectangle([x, y_base - bh, x + bw, y_base], fill=(*col, 255))
            for wy in range(int(y_base - bh) + 7, int(y_base) - 6, 11):
                for wx in range(int(x) + 5, int(x + bw) - 5, 9):
                    if r.random() < 0.42:
                        c = r.choice([(255, 224, 150), (255, 240, 200), (196, 216, 255)])
                        d.rectangle([wx, wy, wx + 3, wy + 4], fill=(*c, win_a))
            x += bw + r.randint(2, 6)

    blocks(HOR - 22, 26, 66, (44, 46, 76), 150, 3)
    blocks(HOR - 8, 34, 88, (32, 34, 58), 205, 7)
    blocks(HOR + 4, 42, 110, (22, 24, 42), 245, 11, 22, 54)
    d.rectangle([0, HOR + 4, W, H], fill=(20, 24, 40, 255))
    refl = canvas(W, H)
    rd = ImageDraw.Draw(refl)
    r = random.Random(5)
    for _ in range(150):
        x, y = r.uniform(0, W), r.uniform(HOR + 8, H)
        c = r.choice([(255, 224, 150), (196, 216, 255), (255, 200, 170)])
        rd.line([(x, y), (x, y + r.uniform(4, 16))],
                fill=(*c, r.randint(24, 76)), width=2)
    img.alpha_composite(refl.filter(ImageFilter.GaussianBlur(2)))
    return img


# ══ 一覧 ══════════════════════════════════════════════
VIEWS = [
    ('view_01', '晴れ',       v01_hare),
    ('view_02', '夕焼け',     v02_yuuyake),
    ('view_03', '夜',         v03_yoru),
    ('view_04', '雨',         v04_ame),
    ('view_05', '雪',         v05_yuki),
    ('view_06', '朝もや',     v06_asamoya),
    ('view_07', '新緑',       v07_shinryoku),
    ('view_08', '紅葉',       v08_kouyou),
    ('view_09', '枯れ木と雪', v09_kareki),
    ('view_10', '杉林と鳥居', v10_sugi),
    ('view_11', '海',         v11_umi),
    ('view_12', '桜',         v12_sakura),
    ('view_13', '街あかり',   v13_machiakari),
]


def main(only=None):
    os.makedirs(OUT, exist_ok=True)
    man = []
    for i, (key, name, fn) in enumerate(VIEWS, 1):
        if only and i not in only:
            continue
        fn().save(f'{OUT}/{key}.png')
        man.append({'key': key, 'category': 'view', 'name': name,
                    'src': f'/assets/home/view/{key}.png',
                    'width': W, 'height': H})
        print(f'  {i:2d} {key}  {name}')
    if not only:
        json.dump(man, open(f'{OUT}/manifest.json', 'w'),
                  ensure_ascii=False, indent=1)
        print(f'manifest {len(man)} 件')


if __name__ == '__main__':
    args = [int(a) for a in sys.argv[1:] if a.isdigit()]
    main(args or None)
