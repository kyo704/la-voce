from PIL import Image, ImageDraw
import numpy as np, math
from era import sh, li, new, W, H, body, head, jaw, CX
from acc import bake_ears

def top_y(x): return max(jaw(x)-14, 592-150*((x-CX)/300.0)**2)
APEX_Y=379.0; HEM=958.0
# 胸→腰でいったん締まって、そこから広がる（ドレスの形）
KEY=[(596,206),(680,180),(756,158),(820,222),(890,296),(HEM,340)]
def cone(y, k=1.0, wmax=352):
    sc = wmax/340.0
    if y<=KEY[0][0]:
        return KEY[0][1]*sc
    for i in range(len(KEY)-1):
        y0,w0=KEY[i]; y1,w1=KEY[i+1]
        if y<=y1:
            t=(y-y0)/(y1-y0)
            t=t**k if y0>=756 else t
            return (w0+(w1-w0)*t)*sc
    w=KEY[-1][1]*sc
    if y>HEM-30:
        u=(y-(HEM-30))/30.0; w*=(1-0.20*u*u)
    return w

def _fill(a, col, k, wmax, shrink=0, ytop=560, ybot=HEM, pattern=None):
    for y in range(int(ytop), int(min(H,ybot))):
        hw=cone(y,k,wmax)-shrink
        if hw<=0: continue
        for x in range(max(0,int(CX-hw)), min(W,int(CX+hw)+1)):
            if y<top_y(x): continue
            base = pattern(x,y,col) if pattern else col
            u=(x-CX)/max(1.0,hw)
            if u<-0.55:  base=li(base,0.16)          # 左からの光
            elif u>0.42: base=sh(base,0.16)          # 右のかげ
            a[y,x]=(*base,255)

def P_star(c2, step=112):
    def f(x,y,b):
        gx,gy=x%step-step//2, y%step-step//2
        for k in range(4):
            a=k*math.pi/4
            if abs(gx*math.sin(a)-gy*math.cos(a))<5 and abs(gx*math.cos(a)+gy*math.sin(a))<26: return c2
        return b
    return f
def P_velvet(c2):
    return lambda x,y,b:(c2 if (x*3+y*5)%37<6 else b)
def P_lace(c2, step=54):
    def f(x,y,b):
        gx,gy=x%step-step//2,y%step-step//2
        d=math.hypot(gx,gy)
        return c2 if 15<d<21 or d<5 else b
    return f
def P_feather(c2,c3):
    def f(x,y,b):
        yy=y%56; xx=(x+(y//56)*28)%56-28
        if yy<7: return sh(b,0.2)
        return c2 if abs(xx)<18-yy*0.2 else c3
    return f

def gown(col, k=0.62, wmax=352, pattern=None, bodice=None, waist=None,
         strap='thin', hem_band=None, deco=None):
    a=np.zeros((H,W,4),'uint8')
    _fill(a, col, k, wmax, 0, 560, HEM, pattern)
    l=Image.fromarray(a); d=ImageDraw.Draw(l)
    if hem_band:
        b2=np.array(l)
        for y in range(int(HEM)-34,int(HEM)):
            hw=cone(y,k,wmax)
            for x in range(int(CX-hw),int(CX+hw)+1):
                if 0<=x<W: b2[y,x]=(*hem_band,255)
        l=Image.fromarray(b2); d=ImageDraw.Draw(l)
    if bodice:      # 身頃（上半身を別色に）
        b2=np.array(l)
        for y in range(560,742):
            hw=cone(y,k,wmax)
            for x in range(int(CX-hw),int(CX+hw)+1):
                if 0<=x<W and y>=top_y(x): b2[y,x]=(*bodice,255)
        l=Image.fromarray(b2); d=ImageDraw.Draw(l)
    if strap=='thin':   # 細い肩ひも
        for s in (-1,1):
            d.line([(CX+s*118,int(top_y(CX+s*118))-4),(CX+s*84,704)], fill=(*li(bodice or col,0.20),255), width=26)
    elif strap=='off':  # オフショルダー（胸元をまっすぐに）
        hwb=cone(636,k,wmax)
        d.polygon([(CX-hwb,608),(CX+hwb,608),(CX+hwb,646),(CX-hwb,646)], fill=(*li(bodice or col,0.18),255))
    if waist:
        hw=cone(752,k,wmax)
        d.polygon([(CX-hw,736),(CX+hw,736),(CX+hw+4,776),(CX-hw-4,776)], fill=(*waist,255))
        d.ellipse([CX-30,738,CX+30,776], fill=(*li(waist,0.44),255))
    for s2 in (-3,-2,-1,1,2,3):
        x0=CX+s2*26; hw2=cone(HEM-40,k,wmax)
        d.line([(x0,790),(CX+s2*hw2/3.4,HEM-16)], fill=(*sh(col,0.13),255), width=6)
    if deco: deco(d)
    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x))),x]=(0,0,0,0)
    return Image.fromarray(a)

def PH(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return bake_ears(l)

# ══ 本番のドレス 4 ═══════════════════════════════════
GOWNS=[
 ('gownBlackLong','本番の黒いドレス', gown((36,34,42), 0.66, 340, P_velvet((52,50,60)),
      bodice=(58,56,68), waist=(20,18,26), strap='thin')),
 ('gownWineMermaid','ワインレッドのドレス', gown((124,18,42), 0.86, 322, None,
      bodice=(158,32,62), waist=(206,176,104), strap='off', hem_band=(150,26,52))),
 ('gownGreenVelvet','深緑のベルベット', gown((30,74,62), 0.62, 348, P_velvet((44,96,80)),
      bodice=(52,104,88), waist=(212,184,116), strap='thin')),
 ('gownGoldALine','うすい金のドレス', gown((216,190,132), 0.58, 360, P_lace((234,214,168)),
      bodice=(238,224,186), waist=(190,156,88), strap='thin', hem_band=(232,212,168))),
]

# ══ オペラの役 4 ═════════════════════════════════════
def _stars(d):
    for (x,y,r) in [(360,800,22),(660,780,18),(430,900,16),(600,890,20),(511,690,14),(300,880,14),(722,880,15)]:
        for k in range(4):
            a=k*math.pi/4
            d.line([(x-r*math.cos(a),y-r*math.sin(a)),(x+r*math.cos(a),y+r*math.sin(a))],
                   fill=(244,238,200,255), width=6)
def _camellia(d):
    for (x,y) in [(392,824),(628,796),(470,912)]:
        for k in range(6):
            a=k*math.pi/3
            d.ellipse([x+26*math.cos(a)-20,y+26*math.sin(a)-20,x+26*math.cos(a)+20,y+26*math.sin(a)+20],
                      fill=(206,44,64,255))
        d.ellipse([x-14,y-14,x+14,y+14], fill=(244,226,140,255))
def _frills(d):
    for i,yy in enumerate((826,876,926)):
        for x in range(int(CX-cone(yy)),int(CX+cone(yy)),64):
            d.pieslice([x-34,yy-30,x+34,yy+30],0,180, fill=((28,26,32) if i%2==0 else (52,48,56))+(255,))

OPERA=[
 ('operaQueenNight','夜の女王（魔笛）', gown((28,34,78), 0.60, 356, P_star((234,226,180)),
      bodice=(52,62,116), waist=(206,190,128), strap='thin', deco=_stars)),
 ('operaVioletta','ヴィオレッタ（椿姫）', gown((246,242,238), 0.58, 356, P_lace((228,222,214)),
      bodice=(252,250,248), waist=(206,44,64), strap='off', deco=_camellia)),
 ('operaCarmen','カルメン', gown((186,26,44), 0.80, 336, None,
      bodice=(214,52,72), waist=(28,26,32), strap='off', deco=_frills)),
 ('operaPapageno','パパゲーノ（魔笛）', gown((70,132,96), 0.70, 300, P_feather((96,166,116),(58,116,84)),
      bodice=(212,180,86), waist=(150,110,54), strap='thin')),
]

# ══ 髪かざり・かんむり 4 ═════════════════════════════
def h_crown():
    def f(d):
        d.polygon([(320,286),(702,286),(676,96),(596,206),(511,72),(426,206),(346,96)], fill=(214,178,92,255))
        d.rectangle([320,272,702,320], fill=(186,146,64,255))
        for (x,y,c) in [(400,150,(96,120,190)),(511,116,(206,60,80)),(622,150,(96,150,120))]:
            d.ellipse([x-22,y-22,x+22,y+22], fill=(*c,255))
    return PH(f)
def h_camellia():
    def f(d):
        d.arc([288,120,734,392],188,352, fill=(52,48,44,255), width=16)
        for (x,y,r) in [(330,214,44),(400,152,36),(690,214,44)]:
            for k in range(6):
                a=k*math.pi/3
                d.ellipse([x+r*0.75*math.cos(a)-r*0.6,y+r*0.75*math.sin(a)-r*0.6,
                           x+r*0.75*math.cos(a)+r*0.6,y+r*0.75*math.sin(a)+r*0.6], fill=(240,244,246,255))
            d.ellipse([x-r*0.4,y-r*0.4,x+r*0.4,y+r*0.4], fill=(244,226,140,255))
            d.arc([x-r*0.9,y-r*0.9,x+r*0.9,y+r*0.9],0,360, fill=(196,190,180,255), width=5)
    return PH(f)
def h_rose():
    def f(d):
        d.arc([288,120,734,392],188,352, fill=(40,36,42,255), width=18)
        x,y=666,206
        for k in range(7):
            a=k*2*math.pi/7
            d.ellipse([x+34*math.cos(a)-30,y+34*math.sin(a)-30,x+34*math.cos(a)+30,y+34*math.sin(a)+30],
                      fill=(196,28,48,255))
        d.ellipse([x-26,y-26,x+26,y+26], fill=(154,18,36,255))
        d.ellipse([x-12,y-12,x+12,y+12], fill=(226,80,96,255))
    return PH(f)
def h_feather():
    def f(d):
        for i,c in enumerate([(58,116,84),(96,166,116),(212,180,86),(96,166,116),(58,116,84)]):
            x=511+(i-2)*74
            d.polygon([(x,282),(x-30,120-abs(i-2)*30),(x,44-abs(i-2)*36),(x+30,120-abs(i-2)*30)], fill=(*c,255))
        d.rounded_rectangle([300,258,722,326],28, fill=(150,110,54,255))
        d.rounded_rectangle([300,258,722,290],20, fill=(178,138,78,255))
    return PH(f)

STAGE_HATS=[('hatCrownNight','夜の女王のかんむり',h_crown()),
            ('hatCamellia','椿の髪かざり',h_camellia()),
            ('hatRose','薔薇の髪かざり',h_rose()),
            ('hatFeatherCap','羽根のかぶりもの',h_feather())]

if __name__=='__main__':
    S=300; cols=6
    lst=[(k,n,g,'g') for k,n,g in GOWNS+OPERA]+[(k,n,g,'h') for k,n,g in STAGE_HATS]
    rows=(len(lst)+cols-1)//cols
    sheet=Image.new('RGBA',(S*cols+22*(cols+1),(S+22)*rows+22),(247,242,230,255))
    for i,(k,n,g,kind) in enumerate(lst):
        p=new(); p.alpha_composite(body)
        if kind=='g': p.alpha_composite(g)
        p.alpha_composite(head)
        if kind=='h': p.alpha_composite(g)
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(22+(S+22)*(i%cols),22+(S+22)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-ドレスとオペラ12点.png')
    print('ok')
