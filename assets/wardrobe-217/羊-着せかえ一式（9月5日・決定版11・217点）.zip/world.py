from PIL import Image, ImageDraw
import numpy as np, math
from era import make, P_none, P_stripe, P_check, P_dots, P_sakura, P_karakusa, P_shima, sh, li, new, W, H, body, head, jaw, CX, top_y
from acc import bake_ears

def P_tartan(c2,c3,w=44):
    def f(x,y,b):
        a=(x//w)%4; c=(y//w)%4
        if a==0 or c==0: return c2
        if a==2 and c==2: return c3
        return b
    return f
def P_flower(c2,c3,step=96):
    def f(x,y,b):
        gx,gy=x%step-step//2, y%step-step//2
        d0=math.hypot(gx,gy)
        if d0<11: return c3
        for k in range(6):
            a=k*math.pi/3
            if math.hypot(gx-24*math.cos(a),gy-24*math.sin(a))<13: return c2
        return b
    return f
def P_embroid(c2,step=64):
    def f(x,y,b):
        gx,gy=x%step-step//2,y%step-step//2
        return c2 if abs(abs(gx)-abs(gy))<5 or (abs(gx)<5 and abs(gy)<18) else b
    return f
def P_denim(c2):
    return lambda x,y,b:(c2 if (x+y)%9<3 else b)

def PH(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return bake_ears(l)
def PP(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return l

# ════ 服 13 ════════════════════════════════════════════
DRESS=dict(sleeve='tube', collar='round')
GARMENTS=[
('wearUSAWestern','アメリカ・ウエスタン', make(col=(96,124,166), hem_y=800, pattern=P_denim((110,138,180)),
   sleeve='tube', collar='v', collar_col=(226,222,212), belt='belt', belt_col=(120,84,54), over=(146,104,66))),
('wearHawaiiAloha','ハワイ・アロハとムームー', make(col=(58,150,150), hem_y=880, pattern=P_flower((248,214,150),(240,120,110)),
   sleeve='short', collar='v', collar_col=(238,246,242), belt=None)),
('wearItalyCarnival','イタリア・カーニバルのマント', make(col=(58,44,96), hem_y=886, pattern=P_dots((214,178,92),96,13),
   sleeve='wide', collar='round', collar_col=(214,178,92), belt=None, over=(40,30,72))),
('wearGermanyLederhosen','ドイツ・レーダーホーゼン', make(col=(238,234,224), hem_y=724, sleeve='tube',
   collar='stand', collar_col=(222,216,202), belt=None,
   hakama=(140,100,64), hakama_hem=862, suspenders=(112,76,46))),
('wearFranceMariniere','フランス・マリニエール', make(col=(240,240,236), hem_y=792, pattern=P_stripe((52,72,132),26),
   sleeve='tube', collar='round', collar_col=(240,240,236), belt=None)),
('wearNetherlandsVolendam','オランダ・フォーレンダム', make(col=(46,72,132), hem_y=884, pattern=P_stripe((60,90,158),30),
   sleeve='tube', collar='round', collar_col=(244,242,236), belt='sash', belt_col=(178,44,56),
   apron=(238,236,228))),
('wearSwissAppenzell','スイス・アッペンツェル', make(col=(198,44,54), hem_y=730, pattern=P_embroid((236,228,206)),
   sleeve='tube', collar='v', collar_col=(244,242,236), belt='belt', belt_col=(40,44,52),
   hakama=(36,40,50), hakama_hem=880)),
('wearSpainFlamenco','スペイン・フラメンコ', make(col=(190,32,48), hem_y=896, pattern=P_dots((250,246,240),58,13),
   sleeve='puff', collar='v', collar_col=(240,60,76), belt='sash', belt_col=(140,20,36),
   kasane=[(214,52,68),(240,90,104),(250,246,240)])),
('wearChinaHanfu','中国・漢服', make(col=(206,40,58), hem_y=886, pattern=P_karakusa((236,196,110)),
   sleeve='wide', collar='kimono', collar_col=(244,238,222), belt='sash', belt_col=(236,196,110),
   plate=(246,226,236))),
('wearKoreaHanbok','韓国・韓服', make(col=(238,238,240), hem_y=896, sleeve='wide', sleeve_col=(228,228,232),
   collar='v', collar_col=(214,60,78), belt='sash', belt_col=(214,60,78),
   hakama=(112,60,148), hakama_hem=920)),
('wearRussiaSarafan','ロシア・サラファン', make(col=(178,32,48), hem_y=894, pattern=P_flower((248,232,180),(240,190,90)),
   sleeve='puff', sleeve_col=(246,244,238), collar='round', collar_col=(246,244,238),
   belt='sash', belt_col=(236,196,110), hem_band=(236,196,110))),
('wearAustriaCourt','オーストリア・宮廷服', make(col=(52,86,140), hem_y=850, pattern=P_karakusa((80,120,180)),
   sleeve='wide', collar='none', belt=None, buttons=3, ruff=(248,246,240))),
('wearUKKilt','イギリス・キルト', make(col=(46,52,66), hem_y=724, sleeve='tube',
   collar='v', collar_col=(238,236,230), belt='belt', belt_col=(48,42,38),
   hakama=(122,36,44), hakama_hem=876, hakama_pattern=P_tartan((36,44,72),(226,206,120),40))),
]

# ════ 帽子 13 ══════════════════════════════════════════
def hw_cowboy():
    C=(146,104,66)
    def f(d):
        d.ellipse([132,196,890,352], fill=(*C,255))
        d.ellipse([132,196,890,312], fill=(*li(C,0.16),255))
        d.rounded_rectangle([336,64,686,266],96, fill=(*C,255))
        d.line([(511,72),(511,240)], fill=(*sh(C,0.16),255), width=26)
        d.rectangle([336,214,686,266], fill=(*sh(C,0.32),255))
    return PH(f)
def hw_hibiscus():
    def f(d):
        cols=[(240,90,110),(250,196,90),(246,140,180),(250,236,170),(238,110,90)]
        pts=[(286,244),(340,180),(404,138),(466,114),(511,108),(556,114),(618,138),(682,180),(736,244)]
        for i,(x,y) in enumerate(pts):
            c=cols[i%5]
            for k in range(5):
                a=k*2*math.pi/5-math.pi/2
                d.ellipse([x+32*math.cos(a)-23,y+32*math.sin(a)-23,x+32*math.cos(a)+23,y+32*math.sin(a)+23], fill=(*c,255))
            d.ellipse([x-16,y-16,x+16,y+16], fill=(250,226,140,255))
        d.arc([272,110,750,392],186,354, fill=(122,158,110,255), width=14)
    return PH(f)
def hw_tricorno():
    C=(40,32,68)
    def f(d):
        d.polygon([(146,300),(876,300),(722,150),(511,96),(300,150)], fill=(*C,255))
        d.polygon([(146,300),(511,300),(511,96),(300,150)], fill=(*li(C,0.14),255))
        d.rounded_rectangle([362,96,660,268],90, fill=(*sh(C,0.14),255))
        d.ellipse([146,282,876,344], fill=(*sh(C,0.24),255))
        for k in range(3):
            d.polygon([(660,150-k*8),(790,60-k*26),(864,58-k*22),(806,116-k*16),(692,196-k*6)],
                      fill=(*((236,196,96) if k%2==0 else (206,166,72)),255))
    return PH(f)
def hw_tirol(col=(64,92,72), fe=(178,52,60)):
    def f(d):
        d.ellipse([196,204,826,326], fill=(*col,255))
        d.ellipse([196,204,826,296], fill=(*li(col,0.16),255))
        d.rounded_rectangle([336,66,686,254],96, fill=(*col,255))
        d.rectangle([336,200,686,252], fill=(*sh(col,0.30),255))
        for k in range(3):
            d.polygon([(668,180-k*8),(742,80-k*24),(790,74-k*20),(752,140-k*14),(696,214-k*6)], fill=(*fe,255))
        d.ellipse([644,190,700,246], fill=(236,232,220,255))
    return PH(f)
def hw_beret_fr():
    C=(38,36,42)
    def f(d):
        d.ellipse([248,66,774,282], fill=(*C,255))
        d.ellipse([248,66,774,236], fill=(*li(C,0.20),255))
        d.ellipse([296,226,726,300], fill=(*sh(C,0.3),255))
        d.ellipse([478,36,544,102], fill=(*sh(C,0.2),255))
    return PH(f)
def hw_dutch():
    def f(d):
        OUT=(196,190,176)
        d.polygon([(258,300),(764,300),(706,110),(316,110)], fill=(*OUT,255))
        d.polygon([(258,300),(200,192),(316,110)], fill=(*OUT,255))
        d.polygon([(764,300),(822,192),(706,110)], fill=(*OUT,255))
        d.polygon([(268,290),(754,290),(700,120),(322,120)], fill=(252,250,246,255))
        d.polygon([(268,290),(511,290),(511,120),(322,120)], fill=(240,238,230,255))
        d.polygon([(270,288),(212,196),(322,120)], fill=(252,250,246,255))
        d.polygon([(752,288),(810,196),(700,120)], fill=(252,250,246,255))
        for x in range(300,730,44):
            d.line([(x,142),(x,276)], fill=(216,212,200,255), width=4)
    return PH(f)
def hw_edelweiss():
    C=(44,50,44)
    def f(d):
        d.ellipse([214,206,808,322], fill=(*C,255))
        d.rounded_rectangle([340,72,682,258],92, fill=(*C,255))
        d.rectangle([340,206,682,256], fill=(214,196,150,255))
        x,y=660,196
        for k in range(6):
            a=k*math.pi/3
            d.ellipse([x+28*math.cos(a)-19,y+28*math.sin(a)-13,x+28*math.cos(a)+19,y+28*math.sin(a)+13], fill=(250,248,240,255))
        d.ellipse([x-14,y-14,x+14,y+14], fill=(246,214,110,255))
    return PH(f)
def hw_mantilla():
    def f(d):
        d.polygon([(500,50),(522,50),(556,150),(466,150)], fill=(216,182,120,255))
        for k in range(7):
            d.line([(470+k*12,60),(470+k*12,150)], fill=(232,206,158,255), width=5)
        d.pieslice([176,84,846,470],180,360, fill=(38,34,44,255))
        d.pieslice([236,144,786,430],180,360, fill=(70,64,78,255))
        for x in range(208,822,44):
            u=(x-511)/336.0
            y=278-int(190*(max(0.0,1-u*u))**0.5)
            d.ellipse([x-19,y-6,x+19,y+30], fill=(38,34,44,255))
        d.polygon([(500,50),(522,50),(556,150),(466,150)], fill=(216,182,120,255))
    return PH(f)
def hw_china():
    def f(d):
        d.arc([286,120,736,396],188,352, fill=(196,36,52,255), width=22)
        for i,x in enumerate(range(330,700,46)):
            y=int(168+112*((x-511)/210.0)**2)
            d.ellipse([x-19,y-19,x+19,y+19], fill=((236,196,110) if i%2 else (196,36,52))+(255,))
        d.polygon([(511,62),(478,132),(544,132)], fill=(236,196,110,255))
        for s in (-1,1):
            d.line([(511+s*180,206),(511+s*220,340)], fill=(196,36,52,255), width=10)
    return PH(f)
def hw_korea():
    def f(d):
        d.rounded_rectangle([352,120,670,236],40, fill=(46,40,52,255))
        d.rounded_rectangle([352,120,670,178],32, fill=(70,62,78,255))
        d.ellipse([472,140,550,218], fill=(214,60,78,255))
        d.ellipse([492,160,530,198], fill=(236,196,110,255))
        for s in (-1,1):
            d.line([(511+s*140,220),(511+s*176,360)], fill=(214,60,78,255), width=12)
    return PH(f)
def hw_kokoshnik():
    def f(d):
        d.pieslice([258,42,764,462],180,360, fill=(196,32,48,255))
        d.pieslice([300,84,722,420],180,360, fill=(236,196,110,255))
        d.pieslice([348,132,674,378],180,360, fill=(196,32,48,255))
        for k in range(7):
            a=math.radians(200+k*23)
            x=511+206*math.cos(a); y=252+206*math.sin(a)
            d.ellipse([x-16,y-16,x+16,y+16], fill=(248,246,238,255))
        for x in range(330,700,42):
            d.ellipse([x-11,272,x+11,320], fill=(248,246,238,255))
    return PH(f)
def hw_wig():
    C=(238,236,230); O=(184,180,170)
    def f(d):
        d.ellipse([258,38,764,340], fill=(*O,255))
        for cy in (150,222,290):
            for s2 in (-1,1):
                d.ellipse([511+s2*250-64,cy-52,511+s2*250+64,cy+52], fill=(*O,255))
        d.ellipse([268,48,754,330], fill=(*C,255))
        for cy in (150,222,290):
            for s2 in (-1,1):
                d.ellipse([511+s2*250-58,cy-46,511+s2*250+58,cy+46], fill=(*C,255))
                d.arc([511+s2*250-58,cy-46,511+s2*250+58,cy+46],0,360, fill=(*O,255), width=5)
        for x in range(312,714,50):
            d.arc([x-26,66,x+26,224],200,340, fill=(*O,255), width=6)
    return PH(f)
def hw_deerstalker():
    C=(148,132,104)
    def f(d):
        d.chord([176,192,846,352],0,180, fill=(*sh(C,0.18),255))
        d.polygon([(176,272),(230,192),(300,272)], fill=(*sh(C,0.18),255))
        d.polygon([(846,272),(792,192),(722,272)], fill=(*sh(C,0.18),255))
        d.rounded_rectangle([300,70,722,268],110, fill=(*C,255))
        d.rounded_rectangle([300,70,722,176],100, fill=(*li(C,0.16),255))
        for x in range(324,706,48):
            d.line([(x,84),(x+38,258)], fill=(*sh(C,0.12),255), width=8)
    return PH(f)

HATS=[('hatUSACowboy','アメリカ・カウボーイハット',hw_cowboy()),
 ('hatHawaiiHibiscus','ハワイ・ハイビスカスの花冠',hw_hibiscus()),
 ('hatItalyTricorno','イタリア・トリコルノ',hw_tricorno()),
 ('hatGermanyTirol','ドイツ・チロル帽',hw_tirol()),
 ('hatFranceBeret','フランス・ベレー（黒）',hw_beret_fr()),
 ('hatNetherlandsCap','オランダ・レースの帽子',hw_dutch()),
 ('hatSwissEdelweiss','スイス・エーデルワイスの帽子',hw_edelweiss()),
 ('hatSpainMantilla','スペイン・マンティージャ',hw_mantilla()),
 ('hatChinaOrnament','中国・花鈿の髪飾り',hw_china()),
 ('hatKoreaJokduri','韓国・チョクトゥリ',hw_korea()),
 ('hatRussiaKokoshnik','ロシア・ココシュニク',hw_kokoshnik()),
 ('hatAustriaWig','オーストリア・白いかつら',hw_wig()),
 ('hatUKDeerstalker','イギリス・ディアストーカー',hw_deerstalker())]

# ════ 持ち物 13 ════════════════════════════════════════
def pw_guitar():
    C=(198,150,92)
    def f(d):
        d.ellipse([352,700,660,952], fill=(*C,255))
        d.ellipse([386,660,626,830], fill=(*C,255))
        d.ellipse([470,772,554,856], fill=(60,48,38,255))
        d.rounded_rectangle([486,470,538,690],12, fill=(120,84,54,255))
        d.rounded_rectangle([472,432,552,486],10, fill=(78,58,44,255))
        for k in range(5):
            d.line([(490+k*8,690),(490+k*8,900)], fill=(236,228,208,255), width=3)
    return PP(f)
def pw_ukulele():
    C=(214,168,106)
    def f(d):
        d.ellipse([388,724,634,948], fill=(*C,255))
        d.ellipse([412,690,610,824], fill=(*C,255))
        d.ellipse([478,798,544,864], fill=(60,48,38,255))
        d.rounded_rectangle([490,540,532,712],10, fill=(132,94,58,255))
        d.rounded_rectangle([478,510,544,552],8, fill=(84,62,46,255))
        d.polygon([(600,700),(690,646),(700,690),(614,742)], fill=(240,120,110,255))
    return PP(f)
def pw_mask():
    def f(d):
        O=(120,104,140)
        d.polygon([(336,600),(686,600),(666,806),(511,952),(356,806)], fill=(*O,255))
        d.polygon([(348,612),(674,612),(654,800),(511,936),(368,800)], fill=(248,244,234,255))
        d.polygon([(348,612),(511,612),(511,936),(368,800)], fill=(234,228,214,255))
        d.polygon([(392,674),(486,660),(482,724),(396,720)], fill=(52,46,58,255))
        d.polygon([(632,674),(538,660),(542,724),(628,720)], fill=(52,46,58,255))
        d.polygon([(486,730),(536,730),(511,864)], fill=(224,216,198,255))
        d.rounded_rectangle([336,588,686,632],16, fill=(214,178,92,255))
        for k in range(3):
            d.polygon([(620,600-k*6),(724,516-k*24),(788,506-k*20),(736,566-k*14),(650,634-k*4)],
                      fill=(*((236,196,96) if k%2==0 else (206,166,72)),255))
    return PP(f)
def pw_pretzel():
    C=(176,116,64)
    def f(d):
        d.arc([362,650,660,948],0,360, fill=(*C,255), width=44)
        d.arc([392,690,530,828],20,300, fill=(*C,255), width=40)
        d.arc([492,690,630,828],240,160, fill=(*C,255), width=40)
        for k in range(10):
            a=k*math.pi/5
            d.ellipse([511+140*math.cos(a)-8,800+140*math.sin(a)-8,511+140*math.cos(a)+8,800+140*math.sin(a)+8], fill=(248,246,238,255))
    return PP(f)
def pw_baguette():
    C=(214,166,102)
    def f(d):
        d.rounded_rectangle([452,560,578,952],62, fill=(*C,255))
        d.rounded_rectangle([452,560,506,952],46, fill=(*li(C,0.16),255))
        for k in range(5):
            d.line([(478,632+k*62),(556,606+k*62)], fill=(*sh(C,0.24),255), width=9)
        d.rounded_rectangle([440,824,590,900],18, fill=(238,234,222,255))
    return PP(f)
def pw_tulip():
    def f(d):
        for i,(x,c) in enumerate([(430,(214,44,60)),(511,(238,180,60)),(592,(226,90,140))]):
            d.line([(x,948),(x+(i-1)*16,742)], fill=(112,150,104,255), width=11)
            d.polygon([(x-40+(i-1)*16,748),(x+40+(i-1)*16,748),(x+30+(i-1)*16,660),(x+(i-1)*16,690),(x-30+(i-1)*16,660)], fill=(*c,255))
        d.polygon([(324,900),(430,900),(414,952),(316,952)], fill=(228,196,128,255))
        d.polygon([(324,900),(300,846),(352,842),(360,898)], fill=(228,196,128,255))
    return PP(f)
def pw_cheese():
    C=(238,204,96)
    def f(d):
        d.polygon([(348,944),(674,944),(674,712),(348,842)], fill=(*C,255))
        d.polygon([(348,842),(674,712),(674,790),(348,920)], fill=(*li(C,0.22),255))
        for (x,y,r) in [(420,890,26),(516,866,20),(606,842,24),(466,820,15)]:
            d.ellipse([x-r,y-r,x+r,y+r], fill=(*sh(C,0.20),255))
    return PP(f)
def pw_abanico():
    def f(d):
        d.pieslice([226,506,796,1076],200,340, fill=(190,32,48,255))
        d.pieslice([290,570,732,1012],200,340, fill=(240,232,216,255))
        for k in range(9):
            a=math.radians(200+k*17.5)
            d.line([(511+36*math.cos(a),790+36*math.sin(a)),(511+284*math.cos(a),790+284*math.sin(a))],
                   fill=(52,46,44,255), width=6)
        for k in range(8):
            a=math.radians(209+k*17.5)
            d.ellipse([511+210*math.cos(a)-14,790+210*math.sin(a)-14,511+210*math.cos(a)+14,790+210*math.sin(a)+14], fill=(190,32,48,255))
        d.ellipse([492,772,530,810], fill=(52,46,44,255))
    return PP(f)
def pw_uchiwa():
    def f(d):
        d.ellipse([368,608,654,894], fill=(214,42,58,255))
        d.ellipse([392,632,630,870], fill=(240,232,214,255))
        d.ellipse([454,694,568,808], fill=(214,42,58,255))
        d.rounded_rectangle([492,860,530,952],14, fill=(150,110,74,255))
    return PP(f)
def pw_janggu():
    C=(160,60,52)
    def f(d):
        d.polygon([(360,668),(432,730),(432,862),(360,924)], fill=(*C,255))
        d.polygon([(662,668),(590,730),(590,862),(662,924)], fill=(*C,255))
        d.rectangle([432,730,590,862], fill=(*sh(C,0.2),255))
        d.ellipse([336,660,384,932], fill=(240,234,216,255))
        d.ellipse([638,660,686,932], fill=(240,234,216,255))
        for k in range(4):
            d.line([(432,748+k*34),(590,748+k*34)], fill=(232,196,110,255), width=7)
    return PP(f)
def pw_matryoshka():
    def f(d):
        d.ellipse([386,660,636,952], fill=(198,36,52,255))
        d.ellipse([408,636,614,820], fill=(244,236,220,255))
        d.ellipse([430,668,592,802], fill=(250,224,196,255))
        d.ellipse([466,712,492,738], fill=(58,48,44,255))
        d.ellipse([530,712,556,738], fill=(58,48,44,255))
        d.arc([482,748,540,782],0,180, fill=(180,90,80,255), width=7)
        d.ellipse([436,842,586,932], fill=(240,228,200,255))
        for (x,y) in [(478,872),(544,872),(511,904)]:
            d.ellipse([x-16,y-16,x+16,y+16], fill=(236,180,70,255))
    return PP(f)
def pw_sachertorte():
    def f(d):
        d.ellipse([352,876,670,952], fill=(240,238,232,255))
        d.polygon([(392,860),(630,860),(630,700),(392,700)], fill=(74,50,40,255))
        d.rectangle([392,700,630,724], fill=(52,34,28,255))
        d.rectangle([392,776,630,796], fill=(196,60,60,255))
        d.rounded_rectangle([448,636,574,700],10, fill=(52,34,28,255))
        d.ellipse([470,650,552,688], fill=(74,50,40,255))
    return PP(f)
def pw_tea():
    def f(d):
        O=(158,150,136)
        d.ellipse([326,732,610,942], fill=(*O,255))
        d.ellipse([336,742,600,932], fill=(248,244,238,255))
        d.ellipse([364,764,572,846], fill=(214,206,192,255))
        d.rounded_rectangle([434,682,502,752],16, fill=(*O,255))
        d.rounded_rectangle([440,690,496,746],14, fill=(248,244,238,255))
        d.polygon([(584,782),(700,752),(710,806),(596,830)], fill=(*O,255))
        d.polygon([(590,790),(692,762),(698,798),(600,822)], fill=(248,244,238,255))
        d.arc([294,754,382,866],90,270, fill=(*O,255), width=26)
        d.arc([300,760,376,860],90,270, fill=(248,244,238,255), width=18)
        d.ellipse([596,872,764,944], fill=(*O,255))
        d.ellipse([604,878,756,938], fill=(232,226,214,255))
        d.rounded_rectangle([620,826,740,894],22, fill=(*O,255))
        d.rounded_rectangle([626,832,734,888],20, fill=(250,246,240,255))
        d.ellipse([638,838,722,868], fill=(168,110,66,255))
    return PP(f)

PROPS=[('propUSAGuitar','アメリカ・ギター',pw_guitar()),('propHawaiiUkulele','ハワイ・ウクレレ',pw_ukulele()),
 ('propItalyMask','イタリア・仮面',pw_mask()),('propGermanyPretzel','ドイツ・プレッツェル',pw_pretzel()),
 ('propFranceBaguette','フランス・バゲット',pw_baguette()),('propNetherlandsTulip','オランダ・チューリップと木靴',pw_tulip()),
 ('propSwissCheese','スイス・チーズ',pw_cheese()),('propSpainAbanico','スペイン・アバニコ',pw_abanico()),
 ('propChinaUchiwa','中国・団扇',pw_uchiwa()),('propKoreaJanggu','韓国・チャング',pw_janggu()),
 ('propRussiaMatryoshka','ロシア・マトリョーシカ',pw_matryoshka()),
 ('propAustriaTorte','オーストリア・ザッハトルテ',pw_sachertorte()),
 ('propUKTea','イギリス・紅茶',pw_tea())]
