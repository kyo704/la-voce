from PIL import Image
import numpy as np

im = Image.open('orig_sheep.png').convert('RGBA')
a  = np.array(im); H,W = a.shape[:2]

# ── 坂本さんが引いた黒線を、元画像の座標に直したもの ────────────
#   端 (306,490) — 底 (526,599) — 端 (746,490)
A,B,C = -0.00237595, 2.49995, -58.78
FLAT  = 490.0                      # 線の外側（左右の毛玉）はここで切る

def cut_y(x):
    return max(A*x*x + B*x + C, FLAT)

CUTY = np.array([cut_y(x) for x in range(W)])

head = a.copy(); body = a.copy()
yy = np.arange(H)[:,None]
below = yy >= CUTY[None,:]          # 曲線より下＝胴
head[:,:,3] = np.where(below, 0, head[:,:,3])
body[:,:,3] = np.where(below, body[:,:,3], 0)

Image.fromarray(head).save('sheepparts2/sheep_head.png')
Image.fromarray(body).save('sheepparts2/sheep_body.png')

def bbox(p):
    m = np.array(Image.open(p))[:,:,3] > 10
    ys,xs = np.nonzero(m)
    return (xs.min(),xs.max(),ys.min(),ys.max())
print('head x%d-%d y%d-%d' % bbox('sheepparts2/sheep_head.png'))
print('body x%d-%d y%d-%d' % bbox('sheepparts2/sheep_body.png'))
for x in (224,306,400,511,600,746,799):
    print('  x=%3d → 境目 y=%d' % (x, round(cut_y(x))))
