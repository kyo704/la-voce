from PIL import Image, ImageDraw
import numpy as np, math
from acc import bake_ears, new, W, H, sh, li, body, head

def P(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return bake_ears(l)

# ══ 時代の帽子 15 ══════════════════════════════════════
def h_jomon():
    def f(d):
        d.arc([286,116,736,392],188,352, fill=(150,120,86,255), width=26)
        for i,x in enumerate(range(320,706,48)):
            y=int(160+118*((x-511)/224.0)**2)
            c=(206,186,140) if i%2 else (92,132,120)
            d.ellipse([x-21,y-21,x+21,y+21], fill=(*c,255))
        d.polygon([(511,64),(486,140),(536,140)], fill=(206,186,140,255))
    return P(f)
def h_yayoi():
    def f(d):
        d.arc([282,120,740,388],186,354, fill=(214,200,172,255), width=44)
        d.polygon([(690,186),(788,158),(816,214),(778,262),(706,240)], fill=(196,180,150,255))
        d.polygon([(690,186),(742,172),(756,250),(706,240)], fill=(212,198,170,255))
    return P(f)
def h_kofun():
    def f(d):
        d.rounded_rectangle([336,86,686,252],120, fill=(196,150,110,255))
        d.rounded_rectangle([336,86,686,176],110, fill=(216,176,138,255))
        d.rounded_rectangle([300,226,722,286],28, fill=(168,124,88,255))
    return P(f)
def h_asuka():
    def f(d):
        d.polygon([(374,232),(648,232),(618,54),(404,54)], fill=(44,40,50,255))
        d.polygon([(374,232),(511,232),(511,54),(404,54)], fill=(66,60,74,255))
        d.rounded_rectangle([330,222,692,278],22, fill=(30,28,36,255))
        for k in range(3):   # 纓（うしろに垂れる布）
            d.polygon([(616,88+k*10),(742,70+k*26),(782,150+k*18),(760,196+k*10),(640,140+k*8)],
                      fill=(*( (30,28,36) if k%2==0 else (52,48,60)),255))
    return P(f)
def h_nara():
    def f(d):
        d.rounded_rectangle([322,84,700,258],110, fill=(52,48,58,255))
        d.rounded_rectangle([322,84,700,170],100, fill=(76,70,82,255))
        d.rounded_rectangle([300,240,722,292],24, fill=(38,34,44,255))
        for s in (-1,1):
            d.polygon([(511+s*160,246),(511+s*250,300),(511+s*214,330),(511+s*140,278)], fill=(38,34,44,255))
    return P(f)
def h_heian_eboshi():
    def f(d):
        d.polygon([(430,254),(600,254),(576,-14),(470,-14)], fill=(34,32,40,255))
        d.polygon([(430,254),(511,254),(511,-14),(470,-14)], fill=(56,52,64,255))
        d.rounded_rectangle([398,238,632,290],20, fill=(24,22,30,255))
    return P(f)
def h_ichimegasa():
    def f(d):
        d.polygon([(112,300),(910,300),(511,64)], fill=(214,196,152,255))
        d.polygon([(112,300),(511,300),(511,64)], fill=(230,214,176,255))
        d.ellipse([112,270,910,342], fill=(198,180,138,255))
        d.rounded_rectangle([444,54,578,120],28, fill=(178,160,120,255))
        for k in range(-5,6):
            d.line([(511,80),(511+k*74,296)], fill=(190,172,132,255), width=4)
    return P(f)
def h_samurai_eboshi():
    def f(d):
        d.polygon([(392,262),(636,262),(672,110),(556,164),(486,54),(414,120)], fill=(38,36,44,255))
        d.polygon([(392,262),(511,262),(486,54),(414,120)], fill=(64,60,72,255))
        d.rounded_rectangle([366,248,660,302],22, fill=(28,26,34,255))
        d.line([(366,276),(660,276)], fill=(196,180,140,255), width=7)
    return P(f)
def h_nanban():
    def f(d):
        d.ellipse([146,204,876,340], fill=(52,48,60,255))
        d.ellipse([146,204,876,306], fill=(74,68,84,255))
        d.rounded_rectangle([344,68,678,262],90, fill=(52,48,60,255))
        d.rectangle([344,206,678,258], fill=(186,52,66,255))
        for k in range(3):   # 羽根
            d.polygon([(648,168-k*8),(760,66-k*30),(848,54-k*26),(806,116-k*18),(686,206-k*6)],
                      fill=(*((240,234,220) if k%2==0 else (218,210,194)),255))
    return P(f)
def h_sugegasa():
    def f(d):
        d.polygon([(150,296),(872,296),(511,90)], fill=(222,204,158,255))
        d.ellipse([150,266,872,330], fill=(204,186,142,255))
        for k in range(-6,7):
            d.line([(511,104),(511+k*62,292)], fill=(206,188,144,255), width=4)
        d.line([(300,300),(722,300)], fill=(160,60,68,255), width=12)
    return P(f)
def h_bowler():
    def f(d):
        d.ellipse([210,208,812,316], fill=(58,48,44,255))
        d.ellipse([210,208,812,286], fill=(80,66,60,255))
        d.rounded_rectangle([348,66,674,268],120, fill=(58,48,44,255))
        d.rectangle([348,206,674,262], fill=(36,30,28,255))
    return P(f)
def h_hunting():
    def f(d):
        d.chord([182,214,842,364],0,180, fill=(104,94,78,255))       # つば
        d.ellipse([258,96,764,300], fill=(150,138,114,255))            # ひらたい山
        d.ellipse([258,96,764,238], fill=(172,160,134,255))
        for x in range(288,740,52):
            d.line([(x,110),(x+44,290)], fill=(136,124,102,255), width=9)
        d.ellipse([470,88,552,140], fill=(136,124,102,255))
    return P(f)
def h_gakubo():
    def f(d):
        d.chord([214,208,808,340],0,180, fill=(24,26,36,255))
        d.rounded_rectangle([296,72,726,266],120, fill=(36,40,54,255))
        d.rectangle([296,206,726,262], fill=(24,26,36,255))
        d.ellipse([475,214,547,286], fill=(206,178,90,255))
    return P(f)
def h_cap():
    def f(d):
        d.chord([198,222,824,384],0,180, fill=(132,38,50,255))        # つば
        d.rounded_rectangle([296,66,726,272],140, fill=(178,56,68,255))
        d.rounded_rectangle([296,66,726,176],130, fill=(198,76,88,255))
        d.line([(511,72),(511,266)], fill=(158,46,58,255), width=6)
        d.ellipse([489,52,533,96], fill=(158,46,58,255))
        d.ellipse([466,180,556,250], fill=(244,238,226,255))
    return P(f)
def h_bucket():
    def f(d):
        d.ellipse([176,190,846,330], fill=(148,150,138,255))
        d.ellipse([176,190,846,296], fill=(166,168,156,255))
        d.rounded_rectangle([300,72,722,250],90, fill=(158,160,148,255))
        d.line([(300,196),(722,196)], fill=(138,140,128,255), width=8)
    return P(f)

ERA_HATS=[('hatJomonBeads','縄文・骨と貝の髪飾り',h_jomon()),
 ('hatYayoiHachimaki','弥生・布の髪飾り',h_yayoi()),
 ('hatKofunBoushi','古墳・埴輪の帽子',h_kofun()),
 ('hatAsukaKanmuri','飛鳥・冠',h_asuka()),
 ('hatNaraZukin','奈良・幞頭',h_nara()),
 ('hatHeianEboshi','平安・立烏帽子',h_heian_eboshi()),
 ('hatIchimegasa','鎌倉・市女笠',h_ichimegasa()),
 ('hatSamuraiEboshi','室町・侍烏帽子',h_samurai_eboshi()),
 ('hatNanban','安土桃山・南蛮帽子',h_nanban()),
 ('hatSugegasa','江戸・菅笠',h_sugegasa()),
 ('hatBowler','明治・山高帽',h_bowler()),
 ('hatHunting','大正・鳥打帽',h_hunting()),
 ('hatGakubo','昭和・学帽',h_gakubo()),
 ('hatCap','平成・キャップ',h_cap()),
 ('hatBucket','令和・バケットハット',h_bucket())]

if __name__=='__main__':
    S=300; cols=8; lst=ERA_HATS; rows=(len(lst)+cols-1)//cols
    sheet=Image.new('RGBA',(S*cols+24*(cols+1),(S+24)*rows+24),(247,242,230,255))
    for i,(k,n,g) in enumerate(lst):
        p=new(); p.alpha_composite(body); p.alpha_composite(head); p.alpha_composite(g)
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(24+(S+24)*(i%cols),24+(S+24)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-時代の帽子15点.png')
    print('ok')
