from era import *
LINEN=(214,200,172); LINEN2=(196,180,150); FUR=(160,132,100)
CONF=[
# ── 縄文 ─────────────────────────────
('jomonKantoui','縄文・貫頭衣（編布）', dict(col=LINEN, hem_y=852, pattern=P_weave(LINEN2),
   sleeve='none', collar='v', collar_col=sh(LINEN,0.16), belt='sash', belt_col=(150,120,86), necklace=True)),
('jomonFur','縄文・毛皮の重ね', dict(col=FUR, hem_y=838, pattern=P_dots(sh(FUR,0.12),58,16),
   sleeve='short', collar='none', belt='sash', belt_col=(112,88,62), necklace=True)),
# ── 弥生 ─────────────────────────────
('yayoiKantoui','弥生・貫頭衣（女）', dict(col=(226,216,192), hem_y=862, pattern=P_weave((208,196,168)),
   sleeve='none', collar='v', collar_col=(196,182,152), belt='sash', belt_col=(168,84,72))),
('yayoiKesa','弥生・袈裟衣（男）', dict(col=(206,194,166), hem_y=828, sleeve='none', collar='none',
   belt='sash', belt_col=(126,104,78), kesa=(168,138,98))),
# ── 古墳 ─────────────────────────────
('kofunKinuHakama','古墳・衣褌（男）', dict(col=(196,86,72), hem_y=740, sleeve='tube',
   collar='v', collar_col=(238,226,198), belt='sash', belt_col=(70,64,58),
   hakama=(76,96,132), hakama_hem=900)),
('kofunKinuMo','古墳・衣裳（女）', dict(col=(232,206,120), hem_y=736, sleeve='tube',
   collar='v', collar_col=(244,236,212), belt='sash', belt_col=(150,60,64),
   hakama=(184,86,96), hakama_hem=906)),
# ── 飛鳥 ─────────────────────────────
('asukaChofuku','飛鳥・朝服（男）', dict(col=(86,72,140), hem_y=868, sleeve='wide',
   collar='stand', collar_col=(226,214,180), belt='belt', belt_col=(58,52,48))),
('asukaHire','飛鳥・領巾の女', dict(col=(226,150,120), hem_y=862, sleeve='wide',
   collar='v', collar_col=(246,238,216), belt='sash', belt_col=(120,140,110), plate=(238,224,236))),
# ── 奈良 ─────────────────────────────
('naraHoueki','奈良・闕腋袍（男）', dict(col=(122,60,60), hem_y=876, pattern=P_karakusa((156,96,86)),
   sleeve='wide', collar='stand', collar_col=(230,216,180), belt='belt', belt_col=(60,54,48))),
('naraKarniginu','奈良・背子と裙（女）', dict(col=(232,178,96), hem_y=740, pattern=P_tenpyo((196,132,60),(240,222,180)),
   sleeve='wide', collar='v', collar_col=(248,240,220), belt='sash', belt_col=(150,72,84),
   hakama=(186,72,86), hakama_hem=908, plate=(244,232,240))),
]

CONF += [
# ── 平安 ─────────────────────────────
('heianJunihitoe','平安・十二単（女）', dict(col=(178,32,52), hem_y=904, sleeve='wide',
   sleeve_cx=286, expand=110, collar='v', collar_col=(250,246,238), belt=None,
   kasane=[(236,232,214),(240,190,150),(232,150,168),(178,44,66)])),
('heianNoushi','平安・直衣（男）', dict(col=(238,236,228), hem_y=872, pattern=P_karakusa((214,210,196)),
   sleeve='wide', collar='stand', collar_col=(206,204,192), belt='sash', belt_col=(180,176,164))),
# ── 鎌倉 ─────────────────────────────
('kamakuraHitatare','鎌倉・直垂（男）', dict(col=(46,72,116), hem_y=736, pattern=P_dots((226,222,206),96,15),
   sleeve='wide', collar='v', collar_col=(230,226,210), belt='sash', belt_col=(212,206,188),
   hakama=(46,72,116), hakama_hem=902)),
('kamakuraTsubo','鎌倉・壺装束（女）', dict(col=(238,232,214), hem_y=858, pattern=P_sakura((216,206,182)),
   sleeve='tube', collar='kimono', collar_col=(250,246,236), belt='sash', belt_col=(178,60,72))),
# ── 室町 ─────────────────────────────
('muromachiSuou','室町・素襖（男）', dict(col=(96,116,88), hem_y=740, pattern=P_check((116,138,106),64),
   sleeve='wide', collar='v', collar_col=(232,228,212), belt='sash', belt_col=(214,208,190),
   hakama=(96,116,88), hakama_hem=900)),
('muromachiKosode','室町・小袖（女）', dict(col=(206,96,84), hem_y=864, pattern=P_karakusa((234,196,126)),
   sleeve='tube', collar='kimono', belt='obi', belt_col=(76,92,120))),
# ── 安土桃山 ─────────────────────────
('momoyamaDoufuku','安土桃山・胴服（男・南蛮）', dict(col=(64,54,86), hem_y=800, pattern=P_dots((214,178,92),84,16),
   sleeve='puff', collar='none', belt='belt', belt_col=(196,160,80), ruff=(248,246,238))),
('momoyamaUchikake','安土桃山・打掛（女・辻が花）', dict(col=(214,214,222), hem_y=884, pattern=P_sakura((176,88,116)),
   sleeve='furisode', collar='kimono', belt='obi', belt_col=(150,44,72), over=(120,52,96))),
# ── 江戸 ─────────────────────────────
('edoShima','江戸・縞の小袖と羽織（男）', dict(col=(80,88,104), hem_y=866, pattern=P_shima((104,112,128),(60,66,80),20),
   sleeve='tube', collar='kimono', collar_col=(238,234,222), belt='sash', belt_col=(58,52,48),
   over=(48,54,66))),
('edoFurisode','江戸・振袖と幅広の帯（女）', dict(col=(198,60,84), hem_y=884, pattern=P_sakura((246,214,226)),
   sleeve='furisode', collar='kimono', belt='obi-wide', belt_col=(226,194,110))),
# ── 明治 ─────────────────────────────
('meijiShosei','明治・書生（男）', dict(col=(72,76,88), hem_y=736, pattern=P_stripe((88,92,104),26),
   sleeve='tube', collar='kimono', collar_col=(228,224,212), belt='sash', belt_col=(52,56,66),
   hakama=(56,60,72), hakama_hem=902, over=(40,44,54))),
('meijiRokumeikan','明治・鹿鳴館のドレス（女）', dict(col=(126,68,110), hem_y=892, pattern=P_dots((166,110,150),70,11),
   sleeve='puff', collar='round', collar_col=(248,244,236), belt='belt', belt_col=(90,44,78),
   kasane=[(226,206,222),(196,164,196)])),
# ── 大正 ─────────────────────────────
('taishoModanBoy','大正・モダンボーイ（男）', dict(col=(94,86,74), hem_y=812, pattern=P_check((108,100,86),56),
   sleeve='tube', collar='v', collar_col=(246,244,238), belt=None, buttons=2, tie=(140,44,52))),
('taishoJogakusei','大正・女学生（女）', dict(col=(206,196,180), hem_y=712, pattern=P_yagasuri((252,248,238)),
   sleeve='tube', collar='kimono', belt='sash', belt_col=(150,44,72),
   hakama=(122,52,74), hakama_hem=900)),
# ── 昭和 ─────────────────────────────
('showaGakuran','昭和・学生服（男）', dict(col=(36,40,54), hem_y=812, sleeve='tube',
   collar='stand', collar_col=(24,26,36), belt=None, buttons=3)),
('showaOnepiece','昭和・ワンピース（女）', dict(col=(206,86,90), hem_y=876, pattern=P_dots((250,246,238),64,12),
   sleeve='puff', collar='round', collar_col=(250,248,242), belt='belt', belt_col=(150,58,62))),
# ── 平成 ─────────────────────────────
('heiseiShibukaji','平成・渋カジ（男）', dict(col=(84,116,158), hem_y=792, pattern=P_stripe((94,126,168),8),
   sleeve='tube', collar='v', collar_col=(240,238,232), belt=None, buttons=3)),
('heiseiSeifuku','平成・制服（女）', dict(col=(48,60,92), hem_y=724, sleeve='tube',
   collar='round', collar_col=(244,242,238), belt=None, tie=(178,58,74),
   hakama=(122,60,72), hakama_hem=846)),
# ── 令和 ─────────────────────────────
('reiwaOversize','令和・オーバーサイズ（男）', dict(col=(148,150,142), hem_y=824, sleeve='wide',
   collar='stand', collar_col=(132,134,126), belt=None, drop=190)),
('reiwaEarth','令和・アースカラー（女）', dict(col=(190,164,132), hem_y=890, sleeve='puff',
   collar='round', collar_col=(210,188,158), belt='sash', belt_col=(156,132,102))),
]
