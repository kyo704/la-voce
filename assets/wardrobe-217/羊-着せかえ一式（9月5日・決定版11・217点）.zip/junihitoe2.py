from PIL import Image, ImageDraw
import numpy as np, math
from era import sh, li, new, W, H, body, head, jaw, CX

def top_y(x): return max(jaw(x)-14, 592-150*((x-CX)/300.0)**2)

# 坂本さんが引いた三角を、元画像の座標に直したもの
APEX_Y, HEM_Y = 379.0, 952.0
def cone_half(y):
    if y<=APEX_Y: return 0.0
    t=min(1.0,(y-APEX_Y)/(HEM_Y-APEX_Y))
    hw = 73 + 393*(t**0.68)
    if y > HEM_Y-34:                    # 裾の角をまるく
        k=(y-(HEM_Y-34))/34.0
        hw *= (1-0.16*k*k)
    return hw

# 襲の色目（紅の匂）：外＝淡い、内＝濃い
KASANE=[(252,224,228),(246,186,198),(236,148,166),(216,104,128),(186,56,80)]
UWAGI =(116,18,40)          # 表着
KARA  =(44,92,84)           # 唐衣
KARA2 =(214,180,104)        # 唐衣の文様（金）
HAKAMA=(198,34,48)          # 長袴（緋）
SHIRO =(250,246,238)        # 単・衿
MO    =(246,244,238)        # 裳

def _fill_cone(a, shrink, ytop, ybot, col, pattern=None):
    for y in range(int(ytop), int(min(H,ybot))):
        hw=cone_half(y)-shrink
        if hw<=0: continue
        x0,x1=int(CX-hw),int(CX+hw)
        for x in range(max(0,x0),min(W,x1+1)):
            if y<top_y(x): continue
            c = pattern(x,y,col) if pattern else col
            a[y,x]=(*c,255)

def P_yusoku(c2, step=104):
    """有職文様ふう（小さな花菱）"""
    def f(x,y,b):
        gx,gy=x%step-step//2, y%step-step//2
        if abs(gx)+abs(gy)<15: return c2
        for (dx,dy) in ((0,-30),(0,30),(-30,0),(30,0)):
            if abs(gx-dx)+abs(gy-dy)<11: return c2
        return b
    return f

def junihitoe():
    a=np.zeros((H,W,4),'uint8')
    TOP=560
    # ① 五衣（外から内へ、少しずつ小さく）
    for i,c in enumerate(KASANE):
        _fill_cone(a, i*24, TOP, HEM_Y, c)          # 裾はそろえ、横だけ細くする
    # ② 表着
    _fill_cone(a, len(KASANE)*24, TOP, HEM_Y, UWAGI, P_yusoku(sh(UWAGI,0.16)))
    l=Image.fromarray(a); d=ImageDraw.Draw(l)

    # ③ 唐衣（みじかい上着・肩に）
    b=np.array(l)
    _fill_cone(b, 96, TOP, 762, KARA, P_yusoku(KARA2, 88))
    l=Image.fromarray(b); d=ImageDraw.Draw(l)
    for i,c in enumerate([(230,220,190),KARA2]):     # 唐衣のふち
        yy=762-13*(2-i); hw=cone_half(yy)-96
        d.polygon([(CX-hw,yy),(CX+hw,yy),(CX+hw+4,yy+14),(CX-hw-4,yy+14)], fill=(*c,255))

    # ④ 長袴（緋）が前のすそから出る
    d.polygon([(CX-104,846),(CX+104,846),(CX+156,HEM_Y-6),(CX-156,HEM_Y-6)], fill=(*HAKAMA,255))
    d.polygon([(CX-104,846),(CX+104,846),(CX+122,886),(CX-122,886)], fill=(*li(HAKAMA,0.14),255))
    d.line([(CX,850),(CX,HEM_Y-10)], fill=(*sh(HAKAMA,0.24),255), width=7)

    # ⑤ 裾の単（白い細い線）
    for y in range(int(HEM_Y)-12,int(HEM_Y)):
        hw=cone_half(y)
        d.line([(CX-hw,y),(CX+hw,y)], fill=(*SHIRO,255), width=1)

    # ⑥ 大腰（裳の腰・ほそい白おび）
    hw=cone_half(796)-140
    d.polygon([(CX-hw,790),(CX+hw,790),(CX+hw+3,808),(CX-hw-3,808)], fill=(236,232,220,255))

    # ⑦ 衿（襲を細く見せる・右前）
    XP,YP=CX-6,744
    for over in (False,True):
        xs = CX+136 if over else CX-136
        for i,c in enumerate([KASANE[1],KASANE[3],SHIRO]):
            w=44-i*13
            col = c if over else sh(c,0.10)
            d.line([(xs,int(top_y(xs))-6),(XP,YP)], fill=(*col,255), width=w)
    d.line([(XP,YP),(XP-46,YP+46)], fill=(*SHIRO,255), width=18)

    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x))),x]=(0,0,0,0)
    return Image.fromarray(a)

if __name__=='__main__':
    g=junihitoe()
    p=new(); p.alpha_composite(body); p.alpha_composite(g); p.alpha_composite(head)
    c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
    c.convert('RGB').resize((700,700),Image.LANCZOS).save('/home/claude/out/羊-十二単v2.png')
    print('ok')
