from PIL import Image, ImageDraw
import numpy as np, math
A,B,C,FLAT=-0.00237595,2.49995,-58.78,490.0
def jaw(x): return max(A*x*x+B*x+C,FLAT)
CX=511
orig=Image.open('orig_sheep.png').convert('RGBA')
head=Image.open('sheepparts2/sheep_head.png').convert('RGBA')
body=Image.open('sheepparts2/sheep_body.png').convert('RGBA')
W,H=orig.size; SIL=np.array(orig)[:,:,3]
def sh(c,d): return tuple(max(0,int(v*(1-d))) for v in c)
def li(c,d): return tuple(int(v+(255-v)*d) for v in c)
def new(): return Image.new('RGBA',(W,H),(0,0,0,0))
def clip(l):
    a=np.array(l); a[:,:,3]=(a[:,:,3].astype(int)*SIL.astype(int)//255).astype('uint8')
    return Image.fromarray(a)
EY,ERX,ERY=660,268,300
def torso_hw(y):
    t=1-((y-EY)/ERY)**2
    return ERX*math.sqrt(t) if t>0 else 0.0
def shoulder(x): return 592-150*((x-CX)/300.0)**2
def top_y(x):    return max(jaw(x)-14, shoulder(x))

# ── 和の柄 ──────────────────────────────────────────
def p_sakura(c2):
    def f(x,y,base):
        gx,gy=x%92-46, y%92-46
        d=math.hypot(gx,gy)
        if d<9: return c2
        for k in range(5):
            a=k*2*math.pi/5-math.pi/2
            if math.hypot(gx-19*math.cos(a), gy-19*math.sin(a))<11: return c2
        return base
    return f
def p_yagasuri(c2):
    def f(x,y,base):
        p=64; u=x%p
        v=(y+ (0 if (x//p)%2==0 else p//2)) % p
        t=abs(u-p/2)
        return c2 if (v < p/2 - t*0.9) else base
    return f
def p_seigaiha(c2,c3):
    def f(x,y,base):
        p=96
        i=round(x/p); j=round(y/(p*0.5))
        best=1e9
        for jj in (j-1,j,j+1):
            off = 0 if jj%2==0 else p/2
            for ii in (i-1,i,i+1):
                d=math.hypot(x-(ii*p+off), y-jj*p*0.5)
                best=min(best,d)
        r=int(best/13)
        return base if r%3==0 else (c2 if r%3==1 else c3)
    return f
def p_none(x,y,base): return base

# ── 着物 ────────────────────────────────────────────
def kimono(col, obi, pattern=p_none, furisode=True, haori=None, hem_y=872):
    l=new(); a=np.array(l)
    def hemc(x):
        u=(x-CX)/264.0
        return hem_y + 18*max(0.0,1-u*u)
    for y in range(470,H):
        hw=torso_hw(y)
        if hw<=0: continue
        for x in range(int(CX-hw),int(CX+hw)+1):
            t=top_y(x); b=hemc(x)
            if y<t or y>b: continue
            base=pattern(x,y,col)
            c = li(base,0.13) if y<t+70 else (sh(base,0.16) if y>b-30 else base)
            a[y,x]=(*c,255)
    l=Image.fromarray(a); d=ImageDraw.Draw(l)

    # ── 衿：正面から見て「y」＝右前（見る人の右の身頃が上）──
    WHITE=(250,246,236); EDGE=sh(col,0.30)
    XP,YP = CX-8, 706                      # 交点（帯のすぐ上）
    def collar(x_top, over):
        y_top=int(top_y(x_top))-8
        w=46
        d.line([(x_top,y_top),(XP,YP)], fill=(*EDGE,255), width=w+12)
        d.line([(x_top,y_top),(XP,YP)], fill=(*(WHITE if over else sh(WHITE,0.13)),255), width=w)
    collar(CX-152, False)                  # 下前（見る人の左）
    collar(CX+152, True)                   # 上前（見る人の右）＝こちらが上
    d.line([(XP,YP),(XP-62,YP+58)], fill=(*EDGE,255), width=58)
    d.line([(XP,YP),(XP-62,YP+58)], fill=(*WHITE,255), width=46)   # y のしっぽ

    # ── 帯 ──────────────────────────────────────
    OT,OB=744,832
    d.rectangle([CX-266,OT,CX+266,OB], fill=(*obi,255))
    d.rectangle([CX-266,OT,CX+266,OT+20], fill=(*li(obi,0.30),255))
    d.rectangle([CX-266,OB-14,CX+266,OB], fill=(*sh(obi,0.28),255))
    d.line([(CX-266,OT+52),(CX+266,OT+52)], fill=(*sh(obi,0.30),255), width=6)   # 帯締め
    d.rounded_rectangle([CX-52,OT+30,CX+52,OT+74],18, fill=(*li(obi,0.48),255))  # 飾り

    # ── 袖（振袖はながい） ──────────────────────
    for s in (-1,1):
        cx=CX+s*236
        bot = 892 if furisode else 796
        d.rounded_rectangle([cx-66,int(shoulder(cx))+12,cx+66,bot],48, fill=(*sh(col,0.10),255))
        # 袖にも柄
        aa=np.array(l)
        for y in range(int(shoulder(cx))+10,bot):
            for x in range(cx-66,cx+67):
                if 0<=x<W and aa[y,x,3]>0:
                    aa[y,x]=(*pattern(x,y,sh(col,0.10)),255)
        l=Image.fromarray(aa); d=ImageDraw.Draw(l)

    if haori:
        aa=np.array(l)
        for y in range(470,812):
            hw=torso_hw(y)
            if hw<=0: continue
            for x in list(range(int(CX-hw),CX-138))+list(range(CX+138,int(CX+hw)+1)):
                if 0<=x<W and y>=top_y(x) and aa[y,x,3]>0:
                    aa[y,x]=(*(li(haori,0.10) if y<top_y(x)+70 else haori),255)
        l=Image.fromarray(aa); d=ImageDraw.Draw(l)
        for s2 in (-1,1):
            cx=CX+s2*236
            d.rounded_rectangle([cx-70,int(shoulder(cx))+12,cx+70,806],50, fill=(*sh(haori,0.10),255))
        # 羽織紐
        d.line([(CX-128,676),(CX+128,676)], fill=(*li(haori,0.55),255), width=9)
        d.ellipse([CX-22,654,CX+22,698], fill=(*li(haori,0.62),255))

    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x))),x]=(0,0,0,0)
    for y in range(H):
        hw=torso_hw(y)
        lo,hi=int(CX-hw)-96,int(CX+hw)+96          # 袖のぶん少し外まで許す
        a[y,:max(0,lo)]=(0,0,0,0); a[y,min(W,hi)+1:]=(0,0,0,0)
    for x in range(W):
        b=int(hemc(x))
        if abs(x-CX)<250: a[b:,x]=(0,0,0,0)
    return clip(Image.fromarray(a))

def stack(g):
    p=new(); p.alpha_composite(body); p.alpha_composite(g); p.alpha_composite(head); return p

RED=(168,32,48); YEL=(212,164,40); BLU=(46,86,140); NAVY=(62,74,106); GRAY=(132,138,152)
items=[
 ('女・赤（桜）',   kimono(RED, (232,214,168), p_sakura((248,224,232)))),
 ('女・黄（矢絣）', kimono(YEL, (120,40,60),   p_yagasuri((250,246,230)))),
 ('女・青（青海波）',kimono(BLU, (226,196,120), p_seigaiha((116,164,206),(206,230,244)))),
 ('男・紺（羽織）', kimono(NAVY,(60,64,86), p_none, furisode=False, haori=GRAY, hem_y=880)),
]
S=400
sheet=Image.new('RGBA',(S*4+40*5,S+80),(247,242,230,255))
for i,(n,g) in enumerate(items):
    c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(stack(g))
    sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(40+(S+40)*i,40))
sheet.convert('RGB').save('/home/claude/out/羊-和服4点.png')
print('ok')
