from PIL import Image, ImageDraw
import numpy as np, math
from era import make, sh, li, new, W, H, body, head, jaw, CX, torso_hw, clipsil
from acc import bake_ears

def top_y(x): return max(jaw(x)-14, 592-150*((x-CX)/300.0)**2)
def PH(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return bake_ears(l)
def PP(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return l

def P_odoshi(lace, w=52, h=46):
    """威（おどし）：横の板と、縦の糸"""
    def f(x,y,b):
        if y % h < 8: return sh(b,0.38)
        if x % w < 9 and (y % h) > 12:  return lace
        return b
    return f

# ══ 甲冑 3点 ═══════════════════════════════════════════
def oyoroi():
    """大鎧（源平のころ）"""
    g = make(col=(58,74,116), hem_y=744, pattern=P_odoshi((214,52,64)),
             sleeve='none', collar='stand', collar_col=(46,58,92),
             belt='sash', belt_col=(180,44,56), expand=90)
    d=ImageDraw.Draw(g)
    # 大袖（肩の大きな板）
    for s in (-1,1):
        x0=CX+s*196; x1=CX+s*346
        d.rounded_rectangle([min(x0,x1),596,max(x0,x1),844],16, fill=(58,74,116,255))
        for k in range(5):
            d.line([(min(x0,x1),608+k*48),(max(x0,x1),608+k*48)], fill=(30,40,70,255), width=9)
        for k in range(3):
            xx=min(x0,x1)+34+k*44
            d.line([(xx,600),(xx,840)], fill=(214,52,64,255), width=8)
    # 草摺（腰から下がる板）
    for i in range(4):
        x0=CX-236+i*118
        d.rounded_rectangle([x0,760,x0+108,930],12, fill=(58,74,116,255))
        for k in range(4):
            d.line([(x0,776+k*40),(x0+108,776+k*40)], fill=(38,50,82,255), width=6)
        for k in range(3):
            d.line([(x0+22+k*32,764),(x0+22+k*32,926)], fill=(214,52,64,255), width=6)
    # 胸の金具
    d.ellipse([CX-40,640,CX+40,720], fill=(206,168,86,255))
    d.ellipse([CX-22,658,CX+22,702], fill=(150,112,48,255))
    return clipsil(g, 90)

def gusoku():
    """当世具足（戦国のころ）"""
    g = make(col=(46,44,52), hem_y=752, sleeve='tube', sleeve_col=(62,60,70),
             collar='stand', collar_col=(34,32,40), belt='sash', belt_col=(160,36,48), expand=70)
    d=ImageDraw.Draw(g)
    for k in range(4):
        d.line([(CX-210,640+k*32),(CX+210,640+k*32)], fill=(28,26,34,255), width=7)
    d.polygon([(CX-186,616),(CX+186,616),(CX+150,700),(CX-150,700)], fill=(70,68,80,255))
    for i in range(5):
        x0=CX-250+i*100
        d.rounded_rectangle([x0,764,x0+90,912],10, fill=(46,44,52,255))
        for k in range(3):
            d.line([(x0,782+k*42),(x0+90,782+k*42)], fill=(28,26,34,255), width=6)
    # 袖（小さめの板）
    for s in (-1,1):
        x0=CX+s*208; x1=CX+s*312
        d.rounded_rectangle([min(x0,x1),606,max(x0,x1),800],14, fill=(46,44,52,255))
        for k in range(4):
            d.line([(min(x0,x1),624+k*44),(max(x0,x1),624+k*44)], fill=(28,26,34,255), width=6)
    d.ellipse([CX-36,644,CX+36,716], fill=(198,162,84,255))
    return clipsil(g, 70)

def jinbaori():
    """陣羽織（鎧の上に着る）"""
    g = make(col=(150,32,44), hem_y=828, sleeve='none', collar='none',
             belt='sash', belt_col=(40,38,46))
    d=ImageDraw.Draw(g)
    d.polygon([(CX-150,int(top_y(CX-150))),(CX,700),(CX+150,int(top_y(CX+150)))], fill=(46,44,52,255))
    for (x,y,r) in [(CX-150,760,44),(CX+150,760,44),(CX,860,44)]:
        d.ellipse([x-r,y-r,x+r,y+r], fill=(232,224,204,255))
        d.ellipse([x-r+13,y-r+13,x+r-13,y+r-13], fill=(150,32,44,255))
    d.line([(CX,700),(CX,844)], fill=(110,22,32,255), width=7)
    return g

ARMOR=[('wearOyoroi','大鎧（源平のころ）',oyoroi()),
       ('wearGusoku','当世具足（戦国のころ）',gusoku()),
       ('wearJinbaori','陣羽織',jinbaori())]

# ══ 兜・陣笠 ═══════════════════════════════════════════
def kabuto():
    C=(52,62,92); G=(206,168,86)
    def f(d):
        for i in range(4):                      # 錣（しころ）
            k=i*26
            d.polygon([(300-k*1.2,196+k*0.9),(722+k*1.2,196+k*0.9),
                       (778+k*1.2,300+k),(244-k*1.2,300+k)], fill=(*(C if i%2==0 else sh(C,0.14)),255))
        d.ellipse([300,58,722,300], fill=(*C,255))     # 鉢
        d.ellipse([300,58,722,222], fill=(*li(C,0.16),255))
        for k in range(-3,4):
            d.line([(511+k*54,80),(511+k*62,286)], fill=(*sh(C,0.18),255), width=6)
        d.ellipse([475,60,547,124], fill=(*G,255))     # 天辺
        # 鍬形（前立て・まん中に細く／耳を隠さない）
        d.polygon([(470,190),(438,26),(470,18),(500,176)], fill=(*G,255))
        d.polygon([(552,190),(584,26),(552,18),(522,176)], fill=(*G,255))
        d.ellipse([479,150,543,214], fill=(*G,255))
        d.ellipse([494,165,528,199], fill=(*sh(G,0.28),255))
    return PH(f)
def jingasa():
    C=(58,54,60)
    def f(d):
        d.polygon([(150,306),(872,306),(511,86)], fill=(*C,255))
        d.polygon([(150,306),(511,306),(511,86)], fill=(*li(C,0.16),255))
        d.ellipse([150,278,872,340], fill=(*sh(C,0.24),255))
        d.ellipse([456,214,566,290], fill=(206,168,86,255))
        d.ellipse([476,232,546,272], fill=(*C,255))
    return PH(f)
ARMOR_HATS=[('hatKabuto','兜（鍬形つき）',kabuto()),('hatJingasa','陣笠',jingasa())]

# ══ 持ち物 ═════════════════════════════════════════════
def p_tachi():
    def f(d):
        d.line([(378,936),(664,486)], fill=(180,186,198,255), width=40)
        d.line([(384,930),(660,494)], fill=(240,244,250,255), width=22)
        d.polygon([(646,470),(686,496),(654,510)], fill=(240,244,250,255))
        d.line([(346,986),(410,884)], fill=(88,66,48,255), width=44)   # 柄
        for k in range(4):
            d.line([(352+k*14,978-k*22),(388+k*14,952-k*22)], fill=(150,120,86,255), width=6)
        d.ellipse([378,858,462,942], fill=(206,168,86,255))            # 鍔
        d.ellipse([400,880,440,920], fill=(150,112,48,255))
    return PP(f)
def p_yumi():
    def f(d):
        d.arc([372,472,732,1020],108,252, fill=(88,62,42,255), width=34)
        for yy in (560,752,944):
            d.ellipse([392,yy-14,438,yy+14], fill=(196,166,120,255))
        d.line([(470,486),(470,1006)], fill=(226,220,204,255), width=10)
        for k,dy in enumerate((-70,0,70)):
            d.line([(508,750+dy),(700,750+dy)], fill=(178,146,102,255), width=8)
            d.polygon([(700,742+dy),(736,750+dy),(700,758+dy)], fill=(214,206,190,255))
            d.polygon([(508,742+dy),(536,736+dy),(536,764+dy),(508,758+dy)], fill=(238,232,216,255))
    return PP(f)
def p_gunbai():
    C=(46,44,52); G=(206,168,86)
    def f(d):
        d.rounded_rectangle([392,560,634,830],46, fill=(*C,255))
        d.rounded_rectangle([414,582,612,808],36, fill=(*G,255))
        d.rounded_rectangle([436,604,590,786],28, fill=(*C,255))
        d.ellipse([466,650,558,742], fill=(*G,255))
        d.rounded_rectangle([488,824,534,960],18, fill=(96,72,52,255))
        for k in range(3):
            d.line([(492,860+k*30),(530,860+k*30)], fill=(*G,255), width=6)
    return PP(f)
ARMOR_PROPS=[('propTachi','太刀',p_tachi()),('propYumiya','弓と矢',p_yumi()),('propGunbai','軍配',p_gunbai())]

if __name__=='__main__':
    from handfix import place
    S=300; cols=8
    lst=[(k,n,g,'g') for k,n,g in ARMOR]+[(k,n,g,'h') for k,n,g in ARMOR_HATS]+[(k,n,g,'p') for k,n,g in ARMOR_PROPS]
    rows=(len(lst)+cols-1)//cols
    sheet=Image.new('RGBA',(S*cols+24*(cols+1),(S+24)*rows+24),(247,242,230,255))
    for i,(k,n,g,kind) in enumerate(lst):
        p=new(); p.alpha_composite(body)
        if kind=='g': p.alpha_composite(g)
        p.alpha_composite(head)
        if kind=='h': p.alpha_composite(g)
        if kind=='p': p.alpha_composite(place(g,'R'))
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(24+(S+24)*(i%cols),24+(S+24)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-甲冑8点.png')
    print('ok')
