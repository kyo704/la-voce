from PIL import Image, ImageDraw
import numpy as np, math
from acc import new, W, H, sh, li, body, head
def P(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return l

def pr_jomon():
    def f(d):
        C=(168,116,84)
        d.polygon([(392,720),(630,720),(654,928),(368,928)], fill=(*C,255))
        d.polygon([(392,720),(511,720),(511,928),(368,928)], fill=(*li(C,0.14),255))
        d.ellipse([368,690,654,752], fill=(*sh(C,0.2),255))
        for k in range(5):
            x=386+k*62
            d.polygon([(x,706),(x+22,644),(x+44,706)], fill=(*sh(C,0.12),255))
        for y in (790,846):
            d.line([(372,y),(650,y)], fill=(*sh(C,0.22),255), width=8)
    return P(f)
def pr_yayoi():
    def f(d):
        for i,x in enumerate((430,511,592)):
            d.line([(x,940),(x+(i-1)*30,672)], fill=(150,166,104,255), width=11)
            for k in range(7):
                yy=690+k*30; xx=x+(i-1)*30+int((k)*(i-1)*3)
                d.ellipse([xx-16,yy-11,xx+16,yy+11], fill=(224,196,104,255))
        d.line([(400,900),(622,900)], fill=(178,150,96,255), width=13)
    return P(f)
def pr_kofun():
    def f(d):
        d.ellipse([340,690,600,950], fill=(146,158,140,255))
        d.ellipse([368,718,572,922], fill=(178,190,170,255))
        for k in range(8):
            a=k*math.pi/4
            d.ellipse([470+72*math.cos(a)-16,820+72*math.sin(a)-16,470+72*math.cos(a)+16,820+72*math.sin(a)+16], fill=(146,158,140,255))
        d.arc([578,714,714,850],20,290, fill=(88,132,120,255), width=42)
        d.ellipse([660,706,716,762], fill=(88,132,120,255))
    return P(f)
def pr_asuka():
    def f(d):
        d.polygon([(474,616),(556,616),(548,946),(482,946)], fill=(212,196,164,255))
        d.polygon([(474,616),(511,616),(511,946),(482,946)], fill=(230,216,188,255))
        d.rounded_rectangle([466,606,564,634],12, fill=(192,176,142,255))
    return P(f)
def pr_nara():
    def f(d):
        C=(158,106,68)
        d.ellipse([368,700,654,952], fill=(*C,255))
        d.ellipse([396,728,626,924], fill=(*li(C,0.16),255))
        d.polygon([(492,714),(530,714),(556,548),(506,536)], fill=(*sh(C,0.18),255))
        d.rounded_rectangle([496,520,570,566],16, fill=(*sh(C,0.3),255))
        for k in range(4):
            d.line([(500+k*8,714),(526+k*8,556)], fill=(238,230,210,255), width=4)
        d.ellipse([472,798,550,876], fill=(*sh(C,0.24),255))
    return P(f)
def pr_ougi():
    def f(d):
        d.pieslice([236,516,786,1066],200,340, fill=(206,60,80,255))
        d.pieslice([300,580,722,1002],200,340, fill=(240,226,196,255))
        for k in range(9):
            a=math.radians(200+k*17.5)
            d.line([(511+40*math.cos(a),790+40*math.sin(a)),(511+274*math.cos(a),790+274*math.sin(a))],
                   fill=(180,150,96,255), width=6)
        d.ellipse([490,770,532,812], fill=(180,150,96,255))
    return P(f)
def pr_makimono():
    def f(d):
        d.rounded_rectangle([340,760,682,884],14, fill=(246,240,224,255))
        d.rounded_rectangle([320,742,376,902],26, fill=(150,110,74,255))
        d.rounded_rectangle([646,742,702,902],26, fill=(150,110,74,255))
        for k in range(5):
            d.line([(400+k*4,790),(620-k*4,790+k*18)], fill=(120,112,100,255), width=5)
    return P(f)
def pr_nohmen():
    def f(d):
        d.ellipse([386,652,636,948], fill=(240,230,208,255))
        d.ellipse([406,672,616,928], fill=(250,244,228,255))
        d.ellipse([448,762,486,790], fill=(60,52,44,255))
        d.ellipse([536,762,574,790], fill=(60,52,44,255))
        d.arc([466,824,556,876],0,180, fill=(150,60,64,255), width=9)
        d.arc([432,712,506,748],200,340, fill=(60,52,44,255), width=7)
        d.arc([516,712,590,748],200,340, fill=(60,52,44,255), width=7)
    return P(f)
def pr_chawan():
    def f(d):
        C=(96,86,78)
        d.polygon([(392,780),(630,780),(600,930),(422,930)], fill=(*C,255))
        d.ellipse([392,752,630,812], fill=(*li(C,0.22),255))
        d.ellipse([412,766,610,798], fill=(158,178,140,255))
        d.rounded_rectangle([648,660,690,868],18, fill=(214,196,150,255))
        for k in range(5):
            d.line([(654+k*8,668),(650+k*9,600)], fill=(228,214,176,255), width=5)
    return P(f)
def pr_chochin():
    def f(d):
        C=(238,222,190)
        d.ellipse([374,610,648,952], fill=(*C,255))
        for y in range(640,930,34):
            d.line([(378,y),(644,y)], fill=(*sh(C,0.12),255), width=5)
        d.rounded_rectangle([444,596,578,636],14, fill=(64,58,52,255))
        d.rounded_rectangle([444,926,578,962],14, fill=(64,58,52,255))
        d.ellipse([456,724,566,844], fill=(190,44,52,255))
    return P(f)
def pr_stick():
    def f(d):
        d.line([(566,940),(566,640)], fill=(92,68,52,255), width=22)
        d.arc([492,600,586,700],90,270, fill=(92,68,52,255), width=22)
        d.rounded_rectangle([552,706,582,742],8, fill=(206,176,110,255))
    return P(f)
def pr_gramophone():
    def f(d):
        d.rounded_rectangle([386,830,646,948],18, fill=(126,88,58,255))
        d.rounded_rectangle([386,830,511,948],14, fill=(150,110,74,255))
        d.polygon([(540,832),(600,700),(760,556),(806,660),(650,776),(604,838)], fill=(196,158,74,255))
        d.ellipse([700,530,830,690], fill=(216,180,96,255))
        d.ellipse([724,558,806,662], fill=(160,124,58,255))
        d.line([(540,834),(596,724)], fill=(90,74,54,255), width=12)
    return P(f)
def pr_camera():
    def f(d):
        d.rounded_rectangle([368,720,654,930],28, fill=(58,54,58,255))
        d.rounded_rectangle([368,720,654,800],24, fill=(78,74,78,255))
        d.ellipse([440,772,582,914], fill=(38,36,40,255))
        d.ellipse([464,796,558,890], fill=(96,110,128,255))
        d.ellipse([488,820,534,866], fill=(200,214,232,255))
        d.rounded_rectangle([586,690,634,724],8, fill=(180,60,64,255))
    return P(f)
def pr_keitai():
    def f(d):
        C=(226,222,230)
        d.rounded_rectangle([440,700,590,948],26, fill=(*C,255))
        d.rounded_rectangle([440,700,590,820],22, fill=(*sh(C,0.10),255))
        d.rounded_rectangle([458,716,572,806],10, fill=(150,190,180,255))
        for r in range(4):
            for c in range(3):
                d.ellipse([466+c*38,842+r*24,494+c*38,860+r*24], fill=(*sh(C,0.16),255))
        d.line([(578,700),(590,632)], fill=(*sh(C,0.3),255), width=10)
    return P(f)
def pr_smartphone():
    def f(d):
        d.rounded_rectangle([430,676,600,952],30, fill=(46,46,52,255))
        d.rounded_rectangle([444,694,586,934],22, fill=(180,206,220,255))
        d.rounded_rectangle([444,694,586,760],18, fill=(150,180,200,255))
        for r in range(3):
            for c in range(3):
                d.rounded_rectangle([460+c*44,786+r*46,494+c*44,820+r*46],9, fill=(240,244,246,255))
    return P(f)

ERA_PROPS=[('propJomonPot','縄文・土器',pr_jomon()),('propYayoiRice','弥生・稲穂',pr_yayoi()),
 ('propKofunMagatama','古墳・鏡と勾玉',pr_kofun()),('propAsukaShaku','飛鳥・笏',pr_asuka()),
 ('propNaraBiwa','奈良・琵琶',pr_nara()),('propHeianOugi','平安・檜扇',pr_ougi()),
 ('propKamakuraMakimono','鎌倉・巻物',pr_makimono()),('propMuromachiNohmen','室町・能面',pr_nohmen()),
 ('propMomoyamaChawan','安土桃山・茶碗と茶筅',pr_chawan()),('propEdoChochin','江戸・提灯',pr_chochin()),
 ('propMeijiStick','明治・ステッキ',pr_stick()),('propTaishoGramophone','大正・蓄音機',pr_gramophone()),
 ('propShowaCamera','昭和・カメラ',pr_camera()),('propHeiseiKeitai','平成・ケータイ',pr_keitai()),
 ('propReiwaSmartphone','令和・スマートフォン',pr_smartphone())]

if __name__=='__main__':
    S=300; cols=8; lst=ERA_PROPS; rows=(len(lst)+cols-1)//cols
    sheet=Image.new('RGBA',(S*cols+24*(cols+1),(S+24)*rows+24),(247,242,230,255))
    for i,(k,n,g) in enumerate(lst):
        p=new(); p.alpha_composite(body); p.alpha_composite(head); p.alpha_composite(g)
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(24+(S+24)*(i%cols),24+(S+24)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-時代の持ち物15点.png')
    print('ok')
