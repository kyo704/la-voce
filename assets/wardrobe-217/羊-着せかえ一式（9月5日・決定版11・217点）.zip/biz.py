from PIL import Image, ImageDraw
import numpy as np, math
from era import make, P_none, P_stripe, P_check, sh, li, new, W, H, body, head, jaw, CX, top_y
from acc import bake_ears

def PH(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return bake_ears(l)
def PP(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return l

# ── 正装の仕上げ（白いシャツ・蝶ネクタイ・燕尾） ──
def add_formal(img, col, tails=False, vest=(250,248,244), bow=(24,22,30)):
    d=ImageDraw.Draw(img)
    j=int(jaw(CX))
    if tails:
        for s in (-1,1):
            d.polygon([(CX+s*84,738),(CX+s*214,720),(CX+s*196,928),(CX+s*128,940),(CX+s*104,800)],
                      fill=(*col,255))
            d.polygon([(CX+s*84,738),(CX+s*150,730),(CX+s*140,900),(CX+s*104,800)],
                      fill=(*sh(col,0.12),255))
    # 白いシャツ（胸）
    d.polygon([(CX-92,j+6),(CX+92,j+6),(CX+64,802),(CX-64,802)], fill=(*vest,255))
    d.polygon([(CX-92,j+6),(CX,j+108),(CX+92,j+6)], fill=(*col,255))
    # 蝶ネクタイ
    d.polygon([(CX,j+96),(CX-84,j+66),(CX-84,j+138)], fill=(*bow,255))
    d.polygon([(CX,j+96),(CX+84,j+66),(CX+84,j+138)], fill=(*bow,255))
    knot = sh(bow,0.25) if sum(bow)<400 else sh(bow,0.08)
    d.ellipse([CX-22,j+80,CX+22,j+124], fill=(*knot,255))
    return img

BLACK=(38,36,44); NAVY=(48,58,86); GRAY=(112,116,126)
SUITS=[
('suitNavy','スーツ（紺）', make(col=NAVY, hem_y=816, sleeve='tube', collar='v',
   collar_col=(246,244,240), belt=None, buttons=2, tie=(140,40,52))),
('suitLadyGray','スーツ（女性・グレー）', make(col=GRAY, hem_y=752, sleeve='tube', collar='v',
   collar_col=(248,246,242), belt=None, buttons=1,
   hakama=(96,100,110), hakama_hem=856)),
('tuxedo','タキシード', add_formal(make(col=BLACK, hem_y=826, sleeve='tube', collar='none',
   belt='sash', belt_col=(22,20,28), buttons=0), BLACK)),
('tailcoat','燕尾服', add_formal(make(col=(28,26,34), hem_y=764, sleeve='tube', collar='none',
   belt=None, buttons=0), (28,26,34), tails=True, bow=(250,248,244))),
]

def h_fedora():
    C=(78,72,64)
    def f(d):
        d.ellipse([190,200,832,326], fill=(*C,255))
        d.ellipse([190,200,832,294], fill=(*li(C,0.16),255))
        d.rounded_rectangle([334,66,688,262],96, fill=(*C,255))
        d.line([(511,74),(511,236)], fill=(*sh(C,0.20),255), width=28)
        d.rectangle([334,208,688,260], fill=(*sh(C,0.34),255))
    return PH(f)
BIZ_HATS=[('hatFedora','中折れ帽',h_fedora())]

def p_briefcase():
    C=(96,66,48)
    def f(d):
        d.rounded_rectangle([336,748,686,942],20, fill=(*C,255))
        d.rounded_rectangle([336,748,686,808],16, fill=(*li(C,0.16),255))
        d.line([(336,846),(686,846)], fill=(*sh(C,0.24),255), width=8)
        d.rounded_rectangle([478,824,544,868],10, fill=(214,186,120,255))
        d.arc([432,660,590,780],180,360, fill=(*sh(C,0.18),255), width=20)
    return PP(f)
def p_musicbag():
    C=(122,32,50)
    def f(d):
        d.rounded_rectangle([326,730,696,948],26, fill=(*C,255))
        d.rounded_rectangle([326,730,696,806],22, fill=(*li(C,0.18),255))
        d.rounded_rectangle([406,712,616,772],18, fill=(*sh(C,0.24),255))
        d.arc([412,632,610,772],180,360, fill=(*sh(C,0.18),255), width=18)
        d.rounded_rectangle([352,838,470,932],8, fill=(246,242,232,255))
        for k in range(4):
            d.line([(362,856+k*20),(460,856+k*20)], fill=(160,152,140,255), width=4)
    return PP(f)
def p_newspaper():
    def f(d):
        d.polygon([(300,700),(511,672),(511,946),(300,922)], fill=(248,246,240,255))
        d.polygon([(511,672),(722,700),(722,922),(511,946)], fill=(236,232,222,255))
        d.rectangle([326,712,494,748], fill=(58,54,50,255))
        for k in range(8):
            d.line([(326,770+k*20),(490,770+k*20)], fill=(160,154,144,255), width=5)
        for k in range(8):
            d.line([(534,776+k*20),(700,776+k*20)], fill=(150,144,134,255), width=5)
        d.line([(511,672),(511,946)], fill=(206,200,190,255), width=6)
    return PP(f)
def p_umbrella():
    C=(52,66,102)
    def f(d):
        d.pieslice([256,538,766,1048],180,360, fill=(*C,255))
        for k in range(1,5):
            a=math.radians(180+k*36)
            d.line([(511,793),(511+255*math.cos(a),793+255*math.sin(a))], fill=(*sh(C,0.22),255), width=7)
        d.line([(511,538),(511,930)], fill=(126,96,64,255), width=14)
        d.arc([440,890,514,960],0,180, fill=(126,96,64,255), width=14)
    return PP(f)
def p_coffee():
    def f(d):
        d.rounded_rectangle([424,690,604,946],18, fill=(248,246,242,255))
        d.polygon([(424,690),(604,690),(590,946),(438,946)], fill=(250,248,244,255))
        d.rounded_rectangle([412,674,616,714],14, fill=(96,74,58,255))
        d.rounded_rectangle([420,776,608,844],10, fill=(158,110,70,255))
        d.ellipse([486,656,542,690], fill=(76,58,46,255))
        for (x,y,r) in [(470,632,22),(508,588,18),(474,548,15)]:
            d.ellipse([x-r,y-r,x+r,y+r], fill=(226,220,208,190))
    return PP(f)
BIZ_PROPS=[('propBriefcase','ブリーフケース',p_briefcase()),('propMusicBag','楽譜の鞄',p_musicbag()),
 ('propNewspaper','新聞',p_newspaper()),('propUmbrella','傘',p_umbrella()),('propCoffee','コーヒー',p_coffee())]

if __name__=='__main__':
    S=300; cols=5
    lst=[(k,n,g,'g') for k,n,g in SUITS]+[(k,n,g,'h') for k,n,g in BIZ_HATS]+[(k,n,g,'p') for k,n,g in BIZ_PROPS]
    rows=(len(lst)+cols-1)//cols
    sheet=Image.new('RGBA',(S*cols+24*(cols+1),(S+24)*rows+24),(247,242,230,255))
    for i,(k,n,g,kind) in enumerate(lst):
        p=new(); p.alpha_composite(body)
        if kind=='g': p.alpha_composite(g)
        p.alpha_composite(head)
        if kind in 'hp': p.alpha_composite(g)
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(24+(S+24)*(i%cols),24+(S+24)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-ビジネス10点.png')
    print('ok')
