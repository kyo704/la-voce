from PIL import Image, ImageDraw, ImageFilter
import numpy as np, math
from era import sh, li, new, W, H, body, head, jaw, CX
from acc import bake_ears

def top_y(x): return max(jaw(x)-14, 592-150*((x-CX)/300.0)**2)
HEM=958.0
# 形（胸→腰→裾）。y と 半分の幅
SHAPES={
 'column'  : [(596,240),(700,232),(770,230),(870,246),(HEM,262)],   # まっすぐ落ちる
 'empire'  : [(596,248),(660,218),(700,242),(800,292),(HEM,330)],   # 胸下で切り替え
 'mermaid' : [(596,242),(720,210),(830,214),(900,286),(HEM,344)],   # 膝下で開く
 'aline'   : [(596,250),(756,210),(820,266),(890,322),(HEM,360)],   # ふつうのドレス
 'ball'    : [(596,248),(730,210),(790,322),(880,400),(HEM,430)],   # 大きく広がる
 'wide'    : [(596,322),(660,276),(760,250),(860,316),(HEM,360)],   # 肩が張り出す
 'short'   : [(596,242),(700,224),(770,256),(806,272),(812,254)],   # 丈みじかめ
}
def half(y, shape, sc=1.0):
    K=SHAPES[shape]
    if y<=K[0][0]: return K[0][1]*sc
    for i in range(len(K)-1):
        y0,w0=K[i]; y1,w1=K[i+1]
        if y<=y1: return (w0+(w1-w0)*((y-y0)/(y1-y0)))*sc
    w=K[-1][1]*sc
    if y>K[-1][0]-30:
        u=min(1.0,(y-(K[-1][0]-30))/30.0); w*=(1-0.20*u*u)
    return w

def fill(a, col, shape, sc=1.0, ytop=560, ybot=None, pat=None, shrink=0):
    ybot=ybot or SHAPES[shape][-1][0]
    for y in range(int(ytop), int(min(H,ybot))):
        hw=half(y,shape,sc)-shrink
        if hw<=0: continue
        for x in range(max(0,int(CX-hw)), min(W,int(CX+hw)+1)):
            if y<top_y(x): continue
            b=pat(x,y,col) if pat else col
            u=(x-CX)/max(1.0,hw)
            if u<-0.55: b=li(b,0.15)
            elif u>0.44: b=sh(b,0.15)
            a[y,x]=(*b,255)

def outline(img, col, w=9):
    """ふちどり：うすい色の服が羊の毛に沈まないように"""
    a=np.array(img); m=(a[:,:,3]>10).astype('uint8')*255
    mi=Image.fromarray(m).filter(ImageFilter.MinFilter(w))
    edge=(m>0)&(np.array(mi)==0)
    a[edge]=(*col,255)
    return Image.fromarray(a)

def base(col, shape, sc=1.0, pat=None, bodice=None, waist=None, hem_band=None,
         sleeve=None, sleeve_col=None, deco=None, folds=True, edge=None):
    a=np.zeros((H,W,4),'uint8')
    yb=SHAPES[shape][-1][0]
    fill(a,col,shape,sc,560,yb,pat)
    l=Image.fromarray(a); d=ImageDraw.Draw(l)
    if sleeve:                                  # 袖（外に垂れる）
        sc2=sleeve_col or col
        for s in (-1,1):
            hw=half(640,shape,sc)
            x0=CX+s*int(hw*0.86); x1=CX+s*int(hw*1.52)
            d.rounded_rectangle([min(x0,x1),604,max(x0,x1),sleeve],46, fill=(*sc2,255))
    if bodice:
        b2=np.array(l)
        for y in range(560,748):
            hw=half(y,shape,sc)
            for x in range(int(CX-hw),int(CX+hw)+1):
                if 0<=x<W and y>=top_y(x): b2[y,x]=(*bodice,255)
        l=Image.fromarray(b2); d=ImageDraw.Draw(l)
    if hem_band:
        b2=np.array(l)
        for y in range(int(yb)-34,int(yb)):
            hw=half(y,shape,sc)
            for x in range(int(CX-hw),int(CX+hw)+1):
                if 0<=x<W: b2[y,x]=(*hem_band,255)
        l=Image.fromarray(b2); d=ImageDraw.Draw(l)
    if waist:
        hw=half(752,shape,sc)
        d.polygon([(CX-hw,736),(CX+hw,736),(CX+hw+4,776),(CX-hw-4,776)], fill=(*waist,255))
    if folds:
        for s2 in (-3,-2,-1,1,2,3):
            hw2=half(yb-40,shape,sc)
            d.line([(CX+s2*24,790),(CX+s2*hw2/3.4,yb-16)], fill=(*sh(col,0.12),255), width=6)
    if deco: deco(d)
    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x))),x]=(0,0,0,0)
    out=Image.fromarray(a)
    return outline(out, edge or sh(col,0.26))

# ── 柄 ──────────────────────────────────────────────
def P_bead(c2, step=44):
    def f(x,y,b):
        gx,gy=x%step-step//2,y%step-step//2
        return c2 if gx*gx+gy*gy<40 else b
    return f
def P_lace(c2, step=54):
    def f(x,y,b):
        gx,gy=x%step-step//2,y%step-step//2; dd=math.hypot(gx,gy)
        return c2 if 15<dd<21 or dd<5 else b
    return f
def P_velvet(c2): return lambda x,y,b:(c2 if (x*3+y*5)%37<6 else b)
def P_scale(c2):                      # 鳳凰の羽（トゥーランドット）
    def f(x,y,b):
        step=52; gy=y%step-step//2; gx=(x+(y//step)*26)%step-step//2
        d0=math.hypot(gx,gy*1.3)
        return c2 if 16<d0<22 else b
    return f
def P_feather(c2,c3):
    def f(x,y,b):
        yy=y%56; xx=(x+(y//56)*28)%56-28
        if yy<7: return sh(b,0.2)
        return c2 if abs(xx)<18-yy*0.2 else c3
    return f
def P_stripe(c2,w=22): return lambda x,y,b:(c2 if (x//w)%2==0 else b)

def PH(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return bake_ears(l)
def PP(fn):
    l=new(); d=ImageDraw.Draw(l); fn(d); return l

GOLD=(212,178,96); GOLD2=(160,124,48)

# ══ 役の衣装 12 ════════════════════════════════════════
def d_bruennhilde(d):                       # 銀の胸当て＋赤いマント
    for s in (-1,1):                        # マント
        d.polygon([(CX+s*150,606),(CX+s*300,660),(CX+s*268,930),(CX+s*140,912)], fill=(158,26,40,255))
    d.polygon([(CX-166,600),(CX+166,600),(CX+150,760),(CX-150,760)], fill=(206,212,222,255))
    d.polygon([(CX-166,600),(CX+166,600),(CX+156,646),(CX-156,646)], fill=(232,236,244,255))
    d.ellipse([CX-104,652,CX-8,742], fill=(178,186,200,255))
    d.ellipse([CX+8,652,CX+104,742], fill=(178,186,200,255))
    d.ellipse([CX-30,690,CX+30,750], fill=(*GOLD,255))
    for k in range(4):
        d.line([(CX-150,780+k*34),(CX+150,780+k*34)], fill=(168,176,190,255), width=9)
def d_turandot(d):                          # 金の襟と胸飾り
    d.polygon([(CX-286,600),(CX+286,600),(CX+236,690),(CX-236,690)], fill=(*GOLD,255))
    d.polygon([(CX-286,600),(CX+286,600),(CX+262,640),(CX-262,640)], fill=(238,214,150,255))
    for s in (-1,1):
        d.polygon([(CX+s*206,690),(CX+s*300,704),(CX+s*286,880),(CX+s*192,860)], fill=(*GOLD2,255))
    d.ellipse([CX-52,700,CX+52,804], fill=(*GOLD,255)); d.ellipse([CX-28,726,CX+28,778], fill=(178,26,44,255))
def d_aida(d):                              # ウセフ（大きな襟飾り）
    for i,c in enumerate([GOLD,(52,120,150),(178,44,52),GOLD]):
        r=210-i*30
        d.pieslice([CX-r,600-r//2,CX+r,600+r+r//2],0,180, fill=(*c,255))
    d.pieslice([CX-90,562,CX+90,742],0,180, fill=(246,242,232,255))
    for s in (-1,1):
        d.rounded_rectangle([CX+s*150-26,760,CX+s*150+26,930],20, fill=(*GOLD,255))
def d_norma(d):                             # 白い長衣＋金の帯と槲寄生
    d.polygon([(CX-160,700),(CX+160,700),(CX+180,742),(CX-180,742)], fill=(*GOLD,255))
    for s in (-1,1):
        d.line([(CX+s*40,742),(CX+s*66,930)], fill=(*GOLD2,255), width=8)
    for (x,y) in [(CX-116,806),(CX+126,832),(CX-70,890)]:
        for k in range(3):
            a=k*2*math.pi/3
            d.ellipse([x+18*math.cos(a)-14,y+18*math.sin(a)-14,x+18*math.cos(a)+14,y+18*math.sin(a)+14],
                      fill=(122,158,116,255))
        d.ellipse([x-9,y-9,x+9,y+9], fill=(238,240,226,255))
def d_lucia(d):                             # 白い寝間着＋血のしみ
    for k in range(5):
        d.line([(CX-150+k*76,600),(CX-150+k*76,930)], fill=(232,230,226,255), width=5)
    d.polygon([(CX+30,700),(CX+96,742),(CX+72,824),(CX+16,782)], fill=(178,32,44,220))
    d.ellipse([CX+92,830,CX+126,868], fill=(178,32,44,200))
    d.ellipse([CX-10,850,CX+22,880], fill=(178,32,44,180))
def d_butterfly(d):                         # 白無垢の帯と衿
    XP,YP=CX-6,742
    for over in (False,True):
        xs=CX+116 if over else CX-116
        for i,c in enumerate([(226,222,212),(244,242,236)]):
            d.line([(xs,int(top_y(xs))-6),(XP,YP)], fill=(*(c if over else sh(c,0.08)),255), width=44-i*14)
    d.rectangle([CX-250,744,CX+250,836], fill=(238,228,196,255))
    d.rectangle([CX-250,744,CX+250,764], fill=(248,242,220,255))
    d.rounded_rectangle([CX-54,766,CX+54,814],14, fill=(*GOLD,255))
def d_mimi(d):                              # ショールとエプロン
    for s in (-1,1):
        d.polygon([(CX+s*24,604),(CX+s*216,676),(CX+s*186,812),(CX+s*20,740)], fill=(126,102,86,255))
    d.polygon([(CX-118,750),(CX+118,750),(CX+140,900),(CX-140,900)], fill=(232,226,210,255))
    d.line([(CX-118,762),(CX+118,762)], fill=(210,202,184,255), width=6)
def d_musetta(d):                           # フリルとリボン
    for i,yy in enumerate((826,876,926)):
        for x in range(CX-320,CX+320,60):
            d.pieslice([x-32,yy-28,x+32,yy+28],0,180,
                       fill=((236,214,120) if i%2==0 else (188,52,110))+(255,))
    d.polygon([(CX,700),(CX-96,664),(CX-96,748)], fill=(236,214,120,255))
    d.polygon([(CX,700),(CX+96,664),(CX+96,748)], fill=(236,214,120,255))
    d.ellipse([CX-26,676,CX+26,726], fill=(198,166,72,255))
def d_cherubino(d):                         # 小姓の上着＋ボタン
    d.polygon([(CX-150,600),(CX,700),(CX+150,600)], fill=(238,234,224,255))
    d.line([(CX,700),(CX,806)], fill=(*GOLD2,255), width=6)
    for y in (724,764,802):
        d.ellipse([CX-15,y-15,CX+15,y+15], fill=(*GOLD,255))
    for s in (-1,1):
        d.rounded_rectangle([CX+s*168-40,700,CX+s*168+40,806],26, fill=(*GOLD2,255))
def d_olympia(d):                           # 人形：レースの段
    for i,yy in enumerate((790,846,902,952)):
        for x in range(CX-380,CX+380,52):
            d.pieslice([x-28,yy-26,x+28,yy+26],0,180, fill=(248,244,240,255))
            d.arc([x-28,yy-26,x+28,yy+26],0,180, fill=(214,204,214,255), width=4)
    d.polygon([(CX-134,604),(CX,690),(CX+134,604)], fill=(248,246,244,255))
    d.ellipse([CX-30,684,CX+30,730], fill=(196,150,180,255))
def d_gilda(d):                             # 素朴な水色＋白いエプロン
    d.polygon([(CX-104,742),(CX+104,742),(CX+126,912),(CX-126,912)], fill=(246,244,238,255))
    for s in (-1,1):
        d.line([(CX+s*72,604),(CX+s*104,748)], fill=(246,244,238,255), width=26)
    d.ellipse([CX-24,724,CX+24,772], fill=(214,206,190,255))
def d_carmen(d):                            # フリル＋黒レース
    for i,yy in enumerate((836,890,944)):
        for x in range(CX-330,CX+330,64):
            d.pieslice([x-34,yy-30,x+34,yy+30],0,180,
                       fill=((28,26,32) if i%2==0 else (52,48,56))+(255,))
    d.polygon([(CX-140,600),(CX+140,600),(CX+126,660),(CX-126,660)], fill=(226,72,88,255))
def d_papageno(d):                          # 羽根と笛
    d.rounded_rectangle([CX-40,700,CX+40,860],18, fill=(*GOLD2,255))
    for k in range(5):
        d.rounded_rectangle([CX-36+k*15,708,CX-26+k*15,852],5, fill=(*GOLD,255))

ROLES=[
 ('operaBruennhilde','ブリュンヒルデ（ワルキューレ）',
  base((88,102,120),'column',1.0,P_velvet((104,118,138)),bodice=(96,110,130),deco=d_bruennhilde,folds=False)),
 ('operaTurandot','トゥーランドット',
  base((176,26,44),'wide',1.0,P_scale((206,52,68)),hem_band=(212,178,96),deco=d_turandot,sleeve=880,sleeve_col=(150,20,38))),
 ('operaAida','アイーダ',
  base((244,240,228),'column',1.05,P_lace((228,222,206)),deco=d_aida,folds=True,edge=(196,178,124))),
 ('operaNorma','ノルマ',
  base((238,236,228),'empire',1.0,None,deco=d_norma,sleeve=900,sleeve_col=(228,226,216),edge=(186,182,166))),
 ('operaLucia','ルチア（狂乱の場）',
  base((246,246,244),'column',1.0,None,deco=d_lucia,sleeve=920,sleeve_col=(238,238,234),edge=(178,178,182))),
 ('operaButterfly','蝶々夫人（白無垢）',
  base((244,242,236),'aline',0.96,None,deco=d_butterfly,sleeve=880,sleeve_col=(236,234,226),folds=False,edge=(186,178,158))),
 ('operaMimi','ミミ（ラ・ボエーム）',
  base((146,118,92),'aline',0.94,P_stripe((160,132,104),18),bodice=(120,96,76),deco=d_mimi)),
 ('operaMusetta','ムゼッタ',
  base((188,52,110),'ball',1.0,P_bead((214,90,140)),bodice=(206,72,126),waist=(236,214,120),deco=d_musetta)),
 ('operaCherubino','ケルビーノ（フィガロの結婚）',
  base((132,44,58),'short',1.0,P_velvet((152,58,74)),deco=d_cherubino,folds=False)),
 ('operaOlympia','オランピア（ホフマン物語）',
  base((236,222,232),'ball',1.02,P_lace((246,236,242)),bodice=(246,240,244),waist=(196,150,180),deco=d_olympia,edge=(190,160,186))),
 ('operaGilda','ジルダ（リゴレット）',
  base((150,182,206),'aline',0.94,None,bodice=(132,166,192),deco=d_gilda)),
 ('operaCarmen2','カルメン',
  base((186,26,44),'mermaid',1.0,None,bodice=(214,52,72),waist=(28,26,32),deco=d_carmen)),
]

# ══ 演奏会のドレス 4（実在の歌手の名は付けません）════════
def d_stole(d, c):                          # ストール
    for s in (-1,1):
        d.polygon([(CX+s*90,600),(CX+s*236,646),(CX+s*206,900),(CX+s*80,860)], fill=(*c,255))
def RECITAL():
    return [
 ('gownCoutureFifties','1950年代のクチュール（細身＋ストール）',
  base((30,28,36),'mermaid',1.0,P_velvet((46,44,54)),bodice=(24,22,30),
       deco=lambda d:(d_stole(d,(226,222,214)),
                      d.ellipse([CX-30,672,CX+30,724], fill=(228,232,238,255)),
                      d.ellipse([CX-16,686,CX+16,710], fill=(180,190,206,255))))),
 ('gownTulleBall','広がるチュールのボールガウン',
  base((238,216,226),'ball',1.06,P_lace((248,236,242)),bodice=(246,232,238),waist=(212,166,186),edge=(198,158,178))),
 ('gownBeadColumn','ビーズのコラムドレス',
  base((44,58,96),'column',1.0,P_bead((214,204,150),40),bodice=(38,50,84))),
 ('gownVelvetCape','ベルベットとケープ',
  base((72,26,52),'aline',1.0,P_velvet((92,36,66)),bodice=(60,20,44),waist=(206,178,110),
       deco=lambda d: d_stole(d,(96,34,66)))),
    ]

# ══ かぶりもの・持ち物 8 ═══════════════════════════════
def h_valkyrie():
    def f(d):
        C=(196,202,214)
        d.ellipse([326,86,696,306], fill=(*C,255)); d.ellipse([326,86,696,232], fill=(228,232,240,255))
        d.rounded_rectangle([300,266,722,318],20, fill=(168,176,190,255))
        for s in (-1,1):
            for k in range(3):
                d.polygon([(511+s*180,264-k*14),(511+s*300,120-k*40),(511+s*354,104-k*36),
                           (511+s*300,190-k*26),(511+s*196,300-k*8)],
                          fill=(*((236,238,244) if k%2==0 else (198,204,216)),255))
    return PH(f)
def h_turandot_crown():
    def f(d):
        G=(212,178,96)
        d.polygon([(316,300),(706,300),(676,120),(596,214),(511,80),(426,214),(346,120)], fill=(*G,255))
        d.rectangle([316,286,706,332], fill=(178,140,60,255))
        for (x,y,c) in [(392,180,(178,26,44)),(511,140,(46,120,150)),(630,180,(178,26,44))]:
            d.ellipse([x-22,y-22,x+22,y+22], fill=(*c,255))
        for s in (-1,1):
            for k in range(4):
                d.line([(511+s*(120+k*46),300),(511+s*(150+k*58),96+k*22)], fill=(*G,255), width=8)
                d.ellipse([511+s*(150+k*58)-15,80+k*22,511+s*(150+k*58)+15,110+k*22], fill=(238,214,150,255))
    return PH(f)
def h_norma_crown():
    def f(d):
        d.arc([288,110,734,392],186,354, fill=(198,166,90,255), width=18)
        for (x,y) in [(360,180),(662,180)]:
            for k in range(3):
                a=k*2*math.pi/3
                d.ellipse([x+20*math.cos(a)-16,y+20*math.sin(a)-16,x+20*math.cos(a)+16,y+20*math.sin(a)+16],
                          fill=(122,158,116,255))
            d.ellipse([x-10,y-10,x+10,y+10], fill=(238,240,226,255))
    return PH(f)
def h_musetta_hat():
    def f(d):
        C=(188,52,110)
        d.ellipse([166,196,856,340], fill=(*C,255)); d.ellipse([166,196,856,306], fill=(210,80,134,255))
        d.rounded_rectangle([336,84,686,262],90, fill=(*C,255))
        d.rectangle([336,214,686,262], fill=(236,214,120,255))
        for k in range(4):
            d.polygon([(640,200-k*10),(756,90-k*30),(818,84-k*26),(752,152-k*18),(660,244-k*6)],
                      fill=(*((248,246,240) if k%2==0 else (226,222,212)),255))
    return PH(f)
def h_cherubino_hat():
    def f(d):
        C=(132,44,58)
        d.ellipse([236,206,786,330], fill=(*C,255)); d.ellipse([236,206,786,300], fill=(158,58,74,255))
        d.rounded_rectangle([346,96,676,258],80, fill=(*C,255))
        d.rectangle([346,212,676,256], fill=(212,178,96,255))
        for k in range(3):
            d.polygon([(636,198-k*10),(744,96-k*28),(796,90-k*24),(738,152-k*16),(652,238-k*6)],
                      fill=(*((246,238,214) if k%2==0 else (222,210,178)),255))
    return PH(f)
def h_lucia_hair():
    def f(d):
        C=(126,96,72)
        for s2 in (-1,1):                       # 横に垂れる長い髪だけ
            for k in range(5):
                x=511+s2*(236+k*22); y=200+k*26
                d.ellipse([x-60,y-70,x+60,y+300], fill=(*C,255))
                d.ellipse([x-44,y-56,x+30,y+180], fill=(*li(C,0.10),255))
        d.arc([282,96,740,382],190,350, fill=(*C,255), width=60)   # 頭のてっぺん
        d.arc([300,112,722,366],196,344, fill=(*li(C,0.10),255), width=22)
        for k in range(6):                      # ほつれ毛
            x=300+k*84
            d.line([(x,180),(x+((-1)**k)*30,116)], fill=(*sh(C,0.12),255), width=9)
    return PH(f)
def h_butterfly_hair():
    def f(d):
        d.polygon([(276,286),(746,286),(722,150),(300,150)], fill=(246,244,238,255))
        d.polygon([(276,286),(746,286),(736,200),(286,200)], fill=(232,228,218,255))
        d.line([(276,286),(746,286)], fill=(214,208,196,255), width=8)
    return PH(f)
def p_spear():
    def f(d):
        d.line([(430,952),(600,520)], fill=(120,92,64,255), width=26)
        d.polygon([(586,548),(632,470),(660,540),(614,584)], fill=(214,220,230,255))
        d.polygon([(586,548),(614,504),(636,540),(614,584)], fill=(176,184,198,255))
    return PP(f)
def p_fan_lace():
    def f(d):
        d.pieslice([236,516,786,1066],200,340, fill=(30,28,34,255))
        d.pieslice([300,580,722,1002],200,340, fill=(72,68,76,255))
        for k in range(9):
            a=math.radians(200+k*17.5)
            d.line([(511+40*math.cos(a),790+40*math.sin(a)),(511+274*math.cos(a),790+274*math.sin(a))],
                   fill=(20,18,24,255), width=6)
        d.ellipse([490,770,532,812], fill=(212,178,96,255))
    return PP(f)

STAGE=[('hatValkyrie','翼の兜（ワルキューレ）',h_valkyrie()),
       ('hatTurandotCrown','トゥーランドットの冠',h_turandot_crown()),
       ('hatNormaWreath','ノルマの槲寄生の冠',h_norma_crown()),
       ('hatMusettaHat','ムゼッタの帽子',h_musetta_hat()),
       ('hatCherubinoHat','ケルビーノの羽根帽',h_cherubino_hat()),
       ('hatLuciaHair','ルチアの乱れ髪',h_lucia_hair()),
       ('hatButterflyTsuno','蝶々夫人の角隠し',h_butterfly_hair())]
STAGE_PROPS=[('propSpear','槍（ワルキューレ）',p_spear()),
             ('propFanLace','黒いレースの扇',p_fan_lace())]

if __name__=='__main__':
    from handfix import place
    REC=RECITAL()
    lst=[(k,n,g,'g') for k,n,g in ROLES+REC]+[(k,n,g,'h') for k,n,g in STAGE]+[(k,n,g,'p') for k,n,g in STAGE_PROPS]
    S=300; cols=8; rows=(len(lst)+cols-1)//cols
    sheet=Image.new('RGBA',(S*cols+22*(cols+1),(S+22)*rows+22),(247,242,230,255))
    for i,(k,n,g,kind) in enumerate(lst):
        p=new(); p.alpha_composite(body)
        if kind=='g': p.alpha_composite(g)
        p.alpha_composite(head)
        if kind=='h': p.alpha_composite(g)
        if kind=='p': p.alpha_composite(place(g,'R'))
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(22+(S+22)*(i%cols),22+(S+22)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-オペラ25点.png')
    print(len(lst))
