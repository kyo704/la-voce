from PIL import Image, ImageDraw
import numpy as np
A,B,C,FLAT=-0.00237595,2.49995,-58.78,490.0
def jaw(x): return max(A*x*x+B*x+C,FLAT)
CX=511
orig=Image.open('orig_sheep.png').convert('RGBA')
head=Image.open('sheepparts2/sheep_head.png').convert('RGBA')
body=Image.open('sheepparts2/sheep_body.png').convert('RGBA')
W,H=orig.size; SIL=np.array(orig)[:,:,3]
def sh(c,d): return tuple(max(0,int(v*(1-d))) for v in c)
def li(c,d): return tuple(int(v+(255-v)*d) for v in c)
def new(): return Image.new('RGBA',(W,H),(0,0,0,0))
def clip(l):
    a=np.array(l); a[:,:,3]=(a[:,:,3].astype(int)*SIL.astype(int)//255).astype('uint8')
    return Image.fromarray(a)
EY,ERX,ERY=660,268,300
def torso_hw(y):
    t=1-((y-EY)/ERY)**2
    return ERX*np.sqrt(t) if t>0 else 0.0

def build(col, hem_y=790, drop=30, shoulder_drop=150, sleeve=True, sleeve_x=196,
          collar=True, buttons=2, cuff=True, pattern=None, accent=None):
    dark=sh(col,0.15); shad=sh(col,0.26)
    def shoulder(x): return 592 - shoulder_drop*((x-CX)/300.0)**2
    def top_y(x):    return max(jaw(x)-14, shoulder(x))
    def hemc(x):
        u=(x-CX)/260.0
        return hem_y + drop*max(0.0,1-u*u)
    l=new(); a=np.array(l)
    for y in range(470,H):
        hw=torso_hw(y)
        if hw<=0: continue
        for x in range(int(CX-hw),int(CX+hw)+1):
            t=top_y(x); b=hemc(x)
            if y<t or y>b: continue
            base = dark if (sleeve and abs(x-CX)>sleeve_x) else col
            if pattern:
                base = pattern(x,y,base)
            c = li(base,0.17) if y<t+80 else (sh(base,0.14) if y>b-32 else base)
            a[y,x]=(*c,255)
    l=Image.fromarray(a); d=ImageDraw.Draw(l)
    if sleeve and cuff:
        for s in (-1,1):
            x0=CX+s*sleeve_x; x1=CX+s*(sleeve_x+150)
            d.rounded_rectangle([min(x0,x1),hem_y-118,max(x0,x1),hem_y-46],26, fill=(*shad,255))
    if buttons:
        d.line([(CX,int(top_y(CX))+72),(CX,hem_y+drop-20)], fill=(*sh(col,0.22),255), width=6)
        for i in range(buttons):
            y=676+i*76
            d.ellipse([CX-17,y-17,CX+17,y+17], fill=(*li(accent or col,0.68),255))
            d.ellipse([CX-6,y-6,CX+6,y+6], fill=(*sh(col,0.32),255))
    if collar:
        cc=li(accent or col,0.42); j=int(jaw(CX))
        d.pieslice([CX-124,j-104,CX-4,j+50],18,174, fill=(*cc,255))
        d.pieslice([CX+4,j-104,CX+124,j+50],6,162, fill=(*cc,255))
    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x))),x]=(0,0,0,0)
    for y in range(H):
        hw=torso_hw(y)
        a[y,:max(0,int(CX-hw))]=(0,0,0,0); a[y,min(W,int(CX+hw))+1:]=(0,0,0,0)
    for x in range(W): a[int(hemc(x)):,x]=(0,0,0,0)
    return clip(Image.fromarray(a))

# ── 柄 ─────────────────────────────────────────
def stripes(c2, w=34):
    return lambda x,y,base: (c2 if ((x+y)//w)%2==0 else base)
def dots(c2, step=76, r=13):
    def f(x,y,base):
        return c2 if ((x%step-step//2)**2+(y%step-step//2)**2) < r*r else base
    return f
def check(c2, w=52):
    return lambda x,y,base: (c2 if ((x//w)%2==0)^((y//w)%2==0) else base)

def stack(g):
    p=new(); p.alpha_composite(body); p.alpha_composite(g); p.alpha_composite(head); return p

SPRING=(232,168,182); SUMMER=(122,178,196); AUTUMN=(186,146,96); WINTER=(72,86,128)
items=[
 ('春 うすもものカーデ', build(SPRING,hem_y=756,drop=26,sleeve_x=200,buttons=2,accent=(255,240,240))),
 ('夏 みずいろのベスト', build(SUMMER,hem_y=744,drop=22,sleeve=False,buttons=2,
                          pattern=stripes(li(SUMMER,0.28),30), accent=(250,252,255))),
 ('秋 キャメルのコート', build(AUTUMN,hem_y=838,drop=26,buttons=3,
                          pattern=check(sh(AUTUMN,0.10),58))),
 ('冬 こんのダッフル',   build(WINTER,hem_y=852,drop=22,sleeve_x=204,buttons=3,accent=(224,214,190))),
]
S=400
sheet=Image.new('RGBA',(S*4+40*5,S+80),(247,242,230,255))
for i,(n,g) in enumerate(items):
    c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(stack(g))
    sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(40+(S+40)*i,40))
sheet.convert('RGB').save('/home/claude/out/羊-四季4点.png')
print('ok')
