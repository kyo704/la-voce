from PIL import Image, ImageDraw, ImageFilter
import numpy as np, math
from era import sh, li, new, W, H, body, head, jaw, CX
from acc import bake_ears
from opera import SHAPES, half, fill, outline, top_y, PH, PP, P_velvet, P_lace, P_stripe, P_bead
GOLD=(212,178,96); GOLD2=(158,118,46)

# 脚（半ズボン＋タイツ／長ズボン）
LEGX=[(342,494),(530,682)]
def legs(d, col, y0=792, y1=944, r=34):
    for (x0,x1) in LEGX:
        d.rounded_rectangle([x0,y0,x1,y1], r, fill=(*col,255))
        d.rounded_rectangle([x0,y0,x0+int((x1-x0)*0.34),y1], r-8, fill=(*li(col,0.13),255))
def boots(d, col, y0=856, y1=958):
    for (x0,x1) in LEGX:
        d.rounded_rectangle([x0-8,y0,x1+8,y1], 26, fill=(*col,255))
        d.rounded_rectangle([x0-14,y1-30,x1+14,y1], 14, fill=(*sh(col,0.34),255))

def suit(col, shape='short', sc=1.0, pat=None, leg=None, boot=None, lapel=None,
         belt=None, cape=None, deco=None, edge=None, sleeve=None, sleeve_col=None):
    a=np.zeros((H,W,4),'uint8')
    yb=SHAPES[shape][-1][0]
    l0=Image.new('RGBA',(W,H),(0,0,0,0)); d0=ImageDraw.Draw(l0)
    if cape:                                    # マントは服のうしろ
        for s in (-1,1):
            d0.polygon([(CX+s*140,600),(CX+s*318,676),(CX+s*284,944),(CX+s*130,908)], fill=(*cape,255))
        for s in (-1,1):
            d0.polygon([(CX+s*140,600),(CX+s*228,640),(CX+s*212,900),(CX+s*130,908)],
                       fill=(*li(cape,0.12),255))
    if leg:   legs(d0, leg)
    if boot:  boots(d0, boot)
    fill(a, col, shape, sc, 560, yb, pat)
    l=Image.fromarray(a)
    base_=Image.new('RGBA',(W,H),(0,0,0,0))
    base_.alpha_composite(l0); base_.alpha_composite(l)
    l=base_; d=ImageDraw.Draw(l)
    if sleeve:
        sc2=sleeve_col or sh(col,0.10)
        for s in (-1,1):
            hw=half(640,shape,sc)
            x0=CX+s*int(hw*0.84); x1=CX+s*int(hw*1.46)
            d.rounded_rectangle([min(x0,x1),604,max(x0,x1),sleeve],44, fill=(*sc2,255))
    if lapel:                                   # 折り襟＋シャツ
        d.polygon([(CX-150,int(top_y(CX-150))),(CX,712),(CX+150,int(top_y(CX+150)))], fill=(*lapel,255))
        d.polygon([(CX-96,int(top_y(CX-96))),(CX,700),(CX+96,int(top_y(CX+96)))], fill=(246,244,238,255))
    if belt:
        hw=half(776,shape,sc)
        d.rectangle([CX-hw,758,CX+hw,802], fill=(*belt,255))
        d.rounded_rectangle([CX-34,754,CX+34,806],10, fill=(*li(belt,0.5),255))
    if deco: deco(d)
    a=np.array(l)
    for x in range(W): a[:max(0,int(top_y(x))),x]=(0,0,0,0)
    return outline(Image.fromarray(a), edge or sh(col,0.28))

# ── 役ごとの飾り ─────────────────────────────────────
def d_figaro(d):
    d.polygon([(CX-118,700),(CX+118,700),(CX+140,880),(CX-140,880)], fill=(244,242,236,255))
    d.line([(CX-118,714),(CX+118,714)], fill=(214,210,200,255), width=6)
    for y in (748,796):
        d.ellipse([CX-15,y-15,CX+15,y+15], fill=(*GOLD,255))
def d_giovanni(d):
    d.polygon([(CX-146,606),(CX,700),(CX+146,606)], fill=(248,246,240,255))
    for k in range(4):
        d.line([(CX-104,690+k*10),(CX+104,690+k*10)], fill=(238,234,224,255), width=7)
    d.line([(CX,706),(CX,796)], fill=(*GOLD2,255), width=6)
    for y in (726,762):
        d.ellipse([CX-14,y-14,CX+14,y+14], fill=(*GOLD,255))
def d_rodolfo(d):
    for s in (-1,1):                            # マフラー
        d.rounded_rectangle([CX-190,610,CX+190,676],30, fill=(150,60,60,255))
    d.polygon([(CX+40,676),(CX+120,676),(CX+134,860),(CX+56,872)], fill=(150,60,60,255))
    d.polygon([(CX-150,600),(CX,700),(CX+150,600)], fill=(96,84,72,255))
def d_escamillo(d):
    for s in (-1,1):                            # 金の刺繍
        for k in range(5):
            x=CX+s*(96+k*26); y=636+k*34
            d.ellipse([x-15,y-15,x+15,y+15], fill=(*GOLD,255))
            d.ellipse([x-7,y-7,x+7,y+7], fill=(*GOLD2,255))
    d.polygon([(CX-140,600),(CX,690),(CX+140,600)], fill=(246,244,236,255))
    d.rounded_rectangle([CX-52,690,CX+52,742],16, fill=(178,26,44,255))
def d_rigoletto(d):
    for i in range(7):                          # まだら
        c=(196,44,60) if i%2 else (216,180,70)
        d.polygon([(CX-240+i*70,600),(CX-206+i*70,600),(CX-190+i*70,900),(CX-236+i*70,900)],
                  fill=(*c,255))
    for x in (CX-150,CX,CX+150):                # 襟の鈴
        d.ellipse([x-24,672,x+24,720], fill=(*GOLD,255))
    d.pieslice([CX-240,600,CX+240,780],0,180, fill=(240,238,230,255))
def d_tamino(d):
    d.polygon([(CX-140,604),(CX,700),(CX+140,604)], fill=(232,224,200,255))
    d.line([(CX-190,700),(CX+190,700)], fill=(*GOLD,255), width=10)
    for k in range(5):
        x=CX-136+k*68
        d.polygon([(x,714),(x+30,714),(x+22,782),(x+8,782)], fill=(*GOLD,255))
def d_wotan(d):
    for s in (-1,1):
        d.polygon([(CX+s*120,604),(CX+s*232,660),(CX+s*208,884),(CX+s*110,860)], fill=(96,84,72,255))
    d.polygon([(CX-160,600),(CX+160,600),(CX+140,676),(CX-140,676)], fill=(178,180,190,255))
    d.ellipse([CX-40,662,CX+40,742], fill=(*GOLD,255)); d.ellipse([CX-20,682,CX+20,722], fill=(*GOLD2,255))
def d_calaf(d):
    d.polygon([(CX-160,600),(CX,706),(CX+160,600)], fill=(238,226,190,255))
    d.rounded_rectangle([CX-210,738,CX+210,796],18, fill=(*GOLD,255))
    for k in range(6):
        x=CX-176+k*70
        d.ellipse([x-16,752,x+16,784], fill=(*GOLD2,255))

MEN=[
 ('operaFigaro','フィガロ（セビリアの理髪師）',
  suit((58,96,148),'short',1.0,None,leg=(226,222,212),boot=(72,60,52),lapel=(46,80,128),deco=d_figaro)),
 ('operaDonGiovanni','ドン・ジョヴァンニ',
  suit((36,32,42),'short',1.0,P_velvet((52,48,60)),leg=(56,50,62),boot=(30,26,34),
       cape=(126,24,44),belt=(24,22,28),deco=d_giovanni)),
 ('operaRodolfo','ロドルフォ（ラ・ボエーム）',
  suit((92,80,68),'aline',0.96,P_stripe((104,92,78),20),leg=(74,64,54),boot=(58,48,40),deco=d_rodolfo)),
 ('operaEscamillo','エスカミーリョ（闘牛士）',
  suit((146,26,44),'short',1.0,None,leg=(226,222,212),boot=(34,30,36),
       cape=(196,42,60),belt=(*(30,28,34),),deco=d_escamillo)),
 ('operaRigoletto','リゴレット（道化）',
  suit((216,180,70),'aline',0.96,None,leg=(196,44,60),boot=(120,96,60),deco=d_rigoletto)),
 ('operaTamino','タミーノ（魔笛）',
  suit((72,116,92),'short',1.0,None,leg=(214,206,186),boot=(96,72,52),belt=(150,110,60),deco=d_tamino)),
 ('operaWotan','ヴォータン（ワルキューレ）',
  suit((70,76,92),'aline',1.0,P_velvet((86,92,110)),leg=(96,84,72),boot=(64,52,44),
       cape=(58,62,76),deco=d_wotan)),
 ('operaCalaf','カラフ（トゥーランドット）',
  suit((44,76,132),'aline',1.0,P_lace((62,98,158)),leg=(38,64,112),boot=(54,44,38),
       sleeve=880,sleeve_col=(38,66,116),deco=d_calaf)),
]

# ── かぶりもの 5 ─────────────────────────────────────
def h_montera():
    def f(d):
        C=(32,30,36)
        d.ellipse([300,96,722,300], fill=(*C,255))
        d.ellipse([300,96,722,222], fill=(58,54,62,255))
        for s in (-1,1):
            d.ellipse([511+s*196-84,140,511+s*196+84,296], fill=(*C,255))
        d.rounded_rectangle([288,268,734,326],22, fill=(20,18,24,255))
    return PH(f)
def h_jester():
    def f(d):
        for i,(dx,dy,c) in enumerate([(-236,-30,(196,44,60)),(0,-90,(216,180,70)),(236,-30,(196,44,60))]):
            x=511+dx
            d.polygon([(511+dx*0.42,290),(x,60+dy),(511+dx*0.42+66,290)],
                      fill=(*c,255))
            d.ellipse([x-30,30+dy,x+30,90+dy], fill=(*GOLD,255))
        d.rounded_rectangle([292,258,730,330],28, fill=(216,180,70,255))
        for k in range(6):
            d.rectangle([300+k*72,258,336+k*72,330], fill=(196,44,60,255))
    return PH(f)
def h_tricorn_black():
    def f(d):
        C=(34,32,40)
        d.polygon([(150,308),(872,308),(716,156),(511,100),(306,156)], fill=(*C,255))
        d.polygon([(150,308),(511,308),(511,100),(306,156)], fill=(56,52,62,255))
        d.rounded_rectangle([360,100,662,272],86, fill=(24,22,28,255))
        d.ellipse([150,290,872,352], fill=(20,18,24,255))
        for k in range(3):
            d.polygon([(660,158-k*8),(790,64-k*26),(848,58-k*22),(788,120-k*16),(688,204-k*6)],
                      fill=(*((246,244,238) if k%2==0 else (222,218,208)),255))
    return PH(f)
def h_wotan():
    def f(d):
        C=(86,74,60)
        d.ellipse([146,206,876,346], fill=(*C,255)); d.ellipse([146,206,876,312], fill=(108,94,76,255))
        d.rounded_rectangle([336,74,686,266],96, fill=(*C,255))
        d.rectangle([336,214,686,262], fill=(62,54,44,255))
        for k in range(3):
            d.polygon([(650,196-k*10),(770,96-k*28),(824,90-k*24),(762,152-k*16),(668,242-k*6)],
                      fill=(*((70,64,58) if k%2==0 else (52,48,44)),255))
    return PH(f)
def h_hunter():
    def f(d):
        C=(72,116,92)
        d.ellipse([206,204,816,330], fill=(*C,255)); d.ellipse([206,204,816,300], fill=(92,142,114,255))
        d.rounded_rectangle([340,72,682,258],92, fill=(*C,255))
        d.rectangle([340,206,682,254], fill=(150,110,60,255))
        for k in range(3):
            d.polygon([(654,190-k*10),(742,84-k*26),(792,80-k*22),(736,144-k*16),(672,236-k*6)],
                      fill=(*((236,216,140) if k%2==0 else (206,180,100)),255))
    return PH(f)
MEN_HATS=[('hatMontera','闘牛士のモンテラ',h_montera()),('hatJester','道化の鈴帽',h_jester()),
          ('hatTricornBlack','羽根つき三角帽',h_tricorn_black()),('hatWotanHat','つば広の旅帽',h_wotan()),
          ('hatHunterGreen','狩人の帽子',h_hunter())]

# ── 持ち物 4 ────────────────────────────────────────
def p_sword():
    def f(d):
        d.line([(392,946),(636,530)], fill=(190,196,208,255), width=34)
        d.line([(398,940),(630,538)], fill=(240,244,250,255), width=18)
        d.polygon([(618,514),(660,540),(628,556)], fill=(240,244,250,255))
        d.line([(360,988),(414,896)], fill=(88,66,48,255), width=38)
        d.rounded_rectangle([352,868,466,916],14, fill=(*GOLD,255))
        d.ellipse([352,952,410,1004], fill=(*GOLD2,255))
    return PP(f)
def p_baton():
    def f(d):
        d.line([(392,946),(672,540)], fill=(210,206,196,255), width=22)
        d.line([(396,940),(668,548)], fill=(250,248,244,255), width=13)
        d.rounded_rectangle([352,890,458,996],34, fill=(96,72,52,255))
        d.rounded_rectangle([352,890,392,996],24, fill=(126,98,72,255))
    return PP(f)
def p_razor():
    def f(d):
        d.rounded_rectangle([336,760,566,822],18, fill=(214,220,230,255))
        d.rounded_rectangle([336,806,566,868],18, fill=(84,66,54,255))
        d.rounded_rectangle([600,720,696,930],14, fill=(226,214,190,255))
        for k in range(12):
            d.rectangle([606,736+k*15,690,742+k*15], fill=(180,166,140,255))
    return PP(f)
def p_manuscript():
    def f(d):
        for k in range(4):
            d.rounded_rectangle([330+k*10,700+k*14,690+k*10,900+k*14],10, fill=(250,248,242,255))
            d.rounded_rectangle([330+k*10,700+k*14,690+k*10,900+k*14],10, outline=(206,198,182,255), width=5)
        for k in range(7):
            d.line([(376,760+k*24),(636,760+k*24)], fill=(150,142,130,255), width=5)
    return PP(f)
MEN_PROPS=[('propSword','剣',p_sword()),('propBaton','指揮棒',p_baton()),
           ('propRazorComb','カミソリと櫛',p_razor()),('propManuscript','原稿の束',p_manuscript())]

if __name__=='__main__':
    from handfix import place
    lst=[(k,n,g,'g') for k,n,g in MEN]+[(k,n,g,'h') for k,n,g in MEN_HATS]+[(k,n,g,'p') for k,n,g in MEN_PROPS]
    S=300; cols=7; rows=(len(lst)+cols-1)//cols
    sheet=Image.new('RGBA',(S*cols+22*(cols+1),(S+22)*rows+22),(247,242,230,255))
    for i,(k,n,g,kind) in enumerate(lst):
        p=new(); p.alpha_composite(body)
        if kind=='g': p.alpha_composite(g)
        p.alpha_composite(head)
        if kind=='h': p.alpha_composite(g)
        if kind=='p': p.alpha_composite(place(g,'R'))
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(22+(S+22)*(i%cols),22+(S+22)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-男性の役17点.png')
    print(len(lst))
