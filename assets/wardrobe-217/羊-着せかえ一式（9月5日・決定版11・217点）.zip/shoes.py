from PIL import Image, ImageDraw
import numpy as np, math
orig=Image.open('orig_sheep.png').convert('RGBA')
head=Image.open('sheepparts2/sheep_head.png').convert('RGBA')
body=Image.open('sheepparts2/sheep_body.png').convert('RGBA')
W,H=orig.size
def sh(c,d): return tuple(max(0,int(v*(1-d))) for v in c)
def li(c,d): return tuple(min(255,int(v+(255-v)*d)) for v in c)
def new(): return Image.new('RGBA',(W,H),(0,0,0,0))
LX,RX = 418, 604            # 足のまんなか

def pair(fn):
    l=new(); d=ImageDraw.Draw(l)
    for cx in (LX,RX): fn(d,cx)
    return l

def boots(col=(122,84,54)):
    def f(d,cx):
        d.rounded_rectangle([cx-74,844,cx+74,952],28, fill=(*col,255))
        d.rounded_rectangle([cx-74,844,cx-24,952],20, fill=(*li(col,0.16),255))
        d.rounded_rectangle([cx-84,930,cx+84,976],18, fill=(*sh(col,0.34),255))
        d.line([(cx-52,868),(cx+52,868)], fill=(*sh(col,0.24),255), width=8)
        d.line([(cx-52,898),(cx+52,898)], fill=(*sh(col,0.24),255), width=8)
    return pair(f)
def geta():
    W1=(206,176,132); B=(70,62,56)
    def f(d,cx):
        d.rounded_rectangle([cx-76,896,cx+76,936],10, fill=(*W1,255))
        d.rectangle([cx-58,936,cx-30,978], fill=(*sh(W1,0.24),255))
        d.rectangle([cx+30,936,cx+58,978], fill=(*sh(W1,0.24),255))
        d.line([(cx,900),(cx-40,928)], fill=(*B,255), width=13)
        d.line([(cx,900),(cx+40,928)], fill=(*B,255), width=13)
    return pair(f)
def zori():
    W1=(224,206,168); B=(160,40,58)
    def f(d,cx):
        d.rounded_rectangle([cx-72,900,cx+72,952],26, fill=(*W1,255))
        d.rounded_rectangle([cx-72,940,cx+72,962],14, fill=(*sh(W1,0.28),255))
        d.line([(cx,906),(cx-38,936)], fill=(*B,255), width=14)
        d.line([(cx,906),(cx+38,936)], fill=(*B,255), width=14)
    return pair(f)
def sneakers():
    W1=(250,248,242); B=(76,96,140)
    def f(d,cx):
        d.rounded_rectangle([cx-76,858,cx+76,948],30, fill=(*W1,255))
        d.rounded_rectangle([cx-84,930,cx+84,972],18, fill=(*B,255))
        for i in range(3):
            d.line([(cx-40,876+i*22),(cx+40,876+i*22)], fill=(*sh(W1,0.22),255), width=7)
        d.ellipse([cx-24,900,cx+24,948], fill=(*li(B,0.72),255))
    return pair(f)
def maryjane():
    B=(52,48,58); S=(236,232,224)
    def f(d,cx):
        d.rounded_rectangle([cx-72,878,cx+72,952],30, fill=(*B,255))
        d.rounded_rectangle([cx-80,938,cx+80,976],16, fill=(*sh(B,0.3),255))
        d.line([(cx-62,896),(cx+62,896)], fill=(*B,255), width=16)
        d.ellipse([cx+44,884,cx+70,910], fill=(*S,255))
    return pair(f)
def rainboots(col=(230,190,72)):
    def f(d,cx):
        d.rounded_rectangle([cx-76,820,cx+76,948],30, fill=(*col,255))
        d.rounded_rectangle([cx-76,820,cx-26,948],22, fill=(*li(col,0.20),255))
        d.rounded_rectangle([cx-84,932,cx+84,976],18, fill=(*sh(col,0.36),255))
        d.rounded_rectangle([cx-76,820,cx+76,846],12, fill=(*sh(col,0.18),255))
    return pair(f)
def pumps():
    B=(30,28,34)
    def f(d,cx):
        d.rounded_rectangle([cx-68,884,cx+68,948],28, fill=(*B,255))
        d.polygon([(cx+20,944),(cx+56,944),(cx+50,988),(cx+30,988)], fill=(*B,255))
        d.rounded_rectangle([cx-76,938,cx+40,964],12, fill=(*sh(B,0.4),255))
        d.ellipse([cx-16,890,cx+16,914], fill=(200,180,110,255))
    return pair(f)
def waraji():
    W1=(214,196,152)
    def f(d,cx):
        d.rounded_rectangle([cx-70,902,cx+70,954],24, fill=(*W1,255))
        for i in range(5):
            d.line([(cx-64,912+i*9),(cx+64,912+i*9)], fill=(*sh(W1,0.14),255), width=5)
        d.line([(cx,900),(cx-46,942)], fill=(*sh(W1,0.34),255), width=10)
        d.line([(cx,900),(cx+46,942)], fill=(*sh(W1,0.34),255), width=10)
    return pair(f)

SHOES=[('shoesBoots','革のブーツ',boots()),('shoesGeta','下駄',geta()),('shoesZori','草履',zori()),
       ('shoesSneakers','スニーカー',sneakers()),('shoesMaryJane','ストラップの靴',maryjane()),
       ('shoesRainBoots','ながぐつ',rainboots()),('shoesStagePumps','本番の靴',pumps()),
       ('shoesWaraji','わらじ',waraji())]
if __name__=='__main__':
    S=320; cols=4
    sheet=Image.new('RGBA',(S*cols+30*(cols+1),(S+30)*2+30),(247,242,230,255))
    for i,(k,n,g) in enumerate(SHOES):
        p=new(); p.alpha_composite(g); p.alpha_composite(body); p.alpha_composite(head)
        p2=new(); p2.alpha_composite(body); p2.alpha_composite(head); p2.alpha_composite(g)
        c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p2)
        sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(30+(S+30)*(i%cols),30+(S+30)*(i//cols)))
    sheet.convert('RGB').save('/home/claude/out/羊-靴8点.png')
    print('ok')
