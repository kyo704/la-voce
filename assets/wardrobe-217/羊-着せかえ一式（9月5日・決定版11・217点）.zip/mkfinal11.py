import json
from PIL import Image
from era import make, body, head, new, W, H
import era_defs, acc, shoes as shoesmod, season as se, wafuku as wa
import hats2, props2, world, biz, armor
import busho2 as busho
import gown, opera, otoko
from junihitoe2 import junihitoe
from handfix import place as hand_place, HANDS

SPRING=(232,168,182); SUMMER=(122,178,196); AUTUMN=(186,146,96); WINTER=(72,86,128)
ALL=[]
def add(k,n,g,slot,z,img): ALL.append((k,n,g,slot,z,img))

for k,n,img in [
 ('coatSpringCardigan','春 うすもものカーディガン', se.build(SPRING,hem_y=756,drop=26,sleeve_x=200,buttons=2,accent=(255,240,240))),
 ('coatSummerVest','夏 みずいろのベスト', se.build(SUMMER,hem_y=744,drop=22,sleeve=False,buttons=2,pattern=se.stripes(se.li(SUMMER,0.28),30),accent=(250,252,255))),
 ('coatAutumnCamel','秋 キャメルのコート', se.build(AUTUMN,hem_y=838,drop=26,buttons=3,pattern=se.check(se.sh(AUTUMN,0.10),58))),
 ('coatWinterDuffle','冬 こんのダッフル', se.build(WINTER,hem_y=852,drop=22,sleeve_x=204,buttons=3,accent=(224,214,190))),
]: add(k,n,'season','garment',2,img)
for k,n,img in [
 ('kimonoRedSakura','和服・赤（桜）', wa.kimono((168,32,48),(232,214,168), wa.p_sakura((248,224,232)))),
 ('kimonoYellowYagasuri','和服・黄（矢絣）', wa.kimono((212,164,40),(120,40,60), wa.p_yagasuri((250,246,230)))),
 ('kimonoBlueSeigaiha','和服・青（青海波）', wa.kimono((46,86,140),(226,196,120), wa.p_seigaiha((116,164,206),(206,230,244)))),
 ('kimonoManNavyHaori','和服・男（紺＋羽織）', wa.kimono((62,74,106),(60,64,86), wa.p_none, furisode=False, haori=(132,138,152), hem_y=880)),
]: add(k,n,'wafuku','garment',2,img)
for k,n,img in acc.HATS:   add(k,n,'accessory','hat',6,img)
for k,n,img in acc.NECKS:  add(k,n,'accessory','neck',3,img)
for k,n,img in acc.PROPS:  add(k,n,'accessory','prop',7,img)
for k,n,img in shoesmod.SHOES: add(k,n,'shoes','shoes',5,img)
for k,n,kw in era_defs.CONF:
    if k=='heianJunihitoe': add(k,n,'era','garment',2,junihitoe())
    else:                   add(k,n,'era','garment',2,make(**kw))
for k,n,img in hats2.ERA_HATS: add(k,n,'era','hat',6,img)
for k,n,img in props2.ERA_PROPS: add(k,n,'era','prop',7,img)
for k,n,img in world.GARMENTS: add(k,n,'world','garment',2,img)
for k,n,img in world.HATS:     add(k,n,'world','hat',6,img)
for k,n,img in world.PROPS:    add(k,n,'world','prop',7,img)
for k,n,img in biz.SUITS:      add(k,n,'business','garment',2,img)
for k,n,img in biz.BIZ_HATS:   add(k,n,'business','hat',6,img)
for k,n,img in biz.BIZ_PROPS:  add(k,n,'business','prop',7,img)
for k,n,img in armor.ARMOR:       add(k,n,'armor','garment',2,img)
for k,n,img in armor.ARMOR_HATS:  add(k,n,'armor','hat',6,img)
for k,n,img in armor.ARMOR_PROPS: add(k,n,'armor','prop',7,img)
for k,n,img in busho.BUSHO:       add(k,n,'armor','garment',2,img)
for k,n,img in busho.BUSHO_HATS:  add(k,n,'armor','hat',6,img)
for k,n,img in gown.GOWNS:        add(k,n,'stage','garment',2,img)
for k,n,img in gown.OPERA:
    if k=='operaCarmen': continue          # 新しいカルメンに差し替え
    add(k,n,'stage','garment',2,img)
for k,n,img in opera.ROLES:          add(k,n,'opera','garment',2,img)
for k,n,img in opera.RECITAL():      add(k,n,'stage','garment',2,img)
for k,n,img in opera.STAGE:          add(k,n,'opera','hat',6,img)
for k,n,img in opera.STAGE_PROPS:    add(k,n,'opera','prop',7,img)
for k,n,img in otoko.MEN:            add(k,n,'opera','garment',2,img)
for k,n,img in otoko.MEN_HATS:       add(k,n,'opera','hat',6,img)
for k,n,img in otoko.MEN_PROPS:      add(k,n,'opera','prop',7,img)
for k,n,img in gown.STAGE_HATS:   add(k,n,'stage','hat',6,img)

seen=set()
idx=[]
for k,n,g,slot,z,img in ALL:
    assert k not in seen, 'dup '+k
    seen.add(k)
    if slot=='prop':
        files={}
        for side,tag in [('L','left'),('R','right'),('C','both')]:
            hand_place(img, side).save('final11/items/%s_%s.png'%(k,side))
            files[tag]="items/%s_%s.png"%(k,side)
        idx.append({"key":k,"name":n,"group":g,"slot":slot,"z":z,"files":files,"size":[1024,1024]})
    else:
        img.save('final11/items/%s.png'%k)
        idx.append({"key":k,"name":n,"group":g,"slot":slot,"z":z,"file":"items/%s.png"%k,"size":[1024,1024]})
json.dump({"version":"2026-09-05k","base":{"body":"sheep_body.png","head":"sheep_head.png"},
  "order":["body","garment","neck","head","shoes","hat","prop"],
  "groups":{"season":"四季","wafuku":"和服","era":"時代","world":"世界","business":"ビジネス","armor":"甲冑","stage":"本番の装い","opera":"オペラの役",
            "accessory":"小物","shoes":"靴"},
  "hands":{k:{"cx":v["cx"],"cy":v["cy"],"box":list(v["box"]),"paws":v["paws"]} for k,v in HANDS.items()},
  "items":idx}, open('final11/items-index.json','w'), ensure_ascii=False, indent=2)

S=230; cols=10; rows=(len(ALL)+cols-1)//cols
sheet=Image.new('RGBA',(S*cols+16*(cols+1),(S+16)*rows+16),(247,242,230,255))
for i,(k,n,g,slot,z,img) in enumerate(ALL):
    p=new(); p.alpha_composite(body)
    if slot in ('garment','neck'): p.alpha_composite(img)
    p.alpha_composite(head)
    if slot=='prop': p.alpha_composite(hand_place(img,'R'))
    elif slot in ('hat','shoes'): p.alpha_composite(img)
    c=Image.new('RGBA',(W,H),(255,253,248,255)); c.alpha_composite(p)
    sheet.alpha_composite(c.resize((S,S),Image.LANCZOS),(16+(S+16)*(i%cols),16+(S+16)*(i//cols)))
sheet.convert('RGB').save('final11/一覧.jpg',quality=88)
sheet.convert('RGB').save('/home/claude/out/羊-全140点の一覧.jpg',quality=88)
print(len(ALL))
