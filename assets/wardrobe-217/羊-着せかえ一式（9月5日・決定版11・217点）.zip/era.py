from PIL import Image, ImageDraw
import numpy as np, math
A,B,C,FLAT=-0.00237595,2.49995,-58.78,490.0
def jaw(x): return max(A*x*x+B*x+C,FLAT)
CX=511
orig=Image.open('orig_sheep.png').convert('RGBA')
head=Image.open('sheepparts2/sheep_head.png').convert('RGBA')
body=Image.open('sheepparts2/sheep_body.png').convert('RGBA')
W,H=orig.size; SIL=np.array(orig)[:,:,3]
def sh(c,d): return tuple(max(0,int(v*(1-d))) for v in c)
def li(c,d): return tuple(min(255,int(v+(255-v)*d)) for v in c)
def new(): return Image.new('RGBA',(W,H),(0,0,0,0))
from PIL import ImageFilter
_SILC={}
def _sil(expand=0):
    if expand<=0: return SIL
    if expand in _SILC: return _SILC[expand]
    m=Image.fromarray(SIL)
    for _ in range(max(1,expand//9)):
        m=m.filter(ImageFilter.MaxFilter(19))
    _SILC[expand]=np.array(m)
    return _SILC[expand]
def clipsil(l, expand=0):
    a=np.array(l); s=_sil(expand)
    a[:,:,3]=(a[:,:,3].astype(int)*s.astype(int)//255).astype('uint8')
    return Image.fromarray(a)
EY,ERX,ERY=660,268,300
def torso_hw(y):
    t=1-((y-EY)/ERY)**2
    return ERX*math.sqrt(t) if t>0 else 0.0
def shoulder(x,drop=150): return 592-drop*((x-CX)/300.0)**2
def top_y(x,drop=150):    return max(jaw(x)-14, shoulder(x,drop))

# ── 柄 ───────────────────────────────────────────
def P_none(x,y,b): return b
def P_stripe(c2,w=30,diag=False):
    return lambda x,y,b: (c2 if (((x+y) if diag else x)//w)%2==0 else b)
def P_check(c2,w=48):
    return lambda x,y,b: (c2 if ((x//w)%2==0)^((y//w)%2==0) else b)
def P_dots(c2,step=72,r=12):
    return lambda x,y,b: (c2 if ((x%step-step//2)**2+(y%step-step//2)**2)<r*r else b)
def P_yagasuri(c2):
    def f(x,y,b):
        p=60; u=x%p; v=(y+(0 if (x//p)%2==0 else p//2))%p
        return c2 if v < p/2-abs(u-p/2)*0.9 else b
    return f
def P_sakura(c2):
    def f(x,y,b):
        gx,gy=x%88-44,y%88-44
        if math.hypot(gx,gy)<8: return c2
        for k in range(5):
            a=k*2*math.pi/5-math.pi/2
            if math.hypot(gx-18*math.cos(a),gy-18*math.sin(a))<10: return c2
        return b
    return f
def P_weave(c2):
    return lambda x,y,b: (c2 if (x//10+y//10)%2==0 else b)
def P_tenpyo(c2,c3):
    def f(x,y,b):
        gx,gy=x%104-52,y%104-52; d=math.hypot(gx,gy)
        if d<14: return c3
        if 22<d<32: return c2
        if 42<d<50: return c2
        return b
    return f
def P_karakusa(c2):
    def f(x,y,b):
        gx,gy=x%92-46,y%92-46; d=math.hypot(gx,gy)
        return c2 if 26<d<34 or d<9 else b
    return f
def P_shima(c2,c3,w=22):
    def f(x,y,b):
        k=(x//w)%3
        return b if k==0 else (c2 if k==1 else c3)
    return f

# ── 本体 ─────────────────────────────────────────
def make(col, hem_y=856, pattern=P_none, sleeve='tube', sleeve_col=None,
         collar='kimono', collar_col=(250,246,236), belt=None, belt_col=(120,90,60),
         hakama=None, hakama_hem=880, hakama_pattern=None, suspenders=None, over=None, over_col=None, drop=150,
         necklace=False, plate=None, kesa=None, kasane=None, ruff=None, tie=None, apron=None, expand=0, sleeve_cx=236, buttons=0, hem_band=None):
    def T(x): return top_y(x,drop)
    def hemc(x):
        u=(x-CX)/264.0
        return hem_y + 18*max(0.0,1-u*u)
    l=new(); a=np.array(l)
    for y in range(470,H):
        hw=torso_hw(y)
        if hw<=0: continue
        for x in range(int(CX-hw),int(CX+hw)+1):
            t=T(x); b=hemc(x)
            if y<t or y>b: continue
            base=pattern(x,y,col)
            c = li(base,0.12) if y<t+70 else (sh(base,0.15) if y>b-28 else base)
            a[y,x]=(*c,255)
    l=Image.fromarray(a); d=ImageDraw.Draw(l)

    # 袴（下半身を別色に）
    if hakama:
        a=np.array(l)
        for y in range(700,H):
            hw=torso_hw(y)
            if hw<=0: continue
            for x in range(int(CX-hw),int(CX+hw)+1):
                if y>hakama_hem: continue
                base = hakama_pattern(x,y,hakama) if hakama_pattern else hakama
                c=base if y<724 else (sh(base,0.16) if y>hakama_hem-26 else base)
                a[y,x]=(*c,255)
        l=Image.fromarray(a); d=ImageDraw.Draw(l)
        for x in range(CX-230,CX+231,52):
            d.line([(x,730),(x,hakama_hem-8)], fill=(*sh(hakama,0.14),255), width=6)

    # 袖
    scol = sleeve_col or sh(col,0.10)
    if sleeve!='none':
        wmap={'tube':(58,796),'wide':(96,846),'furisode':(66,892),'short':(62,712),'puff':(80,760)}
        ww,bot=wmap.get(sleeve,(58,796))
        for s in (-1,1):
            cx=CX+s*sleeve_cx
            d.rounded_rectangle([cx-ww,int(shoulder(cx,drop))+12,cx+ww,bot],min(ww-4,52), fill=(*scol,255))
        aa=np.array(l)
        for s in (-1,1):
            cx=CX+s*sleeve_cx
            for y in range(int(shoulder(cx,drop))+12,bot):
                for x in range(cx-ww,cx+ww+1):
                    if 0<=x<W and aa[y,x,3]>0 and pattern is not P_none:
                        aa[y,x]=(*pattern(x,y,scol),255)
        l=Image.fromarray(aa); d=ImageDraw.Draw(l)

    # 上に羽織るもの（外側だけ別色）
    if over:
        aa=np.array(l)
        for y in range(470,min(H,hem_y)):
            hw=torso_hw(y)
            if hw<=0: continue
            for x in list(range(int(CX-hw),CX-140))+list(range(CX+140,int(CX+hw)+1)):
                if 0<=x<W and y>=T(x) and aa[y,x,3]>0:
                    aa[y,x]=(*(li(over,0.10) if y<T(x)+66 else over),255)
        l=Image.fromarray(aa); d=ImageDraw.Draw(l)
        for s in (-1,1):
            cx=CX+s*236
            d.rounded_rectangle([cx-64,int(shoulder(cx,drop))+12,cx+64,806],48, fill=(*sh(over,0.10),255))

    # 衿
    if collar=='kimono':
        EDGE=sh(col,0.30); XP,YP=CX-8,706
        def cl(xt,ovr):
            yt=int(T(xt))-8
            d.line([(xt,yt),(XP,YP)], fill=(*EDGE,255), width=58)
            d.line([(xt,yt),(XP,YP)], fill=(*(collar_col if ovr else sh(collar_col,0.13)),255), width=46)
        cl(CX-152,False); cl(CX+152,True)          # ★右前：左→右の順
        d.line([(XP,YP),(XP-62,YP+58)], fill=(*EDGE,255), width=58)
        d.line([(XP,YP),(XP-62,YP+58)], fill=(*collar_col,255), width=46)
    elif collar=='round':
        j=int(jaw(CX))
        d.pieslice([CX-124,j-104,CX-4,j+50],18,174, fill=(*collar_col,255))
        d.pieslice([CX+4,j-104,CX+124,j+50],6,162, fill=(*collar_col,255))
    elif collar=='v':
        d.polygon([(CX-150,int(T(CX-150))),(CX,700),(CX+150,int(T(CX+150)))], fill=(*collar_col,255))
    elif collar=='stand':
        aa=np.array(l)
        for x in range(CX-180,CX+181):
            t=int(T(x))
            for y in range(t,t+52):
                if aa[y,x,3]>0: aa[y,x]=(*collar_col,255)
        l=Image.fromarray(aa); d=ImageDraw.Draw(l)

    # 帯・ベルト
    if belt=='obi':
        OT,OB=744,832
        d.rectangle([CX-266,OT,CX+266,OB], fill=(*belt_col,255))
        d.rectangle([CX-266,OT,CX+266,OT+18], fill=(*li(belt_col,0.28),255))
        d.rectangle([CX-266,OB-12,CX+266,OB], fill=(*sh(belt_col,0.26),255))
        d.rounded_rectangle([CX-52,OT+28,CX+52,OT+70],16, fill=(*li(belt_col,0.46),255))
    elif belt=='obi-wide':
        OT,OB=712,856
        d.rectangle([CX-270,OT,CX+270,OB], fill=(*belt_col,255))
        d.rectangle([CX-270,OT,CX+270,OT+22], fill=(*li(belt_col,0.26),255))
        d.line([(CX-270,OT+70),(CX+270,OT+70)], fill=(*sh(belt_col,0.28),255), width=8)
    elif belt=='sash':
        d.rectangle([CX-262,744,CX+262,796], fill=(*belt_col,255))
    elif belt=='belt':
        d.rectangle([CX-262,752,CX+262,806], fill=(*belt_col,255))
        d.rounded_rectangle([CX-42,748,CX+42,810],10, fill=(*li(belt_col,0.55),255))
        d.rounded_rectangle([CX-24,764,CX+24,794],6, fill=(*sh(belt_col,0.3),255))

    if kasane:   # 襲（かさね）：裾と袖口に色を重ねる
        aa=np.array(l); n=len(kasane)
        for i,cc in enumerate(kasane):
            for x in range(W):
                b=int(hemc(x))
                for y in range(max(0,b-34*(n-i)),max(0,b-34*(n-i-1))):
                    if aa[y,x,3]>0: aa[y,x]=(*cc,255)
        l=Image.fromarray(aa); d=ImageDraw.Draw(l)
        for s2 in (-1,1):
            cx=CX+s2*sleeve_cx
            for i,cc in enumerate(kasane):
                d.rounded_rectangle([cx-104,846-30*(len(kasane)-i),cx+104,846-30*(len(kasane)-i-1)+6],10, fill=(*cc,255))
    if ruff:     # 襞襟（南蛮風）
        j=int(jaw(CX))
        d.ellipse([CX-172,j-72,CX+172,j+96], fill=(*ruff,255))
        for k in range(-6,7):
            d.line([(CX+k*26,j-40),(CX+k*30,j+84)], fill=(*sh(ruff,0.10),255), width=5)
    if tie:      # ネクタイ／リボン
        j=int(jaw(CX))
        d.polygon([(CX-30,j+18),(CX+30,j+18),(CX+22,j+180),(CX-22,j+180)], fill=(*tie,255))
        d.polygon([(CX-34,j+6),(CX+34,j+6),(CX+24,j+52),(CX-24,j+52)], fill=(*sh(tie,0.18),255))
    if hem_band:
        aa=np.array(l)
        for x in range(W):
            b=int(hemc(x))
            for y in range(max(0,b-40),b):
                if aa[y,x,3]>0: aa[y,x]=(*hem_band,255)
        l=Image.fromarray(aa); d=ImageDraw.Draw(l)

    if suspenders:
        for s2 in (-1,1):
            d.line([(CX+s2*104,int(T(CX+s2*104))+6),(CX+s2*70,760)], fill=(*suspenders,255), width=34)
        d.line([(CX-96,700),(CX+96,700)], fill=(*suspenders,255), width=26)
        for s2 in (-1,1):
            d.ellipse([CX+s2*76-19,742,CX+s2*76+19,780], fill=(*li(suspenders,0.5),255))
    if plate:  # 領巾（肩から流れる長い布）
        for s in (-1,1):
            x0=CX+s*150; x1=CX+s*268
            d.polygon([(x0,int(T(x0))+8),(x1,int(T(x1))+30),(x1+s*18,884),(x0+s*26,868)],
                      fill=(*plate,255))
            d.polygon([(x0,int(T(x0))+8),(x0+s*40,int(T(x0))+20),(x0+s*54,860),(x0+s*26,868)],
                      fill=(*li(plate,0.22),255))
    if kesa:   # 袈裟衣（肩から斜めにかける）
        d.polygon([(CX-206,int(T(CX-206))+6),(CX-118,int(T(CX-118))-4),(CX+250,844),(CX+186,904)],
                  fill=(*kesa,255))
    if apron:
        d.rounded_rectangle([CX-124,716,CX+124,884],40, fill=(*apron,255))
        d.rounded_rectangle([CX-124,716,CX+124,760],28, fill=(*sh(apron,0.08),255))
        d.line([(CX-124,742),(CX+124,742)], fill=(*sh(apron,0.14),255), width=6)
    if necklace:
        d.arc([CX-150,int(jaw(CX))-70,CX+150,int(jaw(CX))+94],10,170, fill=(122,150,138,255), width=13)
        for i,x in enumerate(range(CX-104,CX+105,52)):
            yy=int(jaw(CX))+40+int(18*math.cos((x-CX)/104*1.4))
            d.ellipse([x-19,yy-19,x+19,yy+19], fill=((92,132,120) if i%2==0 else (206,186,140))+(255,))
    if buttons:
        d.line([(CX,int(T(CX))+70),(CX,hem_y-16)], fill=(*sh(col,0.24),255), width=6)
        for i in range(buttons):
            y=676+i*74
            d.ellipse([CX-16,y-16,CX+16,y+16], fill=(*li(col,0.66),255))

    a=np.array(l)
    for x in range(W): a[:max(0,int(T(x))),x]=(0,0,0,0)
    for y in range(H):
        hw=torso_hw(y); lo,hi=int(CX-hw)-104-expand,int(CX+hw)+104+expand
        a[y,:max(0,lo)]=(0,0,0,0); a[y,min(W,hi)+1:]=(0,0,0,0)
    for x in range(W):
        b=int(hemc(x))
        if abs(x-CX)<250:
            bb=max(b, hakama_hem if hakama else 0)
            a[bb:,x]=(0,0,0,0)
    return clipsil(Image.fromarray(a), expand)

def stack(g):
    p=new(); p.alpha_composite(body); p.alpha_composite(g); p.alpha_composite(head); return p
