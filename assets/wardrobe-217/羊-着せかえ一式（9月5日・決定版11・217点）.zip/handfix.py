from PIL import Image, ImageDraw
import numpy as np

W=H=1024
WOOL=(246,239,223); WOOL2=(235,227,204); WOOL3=(224,215,188)

# 手の位置（見る人から見て）
HANDS={
 'L': dict(cx=322, cy=702, box=(300,296), paws=[]),   # 見る人の左＝羊の右手
 'R': dict(cx=700, cy=702, box=(300,296), paws=[]),   # 見る人の右＝羊の左手
 'C': dict(cx=516, cy=690, box=(440,300), paws=[]),   # まん中
}

def _fit(img, cx, cy, bw, bh):
    a=np.array(img); m=a[:,:,3]>8
    if not m.any(): return img
    ys,xs=np.nonzero(m)
    x0,x1,y0,y1=xs.min(),xs.max(),ys.min(),ys.max()
    w,h=x1-x0+1, y1-y0+1
    s=min(bw/w, bh/h, 1.0)
    nw,nh=max(1,int(round(w*s))), max(1,int(round(h*s)))
    crop=img.crop((x0,y0,x1+1,y1+1)).resize((nw,nh), Image.LANCZOS)
    out=Image.new('RGBA',(W,H),(0,0,0,0))
    out.alpha_composite(crop,(int(cx-nw/2), int(cy-nh/2)))
    return out

def _paw(img, px, py):
    d=ImageDraw.Draw(img)
    d.ellipse([px-64,py-56,px+64,py+58], fill=(*WOOL2,255))     # ふちの影
    d.ellipse([px-58,py-52,px+58,py+52], fill=(*WOOL,255))      # 手
    for k in (-1,0,1):                                          # 指
        d.ellipse([px+k*32-19,py-58,px+k*32+19,py-20], fill=(*WOOL,255))
        d.arc([px+k*32-19,py-58,px+k*32+19,py-20],180,360, fill=(*WOOL3,255), width=4)
    d.arc([px-58,py-52,px+58,py+52],0,180, fill=(*WOOL3,255), width=4)
    return img

def place(img, side='R'):
    cfg=HANDS[side]
    out=_fit(img, cfg['cx'], cfg['cy'], *cfg['box'])
    for (px,py) in cfg.get('paws',[]):
        out=_paw(out, px, py)
    return out
